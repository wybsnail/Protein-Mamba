import sys
import os
import torch

pb_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "finetuning/deepsol/Baseline_ProtBert"))
sys.path.insert(0, pb_dir)
import models as pb_models

def count_parameters(model):
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total_params, trainable_params

def main():
    print("Testing ProtBert Finetuning Initialization & Parameter Counting...\n")
    
    # We use a mocked parameter dictionary to initialize the Baseline LoRA model
    # (These replicate the ones defined in setup_baseline_finetuning.py)
    hyperparameters = {
        'pretrained_model_path': 'Rostlab/prot_bert',
        'out_shape': 2, # Two classes for deepsol
        'dropout_weight': 0.1,
        'lora_rank': 8,
        'lora_scaling_rank': 1,
        'lora_init_scale': 0.01,
        'lora_modules': '.*encoder.*layer.*|.*encoder.*block.*',
        'lora_layers': 'query|key|value|dense|q|k|v|o|wi_0|wi_1|wo',
        'lora_trainable_param_names': '.*norm.*|.*lora_[ab].*'
    }
    
    print("Initializing ProtBert BaselineSequenceClassificationLora...")
    try:
        model = pb_models.BaselineSequenceClassificationLora(hyperparameters)
        total, trainable = count_parameters(model)
        
        print("\n--- Model Parameter Summary ---")
        print(f"Total Parameters:      {total:,}")
        print(f"Trainable Parameters:  {trainable:,}")
        print(f"Percentage Trainable:  {(trainable / total) * 100:.3f} %")
        
        print("\n--- Trainable Layers ---")
        for name, param in model.named_parameters():
            if param.requires_grad:
                print(f" - {name} ({param.numel():,} params)")
                
    except Exception as e:
        print(f"Error initializing model: {e}")

if __name__ == "__main__":
    main()
