import os
from transformers import AutoTokenizer, AutoModel

# 1. Provide absolute explicit path
local_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "model/prot_bert")).replace('\\', '/')
print(f"Loading from: {local_path}")

try:
    print("\n--- Testing Tokenizer ---")
    tokenizer = AutoTokenizer.from_pretrained(local_path, local_files_only=True)
    print("Tokenizer loaded successfully.")
    
    print("\n--- Testing Model ---")
    model = AutoModel.from_pretrained(local_path, local_files_only=True)
    print("Model loaded successfully.")
except Exception as e:
    print(f"Error: {e}")
