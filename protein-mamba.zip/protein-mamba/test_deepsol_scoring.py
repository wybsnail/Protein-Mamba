from conservation import ESMConservationScorer
import pandas as pd
from pathlib import Path
import time

def main():
    # 1. 加载 deepsol 测试集的前 5 条数据进行演示
    csv_path = "data/benchmark/deepsol/test.csv"
    print(f"读取数据集: {csv_path}")
    df = pd.read_csv(csv_path).head(5)
    
    # 2. 初始化保守性评分器
    # 使用默认的 ESM2 模型 (esm2_t30_150M)
    print("正在初始化 ESMConservationScorer...")
    scorer = ESMConservationScorer(batch_size=8)
    
    # 3. 逐条评分
    print("\n开始进行保守性评分演示:")
    for i, row in df.iterrows():
        seq = row['aa_seq']
        label = row['label']
        print(f"\n[序列 {i+1}] 长度: {len(seq)}, Label: {label}")
        print(f"序列预览: {seq[:30]}...")
        
        t0 = time.time()
        entropy, cons_bin = scorer.score_sequence(seq)
        elapsed = time.time() - t0
        
        print(f"评分耗时: {elapsed:.2f}s")
        print(f"平均熵值 (Entropy): {entropy.mean():.4f}")
        print(f"保守性分布: HIGH={sum(cons_bin==25)}, MED={sum(cons_bin==26)}, LOW={sum(cons_bin==27)}")

if __name__ == "__main__":
    main()
