import os
import re
import shutil

DATASETS = {
    'deepsol': {'task': 'classification', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 1700, 'n_labels': 2},
    'envision': {'task': 'regression', 'seq_col': 'primary', 'label_col': 'scaled_effect1', 'max_len': 500, 'n_labels': 1},
    'flip_thermostability': {'task': 'regression', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 2700, 'n_labels': 1},
    'rocklin': {'task': 'regression', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 100, 'n_labels': 1},
    'sarkisyan': {'task': 'regression', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 300, 'n_labels': 1},
    'flip_aav': {'task': 'regression', 'seq_col': 'sequence', 'label_col': 'target', 'max_len': 500, 'n_labels': 1, 'split_file': 'mut_des.csv'},
    'flip_gb1': {'task': 'regression', 'seq_col': 'sequence', 'label_col': 'target', 'max_len': 100, 'n_labels': 1, 'split_file': 'two_vs_rest.csv'},
}

def patch_utils(template_path, out_path):
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Add regression loss and spearman if not exists
    if "loss_fn_regression" not in content:
        regression_losses = """

def loss_fn_regression(predictions, truths):
    loss_fct = torch.nn.MSELoss()
    predictions = predictions.squeeze(-1)
    truths = truths.to(torch.float32)
    batch_loss = loss_fct(predictions, truths)
    pred_list = predictions.cpu().detach().numpy().tolist()
    label_list = truths.cpu().detach().numpy().tolist()
    return batch_loss, pred_list, label_list

def get_spearman(truths, preds):
    from scipy.stats import spearmanr
    import numpy as np
    res, _ = spearmanr(truths, preds)
    if np.isnan(res): res = 0.0
    return res
"""
        content += regression_losses

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)

def patch_models(template_path, out_path):
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Rename PerSequenceClassificationLoraKCNE1 to PerSequenceClassificationLora
    content = re.sub(r"class PerSequenceClassificationLoraKCNE1\(", "class PerSequenceClassificationLora(", content)
    content = re.sub(r"super\(PerSequenceClassificationLoraKCNE1,", "super(PerSequenceClassificationLora,", content)

    # Note: dataset logic is generic: dataframe, tokenizer, max_len, seqname, labelname
    # But wait, original code has: ids, _ = self.tokenizer.encode(sequence, cons_scores=None)
    # We should make sure pd.isna is handled
    replacement_encode = """
        sequence = str(self.sequences[index])
        if sequence == 'nan': sequence = ''
        ids, _ = self.tokenizer.encode(sequence, cons_scores=None)"""
    content = re.sub(r"\s*sequence = self.sequences\[index\]\n\s*label = self.labels\[index\]\n\s*ids, _ = self.tokenizer.encode\(sequence, cons_scores=None\)", replacement_encode + "\n        label = self.labels[index]", content)

    # For DualChannel template:
    replacement_encode_dual = """
        sequence = str(self.sequences[index])
        if sequence == 'nan': sequence = ''
        cons_list = self.cons[index] if hasattr(self, 'cons') else None
        ids, cons = self.tokenizer.encode(sequence, cons_scores=cons_list)"""
    content = re.sub(r"\s*sequence = self.sequences\[index\]\n\s*label = self.labels\[index\]\n\s*cons_list = self.cons\[index\]\n\s*ids, cons = self.tokenizer.encode\(sequence, cons_scores=cons_list\)", replacement_encode_dual + "\n        label = self.labels[index]", content)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)

def patch_train(template_path, out_path, dname, info, channel):
    with open(template_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Generic replaces
    content = re.sub(r"PerSequenceClassificationLoraKCNE1", "PerSequenceClassificationLora", content)
    content = re.sub(r"KCNE1_MAX_LEN =", "MAX_LEN =", content)
    content = re.sub(r"KCNE1_MAX_LEN", "MAX_LEN", content)
    content = re.sub(r"KCNE1_", f"{dname}_", content)
    content = re.sub(r"'accession'", f"'{info['seq_col']}'", content)
    content = re.sub(r"'Mutated_Sequence_NO_HTL'", f"'{info['seq_col']}'", content)
    content = re.sub(r"'Mutated_Sequence_HTL'", f"'{info['seq_col']}'", content)
    content = re.sub(r"LABEL_NAME = 'label'", f"LABEL_NAME = '{info['label_col']}'", content)
    
    # 1. Metrics switch
    if info['task'] == 'regression':
        # Replace f1_score with get_spearman
        content = re.sub(r"from sklearn.metrics import classification_report, f1_score", "from sklearn.metrics import classification_report, f1_score\nfrom scipy.stats import spearmanr", content)
        content = re.sub(r"f1_score\(epoch_val_labels, epoch_val_preds, average='macro'\)", "utils.get_spearman(epoch_val_labels, epoch_val_preds)", content)
        content = re.sub(r"current_val_macro_f1", "current_val_metric", content)
        content = re.sub(r"new_val_macro_f1", "new_val_metric", content)
        
        # Replace loss_fn_multi_class with loss_fn_regression
        content = re.sub(r"utils.loss_fn_multi_class\(tmp_outputs, tmp_labels, positive_weightings.to\(device\)\)", "utils.loss_fn_regression(tmp_outputs, tmp_labels)", content)
        content = re.sub(r"utils.loss_fn_multi_class\(train_outputs, train_labels, positive_weightings.to\(device\)\)", "utils.loss_fn_regression(train_outputs, train_labels)", content)
        
        # Disable positive scalings
        content = re.sub(r"positive_weightings = utils.get_pos_scalings\(.*?\)", "positive_weightings = None", content)
        
        # Disable classification report printing
        content = re.sub(r"print\(classification_report\(.*?\)[\s\S]*?\n\n", "pass\n\n", content)
        content = re.sub(r"print\('Validation Classification Report'\)\s*print\(classification_report\(.*?\)\)\s*print\(\)", "pass", content)
        content = re.sub(r"print\('Testing Metrics'\)\s*print\(classification_report\(.*?\)\)", "print('Testing Spearman:', utils.get_spearman(epoch_test_labels, epoch_test_preds))", content)

    # 2. Fix data loading logic
    load_block_regex = r"train_df = shuffle\(joblib.load\(cwd \+ .*?\)\)[\s\S]*?test_df\.index = test_df\.index\.astype\(str\)"
    
    if 'split_file' in info:
        data_loading = f"""
    full_df = pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/splits/{info['split_file']}')
    train_df = shuffle(full_df[full_df['set'] == 'train'])
    
    if 'validation' in full_df.columns and full_df['validation'].any():
        val_df = shuffle(full_df[full_df['validation'] == True])
    else:
        # fallback if no standard validation set
        val_df = shuffle(full_df[full_df['set'] == 'test'].sample(frac=0.5))
        
    test_df = shuffle(full_df[full_df['set'] == 'test'])
    train_df.index = train_df.index.astype(str)
    val_df.index = val_df.index.astype(str)
    test_df.index = test_df.index.astype(str)
"""
    else:
        data_loading = f"""
    train_df = shuffle(pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/train.csv'))
    val_df = shuffle(pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/validation.csv'))
    test_df = shuffle(pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/test.csv'))
    train_df.index = train_df.index.astype(str)
    val_df.index = val_df.index.astype(str)
    test_df.index = test_df.index.astype(str)
"""
    content = re.sub(load_block_regex, data_loading.strip(), content)
    
    # 3. Adjust MAX_LEN and N_LABELS constants at bottom
    content = re.sub(r"MAX_LEN = 150", f"MAX_LEN = {info['max_len']}", content)
    content = re.sub(r"N_LABELS = 3", f"N_LABELS = {info['n_labels']}", content)
    
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)

def main():
    os.makedirs("finetuning", exist_ok=True)
    
    # We use KCNE1 as template
    base_template_dir = "finetuning/KCNE1"
    
    for dname, info in DATASETS.items():
        base_dir = os.path.join("finetuning", dname)
        os.makedirs(base_dir, exist_ok=True)
        
        for mode in ['SingleChannel', 'DualChannel']:
            tgt_dir = os.path.join(base_dir, mode)
            os.makedirs(tgt_dir, exist_ok=True)
            
            src_mode_dir = os.path.join(base_template_dir, mode)
            
            if os.path.exists(src_mode_dir):
                # 1. utils.py
                patch_utils(os.path.join(src_mode_dir, "utils.py"), os.path.join(tgt_dir, "utils.py"))
                # 2. models.py
                patch_models(os.path.join(src_mode_dir, "models.py"), os.path.join(tgt_dir, "models.py"))
                # 3. train_*.py
                train_file = f"train_{mode.lower()}_channel.py" # wait, the file is train_single_channel.py
                if mode == 'SingleChannel': src_train = "train_single_channel.py"
                else: src_train = "train_dual_channel.py"
                
                if os.path.exists(os.path.join(src_mode_dir, src_train)):
                    patch_train(os.path.join(src_mode_dir, src_train), os.path.join(tgt_dir, src_train), dname, info, mode)

                print(f"Generated {dname}/{mode}")
            else:
                print(f"Missing template directory {src_mode_dir}")

if __name__ == '__main__':
    main()
