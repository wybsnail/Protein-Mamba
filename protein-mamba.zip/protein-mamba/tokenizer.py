"""保守性感知蛋白质 Tokenizer

提供 28-token 词汇表的双通道编码：
  - AA 通道：20 标准氨基酸 + 5 特殊 token
  - CONS 通道：3 保守性等级 token

模型嵌入方式：x_i = EmbAA(aa_ids[i]) + EmbCONS(cons_ids[i])
"""

from __future__ import annotations

import enum
from typing import Optional, Sequence

import numpy as np
import torch


# ═══════════════════════════════════════════════════════════════
# 词汇表定义 (28 tokens)
# ═══════════════════════════════════════════════════════════════

# ── 特殊 token (5) ──
PAD_TOKEN = "[PAD]"
UNK_TOKEN = "[UNK]"
BOS_TOKEN = "[BOS]"
EOS_TOKEN = "[EOS]"
MASK_TOKEN = "[MASK]"

PAD_ID = 0
UNK_ID = 1
BOS_ID = 2
EOS_ID = 3
MASK_ID = 4

SPECIAL_TOKENS = [PAD_TOKEN, UNK_TOKEN, BOS_TOKEN, EOS_TOKEN, MASK_TOKEN]

# ── 标准氨基酸 (20) ──
AMINO_ACIDS = list("RHKDESTNQGPCAVILMFYW")
AA_OFFSET = len(SPECIAL_TOKENS)  # 5

# ── 保守性等级 (3) ──
HIGH_CONS_TOKEN = "[HIGH_CONS]"
MED_CONS_TOKEN = "[MED_CONS]"
LOW_CONS_TOKEN = "[LOW_CONS]"

CONS_OFFSET = AA_OFFSET + len(AMINO_ACIDS)  # 25
HIGH_CONS_ID = CONS_OFFSET      # 25
MED_CONS_ID = CONS_OFFSET + 1   # 26
LOW_CONS_ID = CONS_OFFSET + 2   # 27

CONS_TOKENS = [HIGH_CONS_TOKEN, MED_CONS_TOKEN, LOW_CONS_TOKEN]

VOCAB_SIZE = CONS_OFFSET + len(CONS_TOKENS)  # 28


class ConservationLevel(enum.IntEnum):
    """保守性等级枚举"""
    HIGH = HIGH_CONS_ID   # 25
    MED = MED_CONS_ID     # 26
    LOW = LOW_CONS_ID     # 27


# ═══════════════════════════════════════════════════════════════
# ProteinTokenizer
# ═══════════════════════════════════════════════════════════════

class ProteinTokenizer:
    """28-token 蛋白质分词器，支持双通道编码。

    词表布局:
        0-4:   [PAD] [UNK] [BOS] [EOS] [MASK]
        5-24:  R H K D E S T N Q G P C A V I L M F Y W
        25-27: [HIGH_CONS] [MED_CONS] [LOW_CONS]
    """

    def __init__(self, add_special: bool = True):
        """
        Args:
            add_special: 编码时是否自动添加 [BOS] / [EOS] 标记。
        """
        self.add_special = add_special

        # 正向映射: token_str → id
        self.token_to_id: dict[str, int] = {}
        self.id_to_token: dict[int, str] = {}

        for i, tok in enumerate(SPECIAL_TOKENS):
            self.token_to_id[tok] = i
            self.id_to_token[i] = tok

        for i, aa in enumerate(AMINO_ACIDS):
            tid = AA_OFFSET + i
            self.token_to_id[aa] = tid
            self.id_to_token[tid] = aa

        for i, tok in enumerate(CONS_TOKENS):
            tid = CONS_OFFSET + i
            self.token_to_id[tok] = tid
            self.id_to_token[tid] = tok

        # AA 查找（含非标 AA 映射到 UNK）
        self._aa_lookup: dict[str, int] = {
            aa: AA_OFFSET + i for i, aa in enumerate(AMINO_ACIDS)
        }

    @property
    def vocab_size(self) -> int:
        return VOCAB_SIZE

    @property
    def pad_id(self) -> int:
        return PAD_ID

    @property
    def pad_token_id(self) -> int:
        return PAD_ID

    @property
    def mask_token_id(self) -> int:
        return MASK_ID

    def get_vocab_size(self) -> int:
        return self.vocab_size

    def is_special_token(self, input_ids):
        return input_ids <= MASK_ID

    def is_ptm_token(self, input_ids):
        if torch.is_tensor(input_ids):
            return torch.zeros_like(input_ids, dtype=torch.bool)
        return np.zeros_like(input_ids, dtype=bool)

    # ── 编码 ──

    def encode_aa(self, sequence: str) -> list[int]:
        """将氨基酸序列编码为 token id 列表。

        非标 AA (X, U, O, B, Z 等) 映射到 [UNK]。

        Args:
            sequence: 氨基酸单字母序列。

        Returns:
            aa_ids 列表，长度 = len(sequence) [+ 2 if add_special]。
        """
        ids = [self._aa_lookup.get(aa, UNK_ID) for aa in sequence.upper()]
        if self.add_special:
            ids = [BOS_ID] + ids + [EOS_ID]
        return ids

    def encode(
        self,
        sequence: str,
        cons_scores: Optional[np.ndarray] = None,
        quantiles: tuple[float, float] = (0.33, 0.66),
    ) -> tuple[list[int], list[int]]:
        """双通道编码：AA token + 保守性等级 token。

        Args:
            sequence: 氨基酸单字母序列 (长度 L)。
            cons_scores: 每位置熵值数组 (长度 L)。
                None 时保守性通道全部填 MED_CONS。
            quantiles: (q_low, q_high) 分位数阈值，
                用于 per-sequence quantile 分箱。

        Returns:
            (aa_ids, cons_ids)，长度相同。
        """
        aa_ids = self.encode_aa(sequence)
        L = len(sequence)

        if cons_scores is not None:
            cons_bins = self.score_to_bin(cons_scores, quantiles)
        else:
            # 无保守性信息时默认 MED
            cons_bins = [MED_CONS_ID] * L

        cons_ids = list(cons_bins)
        if self.add_special:
            # BOS/EOS 位置的保守性 token 也设为 PAD（不参与保守性嵌入）
            cons_ids = [PAD_ID] + cons_ids + [PAD_ID]

        return aa_ids, cons_ids

    # ── 解码 ──

    def decode(self, aa_ids: Sequence[int]) -> str:
        """将 token id 列表还原为氨基酸序列字符串。

        自动过滤特殊 token。
        """
        chars = []
        for tid in aa_ids:
            if tid in (PAD_ID, BOS_ID, EOS_ID, MASK_ID, UNK_ID):
                continue
            tok = self.id_to_token.get(tid, "?")
            if len(tok) == 1:  # 单字母 AA
                chars.append(tok)
        return "".join(chars)

    # ── 分箱 ──

    @staticmethod
    def score_to_bin(
        entropy: np.ndarray,
        quantiles: tuple[float, float] = (0.33, 0.66),
    ) -> list[int]:
        """Per-sequence quantile 分箱。

        低熵 → HIGH_CONS；中 → MED_CONS；高熵 → LOW_CONS。

        Args:
            entropy: 逐位置熵值，shape (L,)。
            quantiles: (q_low, q_high)。

        Returns:
            cons_ids 列表，长度 L。
        """
        ent = np.asarray(entropy, dtype=np.float32)
        q_low, q_high = np.quantile(ent, quantiles[0]), np.quantile(ent, quantiles[1])

        bins = []
        for h in ent:
            if h <= q_low:
                bins.append(HIGH_CONS_ID)
            elif h <= q_high:
                bins.append(MED_CONS_ID)
            else:
                bins.append(LOW_CONS_ID)
        return bins

    # ── Padding ──

    def pad_batch(
        self,
        aa_batch: list[list[int]],
        cons_batch: list[list[int]],
        max_len: Optional[int] = None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """批量 padding 到统一长度。

        Args:
            aa_batch: 多条 aa_ids 序列。
            cons_batch: 对应的 cons_ids 序列。
            max_len: 目标长度，None 则取 batch 内最大值。

        Returns:
            (aa_padded, cons_padded)，shape (B, max_len)。
        """
        if max_len is None:
            max_len = max(len(s) for s in aa_batch)

        B = len(aa_batch)
        aa_out = np.full((B, max_len), PAD_ID, dtype=np.int32)
        cons_out = np.full((B, max_len), PAD_ID, dtype=np.int32)

        for i, (aa, cons) in enumerate(zip(aa_batch, cons_batch)):
            length = min(len(aa), max_len)
            aa_out[i, :length] = aa[:length]
            cons_out[i, :length] = cons[:length]

        return aa_out, cons_out


# ═══════════════════════════════════════════════════════════════
# 快捷函数
# ═══════════════════════════════════════════════════════════════

_default_tokenizer: Optional[ProteinTokenizer] = None


def get_tokenizer(add_special: bool = True) -> ProteinTokenizer:
    """获取全局默认 tokenizer 实例。"""
    global _default_tokenizer
    if _default_tokenizer is None or _default_tokenizer.add_special != add_special:
        _default_tokenizer = ProteinTokenizer(add_special=add_special)
    return _default_tokenizer


if __name__ == "__main__":
    tok = ProteinTokenizer()
    print(f"词汇表大小: {tok.vocab_size}")
    print(f"词汇表映射: {tok.token_to_id}")
    print()

    # 测试标准序列
    seq = "MALWM"
    aa_ids, cons_ids = tok.encode(seq)
    print(f"序列: {seq}")
    print(f"AA IDs:   {aa_ids}")
    print(f"CONS IDs: {cons_ids}")
    print(f"解码: {tok.decode(aa_ids)}")
    print()

    # 测试含非标 AA
    seq2 = "MALXUW"
    aa_ids2, cons_ids2 = tok.encode(seq2)
    print(f"序列 (含非标): {seq2}")
    print(f"AA IDs:   {aa_ids2}  (X→{UNK_ID}, U→{UNK_ID})")
    print(f"解码: {tok.decode(aa_ids2)}")
    print()

    # 测试带保守性分数
    entropy = np.array([0.1, 0.5, 0.3, 0.9, 0.2])
    aa_ids3, cons_ids3 = tok.encode("MALWM", cons_scores=entropy)
    print(f"保守性分数: {entropy}")
    print(f"AA IDs:   {aa_ids3}")
    print(f"CONS IDs: {cons_ids3}")
    cons_labels = [tok.id_to_token[c] if c != PAD_ID else "[PAD]" for c in cons_ids3]
    print(f"CONS 标签: {cons_labels}")
