import os, shutil
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from transformers import AutoTokenizer
from sklearn.utils import shuffle
import utils, models
import optuna
import joblib
import logging


def save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name):
    shutil_dir = trials_dir + 'Trial_' + str(parameter_dictionary['trial_num']) + '/'
    try:
        os.mkdir(shutil_dir)
    except:
        pass
    shutil.move(outmodel_name, shutil_dir)
    shutil.move(val_label_name, shutil_dir)
    shutil.move(val_pred_name, shutil_dir)
    shutil.move(test_label_name, shutil_dir)
    shutil.move(test_pred_name, shutil_dir)


def eval_model(parameter_dictionary, model, device, trial_num, epoch, set_flag):
    tmp_params = {'batch_size': parameter_dictionary['batch_size'], 'shuffle': False, 'num_workers': 0}
    tmp_loader = DataLoader(validation_set, **tmp_params) if set_flag == 'Validation' else DataLoader(testing_set, **tmp_params)
    len_tmp_dataloader = len(tmp_loader)
    tmp_loss_accumulator = 0
    model.eval()
    epoch_tmp_preds = []
    epoch_tmp_labels = []

    with torch.no_grad():
        for tmp_data_idx, tmp_data in enumerate(tmp_loader):
            tmp_percent_done = (((tmp_data_idx + 1) / len_tmp_dataloader) * 100)
            tmp_ids = tmp_data['input_ids'].to(device, dtype=torch.long)
            tmp_mask = tmp_data['attention_mask'].to(device, dtype=torch.long)
            tmp_labels = tmp_data['labels'].to(device)

            tmp_outputs = model(tmp_ids, tmp_mask)
            tmp_loss, tmp_pred, tmp_truth = utils.loss_fn_regression(tmp_outputs, tmp_labels)
            tmp_loss_accumulator += tmp_loss.item()
            epoch_tmp_preds.extend(tmp_pred)
            epoch_tmp_labels.extend(tmp_truth)
            print(f'Trial: {trial_num}, {set_flag}: Epoch: {epoch}, Loss: {tmp_loss.item():.16f}, % Done: {tmp_percent_done:.5f}')

    average_tmp_loss = np.round(tmp_loss_accumulator / len_tmp_dataloader, 8)
    return average_tmp_loss, epoch_tmp_labels, epoch_tmp_preds


def train_model(parameter_dictionary):
    trial_num = parameter_dictionary['trial_num']
    study_best = 0 if trial_num <= number_jobs else study.best_trial.values[0]
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    train_params = {'batch_size': parameter_dictionary['batch_size'], 'shuffle': True, 'num_workers': 0}
    training_loader = DataLoader(training_set, **train_params)
    len_training_dataloader = len(training_loader)

    model = models.BaselineSequenceClassificationLora(parameter_dictionary).bfloat16().to(device)
    optimizer = torch.optim.AdamW(params=model.parameters(), lr=parameter_dictionary['learning_rate'], fused=True)

    current_val_metric = -99999
    outmodel_name = 'envision_ProtT5_' + str(trial_num) + '.pt'
    val_label_name = 'ValLabels.joblib'
    val_pred_name = 'ValPreds.joblib'
    test_label_name = 'TestLabels.joblib'
    test_pred_name = 'TestPreds.joblib'

    grad_accum_steps = parameter_dictionary['grad_accum_steps']
    patience_counter = 0
    patience = 15

    for epoch in range(parameter_dictionary['epochs']):
        model.train()
        train_loss_accumulator = 0
        optimizer.zero_grad()

        for train_data_idx, train_data in enumerate(training_loader):
            training_percent_done = (((train_data_idx + 1) / len_training_dataloader) * 100)
            train_ids = train_data['input_ids'].to(device, dtype=torch.long)
            train_mask = train_data['attention_mask'].to(device, dtype=torch.long)
            train_labels = train_data['labels'].to(device)

            train_outputs = model(train_ids, train_mask)
            train_loss, _, _ = utils.loss_fn_regression(train_outputs, train_labels)
            train_loss_accumulator += train_loss.item()
            train_loss.backward()

            print(f'Trial: {trial_num}, Training: Epoch: {epoch}, Loss: {train_loss.item():.16f}, % Done: {training_percent_done:.5f}')

            if (train_data_idx + 1) % grad_accum_steps == 0 or (train_data_idx + 1) == len(training_loader):
                optimizer.step()
                optimizer.zero_grad()

            if (train_data_idx + 1) == int(np.floor(len_training_dataloader / 2)) or (train_data_idx + 1) == len_training_dataloader:
                average_train_loss = np.round(train_loss_accumulator / (train_data_idx + 1), 8)
                average_val_loss, epoch_val_labels, epoch_val_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, "Validation")
                new_val_metric = utils.get_spearman(epoch_val_labels, epoch_val_preds)

                if new_val_metric >= current_val_metric:
                    current_val_metric = new_val_metric
                    patience_counter = 0
                    torch.save(model.state_dict(), outmodel_name)
                    joblib.dump(epoch_val_labels, val_label_name)
                    joblib.dump(epoch_val_preds, val_pred_name)
                else:
                    patience_counter += 1

                print('Average train loss: ' + str(average_train_loss))
                print('Average validation loss: ' + str(average_val_loss))
                print('Validation Spearman: ' + str(new_val_metric))
                print('Patience = ' + str(patience_counter))

                if patience_counter != patience:
                    model.train()
                else:
                    if current_val_metric >= study_best:
                        _, epoch_test_labels, epoch_test_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, 'Testing')
                        joblib.dump(epoch_test_labels, test_label_name)
                        joblib.dump(epoch_test_preds, test_pred_name)
                        save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name)
                    else:
                        os.remove(outmodel_name)
                        os.remove(val_label_name)
                        os.remove(val_pred_name)
                    model.to('cpu')
                    del model
                    torch.cuda.empty_cache()
                    return current_val_metric

    _, epoch_test_labels, epoch_test_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, 'Testing')
    joblib.dump(epoch_test_labels, test_label_name)
    joblib.dump(epoch_test_preds, test_pred_name)
    save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name)
    model.to('cpu')
    del model
    torch.cuda.empty_cache()
    return current_val_metric


def objective(trial):
    torch.cuda.empty_cache()
    utils.seed_everything(seed)
    trial_num = trial.number

    if trial_num != 0:
        best_params = study.best_trial.params
        best_params['best_trial_num'] = study.best_trial.number
        joblib.dump(best_params, 'best_hyperparameters.joblib')
        study.trials_dataframe().to_csv('optuna_data.csv', index=False)
        joblib.dump(study, 'optuna_study.joblib')

    parameters = {
        'pretrained_model_path': os.path.abspath(os.path.join(os.path.dirname(__file__), "../../..", "model", "prot_t5_xl_uniref50")).replace("\\", "/"),
        'in_shape': MAX_LEN,
        'out_shape': N_LABELS,
        'epochs': EPOCHS,
        'batch_size': 64,
        'grad_accum_steps': trial.suggest_int('grad_accum_steps', 4, 16, step=2),
        'dropout_weight': trial.suggest_float('dropout_weight', 0.1, 0.4, log=False),
        'learning_rate': trial.suggest_float('learning_rate', 0.00001, 0.001, log=False),
        'trial_num': trial_num,
        'lora_rank': trial.suggest_int('lora_rank', 4, 8, step=1),
        'lora_scaling_rank': 1,
        'lora_init_scale': 0.01,
        'lora_modules': '.*encoder.*layer.*|.*encoder.*block.*',
        'lora_layers': 'query|key|value|dense|q|k|v|o|wi_0|wi_1|wo',
        'lora_trainable_param_names': '.*norm.*|.*lora_[ab].*'
    }

    trial_metric = train_model(parameters)
    torch.cuda.empty_cache()
    return trial_metric


if __name__ == '__main__':
    global cwd, seed, trials_dir, tokenizer, training_set, validation_set, testing_set
    global MAX_LEN, N_LABELS, study, number_jobs

    cwd = os.getcwd() + '/'
    seed = 42

    utils.seed_everything(seed)
    utils.set_global_logging_level(logging.ERROR, ["transformers", "nlp", "torch", "tensorflow", "tensorboard", "wandb"])
    trials_dir = utils.setup_trials_dir(cwd)

    MAX_LEN = 500
    N_LABELS = 1

    tokenizer = AutoTokenizer.from_pretrained(
        os.path.abspath(os.path.join(os.path.dirname(__file__), "../../..", "model", "prot_t5_xl_uniref50")).replace("\\", "/"),
        local_files_only=True,
    )

    train_df = shuffle(pd.read_csv(cwd + '../../../data/benchmark/envision/train.csv'))
    val_df = shuffle(pd.read_csv(cwd + '../../../data/benchmark/envision/validation.csv'))
    test_df = shuffle(pd.read_csv(cwd + '../../../data/benchmark/envision/test.csv'))

    label_col = 'scaled_effect1'
    for split_name, df in [('train', train_df), ('validation', val_df), ('test', test_df)]:
        before = len(df)
        numeric = pd.to_numeric(df[label_col], errors='coerce')
        mask = np.isfinite(numeric.to_numpy())
        df.drop(df.index[~mask], inplace=True)
        df[label_col] = numeric[mask]
        after = len(df)
        removed = before - after
        if removed > 0:
            print(f"[{split_name}] removed invalid labels: {removed}")

    training_set = models.BaselineDataset(train_df, tokenizer, MAX_LEN, 'primary', 'scaled_effect1', N_LABELS, True)
    validation_set = models.BaselineDataset(val_df, tokenizer, MAX_LEN, 'primary', 'scaled_effect1', N_LABELS, True)
    testing_set = models.BaselineDataset(test_df, tokenizer, MAX_LEN, 'primary', 'scaled_effect1', N_LABELS, True)

    number_trials = 1
    number_jobs = 1

    global EPOCHS
    EPOCHS = 30

    study = optuna.create_study(study_name="envision_prott5", direction='maximize', sampler=optuna.samplers.TPESampler(seed=seed))
    study.optimize(objective, n_trials=number_trials, n_jobs=number_jobs, show_progress_bar=True)
