import re
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
import torch.nn.init as initialization_strategy
import utils
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from transformers import AutoModel, AutoModelForSequenceClassification

utils.seed_everything()

class BaselineDataset(Dataset):
    def __init__(self, dataframe, tokenizer, max_len, seqname, labelname, n_labels, requires_spaces=False):
        self.tokenizer = tokenizer
        self.dataframe = dataframe.copy().reset_index(drop=True)
        self.sequences = self.dataframe[seqname].values
        self.labels = self.dataframe[labelname].values
        self.max_len = max_len
        self.requires_spaces = requires_spaces

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, index):
        sequence = self.sequences[index]
        label = self.labels[index]
        if pd.isna(sequence): sequence = ''
        
        if self.requires_spaces:
            # ProtBert and ProtT5 require spaces between amino acids
            sequence = " ".join(list(sequence))
            
        inputs = self.tokenizer(
            sequence, 
            padding='max_length', 
            truncation=True, 
            max_length=self.max_len, 
            return_tensors='pt'
        )
        
        ids = inputs['input_ids'].squeeze(0)
        mask = inputs['attention_mask'].squeeze(0)
        
        # for bfloat16 loss fn compatibility
        if 'classification' == 'classification':
            label_tensor = torch.tensor(label, dtype=torch.bfloat16) 
        else:
            label_tensor = torch.tensor(label, dtype=torch.bfloat16)
        
        return {'input_ids': ids, 'attention_mask': mask, 'labels': label_tensor}

class LoRALinear(nn.Module):
    def __init__(self, linear_layer, rank, scaling_rank, init_scale):
        super().__init__()
        self.in_features = linear_layer.in_features
        self.out_features = linear_layer.out_features
        self.rank = rank
        self.scaling_rank = scaling_rank
        self.weight = linear_layer.weight
        self.bias = linear_layer.bias
        
        dtype = linear_layer.weight.dtype
        self.lora_a = nn.Parameter(torch.randn(rank, linear_layer.in_features, dtype=dtype) * init_scale)
        self.lora_b = nn.Parameter(torch.zeros(linear_layer.out_features, rank, dtype=dtype))
        self.multi_lora_a = nn.Parameter(torch.ones(self.scaling_rank, linear_layer.in_features, dtype=dtype) + torch.randn(self.scaling_rank, linear_layer.in_features, dtype=dtype) * init_scale)
        self.multi_lora_b = nn.Parameter(torch.ones(linear_layer.out_features, self.scaling_rank, dtype=dtype))

    def forward(self, input):
        weight = self.weight
        weight = weight * torch.matmul(self.multi_lora_b, self.multi_lora_a) / self.scaling_rank
        weight = weight + torch.matmul(self.lora_b, self.lora_a) / self.rank
        return F.linear(input, weight, self.bias)

class BaselineSequenceClassificationLora(torch.nn.Module):
    def __init__(self, hyperparameters_dictionary):
        super(BaselineSequenceClassificationLora, self).__init__()
        self.out_shape = hyperparameters_dictionary['out_shape']
        self.dropout_weight = hyperparameters_dictionary['dropout_weight']
        self.lora_rank = hyperparameters_dictionary['lora_rank']
        self.lora_scaling_rank = hyperparameters_dictionary['lora_scaling_rank']
        self.lora_init_scale = hyperparameters_dictionary['lora_init_scale']
        self.lora_modules = hyperparameters_dictionary['lora_modules']
        self.lora_layers = hyperparameters_dictionary['lora_layers']
        self.lora_trainable_param_names = hyperparameters_dictionary['lora_trainable_param_names']

        pretrained_path = hyperparameters_dictionary.get('pretrained_model_path', None)
        from transformers import AutoConfig
        config = AutoConfig.from_pretrained(pretrained_path, local_files_only=True)
        self.encoder = AutoModel.from_config(config)
        # Load the locally saved state dict safely directly into the model
        import safetensors.torch
        state_dict_path = os.path.join(pretrained_path, "pytorch_model.bin")
        if not os.path.exists(state_dict_path):
            state_dict_path = os.path.join(pretrained_path, "model.safetensors")
            if os.path.exists(state_dict_path):
                state_dict = safetensors.torch.load_file(state_dict_path)
            else:
                raise FileNotFoundError("Could not find pytorch_model.bin or model.safetensors locally.")
        else:
            state_dict = torch.load(state_dict_path, map_location="cpu", weights_only=True)
            
        self.encoder.load_state_dict(state_dict, strict=False)
        self.embedding_shape = self.encoder.config.hidden_size

        if hasattr(self.encoder, "gradient_checkpointing_enable"):
            self.encoder.gradient_checkpointing_enable()
            
        for m_name, module in dict(self.encoder.named_modules()).items():
            if re.fullmatch(self.lora_modules, m_name):
                for c_name, layer in dict(module.named_children()).items():
                    if re.fullmatch(self.lora_layers, c_name):
                        if isinstance(layer, nn.Linear):
                            setattr(module, c_name, LoRALinear(layer, self.lora_rank, self.lora_scaling_rank, self.lora_init_scale))
        
        for (param_name, param) in self.encoder.named_parameters():
            if not re.fullmatch(self.lora_trainable_param_names, param_name):
                param.requires_grad = False         
            else:
                param.requires_grad = True

        self.dropout_layer = torch.nn.Dropout(self.dropout_weight)
        self.activation_function = F.relu

        self.l1 = torch.nn.Linear(self.embedding_shape, 512, bias=True)
        self.l2 = torch.nn.Linear(512, 256, bias=True)
        self.l3 = torch.nn.Linear(256, 128, bias=True)
        self.classification_layer = torch.nn.Linear(128, self.out_shape, bias=True)
        
        initialization_strategy.xavier_uniform_(self.l1.weight)
        initialization_strategy.xavier_uniform_(self.l2.weight)
        initialization_strategy.xavier_uniform_(self.l3.weight)
        initialization_strategy.xavier_uniform_(self.classification_layer.weight)

        # Ensure the entire model (including newly added head and LoRA) is the same dtype as the encoder weights
        encoder_dtype = next(self.encoder.parameters()).dtype
        self.to(encoder_dtype)

    def forward(self, ids, mask):
        utils.seed_everything()
        
        encoder_output = self.encoder(input_ids=ids, attention_mask=mask)
        logits = encoder_output.last_hidden_state
        
        mask_expanded = mask.unsqueeze(-1).expand(logits.size()).to(logits.dtype)
        sum_embeddings = torch.sum(logits * mask_expanded, 1)
        sum_mask = mask_expanded.sum(1)
        sum_mask = torch.clamp(sum_mask, min=1e-9)
        logits = sum_embeddings / sum_mask
        
        logits = self.dropout_layer(logits)
        logits = self.l1(logits)
        logits = self.activation_function(logits)
        logits = self.dropout_layer(logits)
        logits = self.l2(logits)
        logits = self.activation_function(logits)
        logits = self.dropout_layer(logits)
        logits = self.l3(logits)
        logits = self.activation_function(logits)
        
        logits = self.classification_layer(logits)
        return logits
