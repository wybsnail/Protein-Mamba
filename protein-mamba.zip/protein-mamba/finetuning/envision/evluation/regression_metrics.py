from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Iterable, List, Optional

import joblib
import numpy as np
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


_SPLIT_FILE_MAP = {
    "val": ("ValLabels.joblib", "ValPreds.joblib"),
    "test": ("TestLabels.joblib", "TestPreds.joblib"),
}


def _to_1d_float(values: Iterable) -> np.ndarray:
    """Convert possible nested predictions/labels to 1D float array."""
    arr = np.asarray(values)
    if arr.ndim > 1:
        # For regression this usually won't happen, but keep safe fallback.
        arr = arr.reshape(arr.shape[0], -1).mean(axis=1)
    return arr.astype(np.float64).reshape(-1)


def _compute_regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    mse = float(mean_squared_error(y_true, y_pred))
    rmse = float(np.sqrt(mse))
    mae = float(mean_absolute_error(y_true, y_pred))
    r2 = float(r2_score(y_true, y_pred))

    # Handle constant arrays safely for correlation metrics.
    if len(np.unique(y_true)) <= 1 or len(np.unique(y_pred)) <= 1:
        spearman = 0.0
        pearson = 0.0
    else:
        spearman = float(spearmanr(y_true, y_pred).correlation)
        pearson = float(pearsonr(y_true, y_pred).statistic)
        if np.isnan(spearman):
            spearman = 0.0
        if np.isnan(pearson):
            pearson = 0.0

    return {
        "mse": mse,
        "rmse": rmse,
        "mae": mae,
        "r2": r2,
        "spearman": spearman,
        "pearson": pearson,
    }


def _pick_trial_dirs(model_dir: Path, best_only: bool) -> List[Path]:
    """
    Select trial directories.

    If `best_only` and best_hyperparameters.joblib exists, pick only that trial.
    Otherwise return all Trial_* dirs; if none, fall back to model_dir itself.
    """
    trials_root = model_dir / "Trials"
    if not trials_root.exists():
        return [model_dir]

    if best_only:
        best_path = model_dir / "best_hyperparameters.joblib"
        if best_path.exists():
            try:
                payload = joblib.load(best_path)
                best_trial = payload.get("best_trial_num", None)
                if best_trial is not None:
                    d = trials_root / f"Trial_{best_trial}"
                    if d.exists():
                        return [d]
            except Exception:
                pass

    trial_dirs = sorted(d for d in trials_root.glob("Trial_*") if d.is_dir())
    return trial_dirs if trial_dirs else [model_dir]


def compute_all_envision_baseline_metrics(
    envision_dir: str | Path,
    split: str = "test",
    output_csv: str | Path | None = None,
    best_only: bool = True,
) -> list[dict]:
    """
    Compute regression metrics for all baseline-like models under finetuning/envision.

    This will scan directories:
      - SingleChannel
      - DualChannel
      - Baseline_*

    It expects per-trial saved predictions:
      - ValLabels.joblib / ValPreds.joblib
      - TestLabels.joblib / TestPreds.joblib
    """
    if split not in _SPLIT_FILE_MAP:
        raise ValueError(f"split must be one of {list(_SPLIT_FILE_MAP)}, got: {split}")

    envision_dir = Path(envision_dir).resolve()
    label_file, pred_file = _SPLIT_FILE_MAP[split]

    model_dirs: List[Path] = []
    for name in ["SingleChannel", "DualChannel"]:
        p = envision_dir / name
        if p.is_dir():
            model_dirs.append(p)
    model_dirs.extend(sorted(p for p in envision_dir.glob("Baseline_*") if p.is_dir()))

    rows: list[dict] = []

    for model_dir in model_dirs:
        trial_dirs = _pick_trial_dirs(model_dir, best_only=best_only)
        for run_dir in trial_dirs:
            labels_path = run_dir / label_file
            preds_path = run_dir / pred_file
            if not labels_path.exists() or not preds_path.exists():
                continue

            y_true = _to_1d_float(joblib.load(labels_path))
            y_pred = _to_1d_float(joblib.load(preds_path))
            if len(y_true) == 0 or len(y_pred) == 0 or len(y_true) != len(y_pred):
                continue

            metrics = _compute_regression_metrics(y_true, y_pred)
            trial_name = run_dir.name if run_dir != model_dir else "root"
            rows.append(
                {
                    "model": model_dir.name,
                    "trial": trial_name,
                    "split": split,
                    "count": int(len(y_true)),
                    **metrics,
                }
            )

    if output_csv:
        output_csv = Path(output_csv).resolve()
        output_csv.parent.mkdir(parents=True, exist_ok=True)
        with output_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "model",
                    "trial",
                    "split",
                    "count",
                    "mse",
                    "rmse",
                    "mae",
                    "r2",
                    "spearman",
                    "pearson",
                ],
            )
            writer.writeheader()
            writer.writerows(rows)

    return rows


def main():
    parser = argparse.ArgumentParser(
        description="Compute regression metrics for all envision baseline models."
    )
    parser.add_argument(
        "--envision-dir",
        type=str,
        default=str(Path(__file__).resolve().parents[1]),
        help="Path to finetuning/envision",
    )
    parser.add_argument(
        "--split",
        type=str,
        default="test",
        choices=["val", "test"],
        help="Which split predictions to evaluate",
    )
    parser.add_argument(
        "--output-csv",
        type=str,
        default=None,
        help="Optional output CSV path",
    )
    parser.add_argument(
        "--all-trials",
        action="store_true",
        help="Evaluate all Trial_* dirs. Default is best trial only when possible.",
    )

    args = parser.parse_args()

    rows = compute_all_envision_baseline_metrics(
        envision_dir=args.envision_dir,
        split=args.split,
        output_csv=args.output_csv,
        best_only=not args.all_trials,
    )
    print(f"Computed {len(rows)} rows.")
    if len(rows) == 0:
        print("No matching prediction files found in SingleChannel/DualChannel/Baseline_*.")


if __name__ == "__main__":
    main()
