from pathlib import Path
import sys

import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

from tokenizer import ProteinTokenizer


class BaselineDataset(Dataset):
    def __init__(self, dataframe, tokenizer, max_len, seqname, labelname):
        self.tokenizer = tokenizer
        self.dataframe = dataframe.copy().reset_index(drop=True)
        self.sequences = self.dataframe[seqname].values
        self.labels = self.dataframe[labelname].values
        self.max_len = max_len

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, index):
        sequence = self.sequences[index]
        if pd.isna(sequence):
            sequence = ""
        ids, _ = self.tokenizer.encode(str(sequence), cons_scores=None)

        if len(ids) > self.max_len:
            ids = ids[: self.max_len]

        mask_len = len(ids)
        if mask_len < self.max_len:
            ids = ids + [self.tokenizer.pad_token_id] * (self.max_len - mask_len)

        mask = [1] * mask_len + [0] * (self.max_len - mask_len)
        label = int(float(self.labels[index]))

        return {
            "input_ids": torch.tensor(ids, dtype=torch.long),
            "attention_mask": torch.tensor(mask, dtype=torch.long),
            "labels": torch.tensor(label, dtype=torch.long),
        }


class TransformerSequenceClassifier(nn.Module):
    def __init__(self, hyperparameters_dictionary, vocab_size: int, pad_token_id: int):
        super().__init__()
        out_shape = hyperparameters_dictionary["out_shape"]
        d_model = hyperparameters_dictionary["d_model"]
        n_heads = hyperparameters_dictionary["n_heads"]
        num_layers = hyperparameters_dictionary["num_layers"]
        ff_dim = hyperparameters_dictionary["ff_dim"]
        dropout = hyperparameters_dictionary["dropout_weight"]
        max_len = hyperparameters_dictionary["max_len"]

        self.token_embedding = nn.Embedding(vocab_size, d_model, padding_idx=pad_token_id)
        self.position_embedding = nn.Embedding(max_len, d_model)

        self.encoder = nn.ModuleList(
            [
                _TransformerBlock(
                    d_model=d_model,
                    n_heads=n_heads,
                    ff_dim=ff_dim,
                    dropout=dropout,
                )
                for _ in range(num_layers)
            ]
        )

        self.classifier = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Dropout(dropout),
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, out_shape),
        )

    def forward(self, ids, mask):
        batch_size, seq_len = ids.shape
        pos_ids = torch.arange(seq_len, device=ids.device).unsqueeze(0).expand(batch_size, seq_len)

        x = self.token_embedding(ids) + self.position_embedding(pos_ids)
        key_padding_mask = mask == 0
        for layer in self.encoder:
            x = layer(x, key_padding_mask=key_padding_mask)

        mask_expanded = mask.unsqueeze(-1).to(x.dtype)
        pooled = torch.sum(x * mask_expanded, dim=1)
        pooled = pooled / torch.clamp(mask_expanded.sum(dim=1), min=1e-9)

        return self.classifier(pooled)


class _MultiHeadSelfAttention(nn.Module):
    """Multi-head self-attention that supports d_model not divisible by n_heads.

    We project from d_model -> (n_heads * head_dim) and back.
    """

    def __init__(self, d_model: int, n_heads: int, dropout: float, head_dim: int = 16):
        super().__init__()
        self.d_model = int(d_model)
        self.n_heads = int(n_heads)
        self.head_dim = int(head_dim)
        self.inner_dim = self.n_heads * self.head_dim

        self.qkv = nn.Linear(self.d_model, 3 * self.inner_dim, bias=True)
        self.out = nn.Linear(self.inner_dim, self.d_model, bias=True)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, key_padding_mask: torch.Tensor | None = None) -> torch.Tensor:
        # x: (B, L, D)
        bsz, seq_len, _ = x.shape
        qkv = self.qkv(x)  # (B, L, 3*inner)
        q, k, v = qkv.chunk(3, dim=-1)

        q = q.view(bsz, seq_len, self.n_heads, self.head_dim).transpose(1, 2)  # (B, H, L, Hd)
        k = k.view(bsz, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
        v = v.view(bsz, seq_len, self.n_heads, self.head_dim).transpose(1, 2)

        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)  # (B, H, L, L)
        if key_padding_mask is not None:
            # key_padding_mask: (B, L) with True for pads
            pad = key_padding_mask[:, None, None, :].to(dtype=torch.bool)
            attn_scores = attn_scores.masked_fill(pad, torch.finfo(attn_scores.dtype).min)

        attn = F.softmax(attn_scores, dim=-1)
        attn = self.dropout(attn)

        ctx = torch.matmul(attn, v)  # (B, H, L, Hd)
        ctx = ctx.transpose(1, 2).contiguous().view(bsz, seq_len, self.inner_dim)  # (B, L, inner)
        return self.out(ctx)


class _TransformerBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, ff_dim: int, dropout: float):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.attn = _MultiHeadSelfAttention(d_model=d_model, n_heads=n_heads, dropout=dropout)
        self.drop1 = nn.Dropout(dropout)

        self.norm2 = nn.LayerNorm(d_model)
        self.ff = nn.Sequential(
            nn.Linear(d_model, ff_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ff_dim, d_model),
        )
        self.drop2 = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, key_padding_mask: torch.Tensor | None = None) -> torch.Tensor:
        x = x + self.drop1(self.attn(self.norm1(x), key_padding_mask=key_padding_mask))
        x = x + self.drop2(self.ff(self.norm2(x)))
        return x
