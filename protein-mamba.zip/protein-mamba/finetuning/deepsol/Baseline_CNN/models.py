from pathlib import Path
import sys

import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

from tokenizer import ProteinTokenizer


class BaselineDataset(Dataset):
    def __init__(self, dataframe, tokenizer, max_len, seqname, labelname):
        self.tokenizer = tokenizer
        self.dataframe = dataframe.copy().reset_index(drop=True)
        self.sequences = self.dataframe[seqname].values
        self.labels = self.dataframe[labelname].values
        self.max_len = max_len

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, index):
        sequence = self.sequences[index]
        if pd.isna(sequence):
            sequence = ""
        ids, _ = self.tokenizer.encode(str(sequence), cons_scores=None)

        if len(ids) > self.max_len:
            ids = ids[: self.max_len]

        mask_len = len(ids)
        if mask_len < self.max_len:
            ids = ids + [self.tokenizer.pad_token_id] * (self.max_len - mask_len)

        mask = [1] * mask_len + [0] * (self.max_len - mask_len)
        label = int(float(self.labels[index]))

        return {
            "input_ids": torch.tensor(ids, dtype=torch.long),
            "attention_mask": torch.tensor(mask, dtype=torch.long),
            "labels": torch.tensor(label, dtype=torch.long),
        }


class SamePadConv1d(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int):
        super().__init__()
        self.kernel_size = int(kernel_size)
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size=self.kernel_size, padding=0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Pad so output length == input length for stride=1.
        total_pad = self.kernel_size - 1
        left = total_pad // 2
        right = total_pad - left
        x = F.pad(x, (left, right))
        return self.conv(x)


class CNNSequenceClassifier(nn.Module):
    """1D-CNN baseline: 4 conv layers (32/64/96/128 filters) with kernels (6/8/10/12).

    Final convolutional features are pooled and fed to a 1-layer MLP (linear) for prediction.
    """

    def __init__(self, hyperparameters_dictionary, vocab_size: int, pad_token_id: int):
        super().__init__()
        out_shape = hyperparameters_dictionary["out_shape"]
        embedding_dim = hyperparameters_dictionary.get("embedding_dim", 100)

        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=pad_token_id)

        self.conv1 = SamePadConv1d(embedding_dim, 32, 6)
        self.conv2 = SamePadConv1d(32, 64, 8)
        self.conv3 = SamePadConv1d(64, 96, 10)
        self.conv4 = SamePadConv1d(96, 128, 12)
        self.act = nn.ReLU()

        self.classifier = nn.Linear(128, out_shape)

    def forward(self, ids: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        x = self.embedding(ids)  # (B, L, E)
        x = x.transpose(1, 2)  # (B, E, L)

        x = self.act(self.conv1(x))
        x = self.act(self.conv2(x))
        x = self.act(self.conv3(x))
        x = self.act(self.conv4(x))  # (B, 128, L)

        mask_f = mask.unsqueeze(1).to(dtype=x.dtype)  # (B, 1, L)
        pooled = torch.sum(x * mask_f, dim=2)
        pooled = pooled / torch.clamp(mask_f.sum(dim=2), min=1e-9)

        return self.classifier(pooled)
