from pathlib import Path
import sys

import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

from tokenizer import ProteinTokenizer


class BaselineDataset(Dataset):
    def __init__(self, dataframe, tokenizer, max_len, seqname, labelname):
        self.tokenizer = tokenizer
        self.dataframe = dataframe.copy().reset_index(drop=True)
        self.sequences = self.dataframe[seqname].values
        self.labels = self.dataframe[labelname].values
        self.max_len = max_len

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, index):
        sequence = self.sequences[index]
        if pd.isna(sequence):
            sequence = ""
        ids, _ = self.tokenizer.encode(str(sequence), cons_scores=None)

        if len(ids) > self.max_len:
            ids = ids[: self.max_len]

        mask_len = len(ids)
        if mask_len < self.max_len:
            ids = ids + [self.tokenizer.pad_token_id] * (self.max_len - mask_len)

        mask = [1] * mask_len + [0] * (self.max_len - mask_len)
        label = int(float(self.labels[index]))

        return {
            "input_ids": torch.tensor(ids, dtype=torch.long),
            "attention_mask": torch.tensor(mask, dtype=torch.long),
            "labels": torch.tensor(label, dtype=torch.long),
        }


class LSTMSequenceClassifier(nn.Module):
    def __init__(self, hyperparameters_dictionary, vocab_size: int, pad_token_id: int):
        super().__init__()
        out_shape = hyperparameters_dictionary["out_shape"]
        embedding_dim = hyperparameters_dictionary["embedding_dim"]
        hidden_dim = hyperparameters_dictionary["hidden_dim"]
        num_layers = hyperparameters_dictionary["num_layers"]
        dropout = hyperparameters_dictionary["dropout_weight"]

        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=pad_token_id)
        self.encoder = nn.LSTM(
            input_size=embedding_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, out_shape),
        )

    def forward(self, ids, mask):
        x = self.embedding(ids)

        lengths = mask.sum(dim=1).detach().cpu()
        lengths = torch.clamp(lengths, min=1)
        packed = nn.utils.rnn.pack_padded_sequence(
            x,
            lengths,
            batch_first=True,
            enforce_sorted=False,
        )
        _, (h_n, _) = self.encoder(packed)

        # last layer's forward/backward hidden states
        forward_last = h_n[-2]
        backward_last = h_n[-1]
        pooled = torch.cat([forward_last, backward_last], dim=1)

        return self.classifier(pooled)
