import logging
import os
import random
import re

import numpy as np
import torch


seed = 42


def seed_everything(seed_value: int = seed):
    random.seed(seed_value)
    os.environ["PYTHONHASHSEED"] = str(seed_value)
    np.random.seed(seed_value)
    torch.manual_seed(seed_value)
    torch.cuda.manual_seed(seed_value)
    torch.cuda.manual_seed_all(seed_value)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def setup_trials_dir(cwd: str) -> str:
    trials_dir = os.path.join(cwd, "Trials")
    os.makedirs(trials_dir, exist_ok=True)
    return trials_dir + "/"


def get_class_weights(dataframe, n_labels: int, label_col: str = "label") -> torch.Tensor:
    labels = dataframe[label_col].astype(int).to_numpy()
    counts = np.bincount(labels, minlength=n_labels).astype(np.float32)
    counts[counts == 0] = 1.0
    # Balanced class weights: N / (K * n_c)
    weights = counts.sum() / (n_labels * counts)
    return torch.tensor(weights, dtype=torch.float32)


def loss_fn_multi_class(predictions, truths, class_weights=None):
    if truths.dim() > 1:
        truths = torch.argmax(truths, dim=1)
    truths = truths.long()

    if class_weights is not None:
        class_weights = class_weights.to(predictions.device, dtype=predictions.dtype)
        loss_fct = torch.nn.CrossEntropyLoss(weight=class_weights)
    else:
        loss_fct = torch.nn.CrossEntropyLoss()

    batch_loss = loss_fct(predictions, truths)
    pred_list = predictions.argmax(dim=1).detach().cpu().numpy().tolist()
    label_list = truths.detach().cpu().numpy().tolist()
    return batch_loss, pred_list, label_list


def set_global_logging_level(level=logging.ERROR, prefices=("", "torch.distributed")):
    prefix_re = re.compile(fr'^(?:{"|".join(prefices)})')
    for name in logging.root.manager.loggerDict:
        if re.match(prefix_re, name):
            logging.getLogger(name).setLevel(level)
