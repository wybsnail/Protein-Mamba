from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Iterable, List

import joblib
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support


_SPLIT_FILE_MAP = {
    "val": ("ValLabels.joblib", "ValPreds.joblib"),
    "test": ("TestLabels.joblib", "TestPreds.joblib"),
}


def _flatten_labels(values: Iterable) -> np.ndarray:
    """Convert nested list/array labels to a 1D int array."""
    arr = np.asarray(values)
    if arr.ndim > 1:
        arr = np.argmax(arr, axis=1)
    return arr.astype(int).reshape(-1)


def _compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> List[dict]:
    labels = sorted(set(y_true.tolist()) | set(y_pred.tolist()))
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=labels,
        zero_division=0,
    )
    accuracy = float(accuracy_score(y_true, y_pred))

    rows = []
    for cls, p, r, f, s in zip(labels, precision, recall, f1, support):
        rows.append(
            {
                "class": int(cls),
                "precision": float(p),
                "recall": float(r),
                "f1": float(f),
                "support": int(s),
                "accuracy": accuracy,
            }
        )
    return rows


def compute_all_baseline_metrics(
    deepsol_dir: str | Path,
    split: str = "test",
    output_csv: str | Path | None = None,
) -> list[dict]:
    """
    Compute precision/recall/f1/support/accuracy for all finetuned baseline models.

    Args:
        deepsol_dir: Path like `finetuning/deepsol`.
        split: `val` or `test`.
        output_csv: Optional output CSV path.

    Returns:
        A list of metric rows (one row per class per model/trial/split).
    """
    if split not in _SPLIT_FILE_MAP:
        raise ValueError(f"split must be one of {list(_SPLIT_FILE_MAP)}, got: {split}")

    deepsol_dir = Path(deepsol_dir).resolve()
    label_file, pred_file = _SPLIT_FILE_MAP[split]

    metric_rows: list[dict] = []

    for baseline_dir in sorted(deepsol_dir.glob("Baseline_*")):
        if not baseline_dir.is_dir():
            continue

        trial_dirs = sorted((baseline_dir / "Trials").glob("Trial_*"))
        candidate_dirs = trial_dirs if trial_dirs else [baseline_dir]

        for run_dir in candidate_dirs:
            labels_path = run_dir / label_file
            preds_path = run_dir / pred_file
            if not labels_path.exists() or not preds_path.exists():
                continue

            y_true = _flatten_labels(joblib.load(labels_path))
            y_pred = _flatten_labels(joblib.load(preds_path))
            if len(y_true) == 0 or len(y_pred) == 0 or len(y_true) != len(y_pred):
                continue

            per_class = _compute_metrics(y_true, y_pred)
            trial_name = run_dir.name if run_dir != baseline_dir else "root"

            for row in per_class:
                row.update(
                    {
                        "baseline": baseline_dir.name,
                        "trial": trial_name,
                        "split": split,
                    }
                )
                metric_rows.append(row)

    if output_csv:
        output_csv = Path(output_csv).resolve()
        output_csv.parent.mkdir(parents=True, exist_ok=True)
        with output_csv.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "baseline",
                    "trial",
                    "split",
                    "class",
                    "precision",
                    "recall",
                    "f1",
                    "support",
                    "accuracy",
                ],
            )
            writer.writeheader()
            writer.writerows(metric_rows)

    return metric_rows


def main():
    parser = argparse.ArgumentParser(
        description="Compute deepsol baseline classification metrics from saved predictions."
    )
    parser.add_argument(
        "--deepsol-dir",
        type=str,
        default=str(Path(__file__).resolve().parents[1]),
        help="Path to finetuning/deepsol",
    )
    parser.add_argument(
        "--split",
        type=str,
        default="test",
        choices=["val", "test"],
        help="Which saved prediction split to evaluate",
    )
    parser.add_argument(
        "--output-csv",
        type=str,
        default=None,
        help="Optional output CSV path",
    )
    args = parser.parse_args()

    rows = compute_all_baseline_metrics(
        deepsol_dir=args.deepsol_dir,
        split=args.split,
        output_csv=args.output_csv,
    )
    print(f"Computed {len(rows)} metric rows.")
    if len(rows) == 0:
        print("No matching prediction files found under Baseline_*/Trials/Trial_*.")


if __name__ == "__main__":
    main()
