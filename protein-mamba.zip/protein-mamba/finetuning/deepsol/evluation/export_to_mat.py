import os
import joblib
import numpy as np
from pathlib import Path
from scipy.io import savemat
import argparse

def flatten_labels(values):
    arr = np.asarray(values)
    if arr.ndim > 1:
        arr = np.argmax(arr, axis=1)
    return arr.astype(int).reshape(-1)

def scores_from_preds(pred_values):
    arr = np.asarray(pred_values)
    if arr.ndim == 2:
        if arr.shape[1] >= 2:
            return arr[:, 1].astype(float)
        return arr[:, 0].astype(float)
    return arr.astype(float).reshape(-1)

def export_deepsol_to_mat(deepsol_dir, output_dir):
    deepsol_dir = Path(deepsol_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    for method_dir in deepsol_dir.glob("Baseline_*"):
        if not method_dir.is_dir():
            continue
        
        model_name = method_dir.name
        mat_data = {}
        found_data = False

        # Try to find Trials/Trial_* or root
        trial_dirs = list((method_dir / "Trials").glob("Trial_*"))
        if not trial_dirs:
            search_dirs = [method_dir]
        else:
            search_dirs = sorted(trial_dirs)

        for d in search_dirs:
            for split in ["Val", "Test"]:
                labels_path = d / f"{split}Labels.joblib"
                preds_path = d / f"{split}Preds.joblib"
                
                if labels_path.exists() and preds_path.exists():
                    try:
                        y_true = flatten_labels(joblib.load(labels_path))
                        y_score = scores_from_preds(joblib.load(preds_path))
                        
                        mat_data[f"{split.lower()}_y_true"] = y_true
                        mat_data[f"{split.lower()}_y_score"] = y_score
                        found_data = True
                    except Exception as e:
                        print(f"Error loading {model_name} {split}: {e}")

        if found_data:
            out_path = output_dir / f"{model_name}_preds.mat"
            savemat(out_path, mat_data)
            print(f"Exported {model_name} to {out_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--deepsol-dir", type=str, required=True)
    parser.add_argument("--output-dir", type=str, default="mat_data")
    args = parser.parse_args()
    
    export_deepsol_to_mat(args.deepsol_dir, args.output_dir)
