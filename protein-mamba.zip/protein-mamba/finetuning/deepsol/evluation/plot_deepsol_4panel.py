from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Dict, List


def _to_float(value: str):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except ValueError:
        return None


def read_overall_metrics(csv_path: Path) -> Dict[str, Dict[str, float]]:
    """
    Read overall metrics CSV.

    Required column:
      - model
    Optional metric columns:
      - accuracy, auroc, auprc, f1, mcc, precision, recall
    """
    result: Dict[str, Dict[str, float]] = {}
    with csv_path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        if "model" not in (reader.fieldnames or []):
            raise ValueError("overall metrics CSV must contain a 'model' column")
        for row in reader:
            model = row["model"].strip()
            if not model:
                continue
            result[model] = {}
            for k, v in row.items():
                if k == "model":
                    continue
                fv = _to_float(v)
                if fv is not None:
                    result[model][k] = fv
    return result


def read_length_metrics(csv_path: Path) -> Dict[str, Dict[float, Dict[str, float]]]:
    """
    Read length-binned metrics CSV.

    Required columns:
      - model
      - length_bin
    Optional metric columns:
      - accuracy, auprc, precision
    """
    result: Dict[str, Dict[float, Dict[str, float]]] = {}
    with csv_path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames or []
        if "model" not in fields or "length_bin" not in fields:
            raise ValueError("length metrics CSV must contain 'model' and 'length_bin'")
        for row in reader:
            model = row["model"].strip()
            lb = _to_float(row["length_bin"])
            if not model or lb is None:
                continue
            result.setdefault(model, {})
            result[model].setdefault(lb, {})
            for k, v in row.items():
                if k in {"model", "length_bin"}:
                    continue
                fv = _to_float(v)
                if fv is not None:
                    result[model][lb][k] = fv
    return result


def save_demo_csvs(out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)

    overall_path = out_dir / "overall_metrics_demo.csv"
    with overall_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["model", "accuracy", "auroc", "auprc", "f1", "mcc", "precision", "recall"])
        writer.writerow(["Baseline_ProtBert", 0.870, 0.760, 0.410, 0.230, 0.250, 0.620, 0.150])
        writer.writerow(["Baseline_ESM", 0.874, 0.768, 0.425, 0.236, 0.262, 0.700, 0.162])
        writer.writerow(["Baseline_ProtT5", 0.866, 0.748, 0.398, 0.218, 0.230, 0.590, 0.148])
        writer.writerow(["Baseline_LSTM", 0.861, 0.731, 0.380, 0.210, 0.210, 0.560, 0.141])
        writer.writerow(["Baseline_Transformer", 0.868, 0.752, 0.406, 0.225, 0.240, 0.610, 0.152])

    length_path = out_dir / "length_metrics_demo.csv"
    with length_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["model", "length_bin", "accuracy", "auprc", "precision"])
        for length_bin, pb_a, pb_c, pb_p, esm_a, esm_c, esm_p, pt5_a, pt5_c, pt5_p, lstm_a, lstm_c, lstm_p, tfm_a, tfm_c, tfm_p in [
            (11, 0.868, 0.402, 0.56, 0.872, 0.414, 0.60, 0.860, 0.380, 0.53, 0.852, 0.366, 0.50, 0.858, 0.388, 0.54),
            (15, 0.875, 0.401, 0.59, 0.878, 0.421, 0.65, 0.864, 0.386, 0.56, 0.856, 0.370, 0.52, 0.862, 0.392, 0.57),
            (21, 0.867, 0.395, 0.63, 0.871, 0.415, 0.69, 0.861, 0.379, 0.58, 0.854, 0.365, 0.55, 0.860, 0.390, 0.60),
            (25, 0.864, 0.385, 0.52, 0.868, 0.405, 0.58, 0.858, 0.372, 0.50, 0.851, 0.360, 0.48, 0.857, 0.383, 0.53),
            (31, 0.868, 0.401, 0.68, 0.873, 0.426, 0.72, 0.863, 0.392, 0.63, 0.856, 0.375, 0.58, 0.862, 0.398, 0.65),
            (35, 0.871, 0.423, 0.62, 0.876, 0.440, 0.70, 0.866, 0.404, 0.57, 0.858, 0.387, 0.54, 0.865, 0.412, 0.60),
            (41, 0.868, 0.409, 0.63, 0.873, 0.431, 0.68, 0.864, 0.398, 0.58, 0.857, 0.382, 0.55, 0.863, 0.406, 0.61),
            (45, 0.865, 0.411, 0.56, 0.870, 0.425, 0.63, 0.861, 0.389, 0.52, 0.854, 0.374, 0.49, 0.860, 0.397, 0.55),
            (51, 0.870, 0.417, 0.59, 0.874, 0.434, 0.65, 0.866, 0.401, 0.55, 0.859, 0.386, 0.52, 0.864, 0.408, 0.58),
            (55, 0.869, 0.410, 0.66, 0.873, 0.429, 0.71, 0.865, 0.395, 0.62, 0.858, 0.381, 0.59, 0.863, 0.404, 0.64),
            (61, 0.872, 0.415, 0.68, 0.876, 0.436, 0.73, 0.868, 0.403, 0.64, 0.861, 0.389, 0.61, 0.866, 0.410, 0.66),
        ]:
            writer.writerow(["Baseline_ProtBert", length_bin, pb_a, pb_c, pb_p])
            writer.writerow(["Baseline_ESM", length_bin, esm_a, esm_c, esm_p])
            writer.writerow(["Baseline_ProtT5", length_bin, pt5_a, pt5_c, pt5_p])
            writer.writerow(["Baseline_LSTM", length_bin, lstm_a, lstm_c, lstm_p])
            writer.writerow(["Baseline_Transformer", length_bin, tfm_a, tfm_c, tfm_p])

    print(f"Demo overall CSV: {overall_path}")
    print(f"Demo length CSV:  {length_path}")


def _pick_models(
    overall: Dict[str, Dict[str, float]],
    length_data: Dict[str, Dict[float, Dict[str, float]]],
    preferred: List[str] | None,
    baseline_only: bool,
) -> List[str]:
    models = list(overall.keys())
    if baseline_only:
        models = [m for m in models if m.startswith("Baseline_")]

    if preferred:
        models = [m for m in preferred if m in overall]

    models = [m for m in models if m in length_data]
    if len(models) < 2:
        raise ValueError("Need at least 2 models available in both overall and length CSV")
    return models


def plot_4panel(
    overall_csv: Path,
    length_csv: Path,
    output_path: Path,
    model_order: List[str] | None = None,
    baseline_only: bool = True,
):
    import matplotlib.pyplot as plt
    import numpy as np

    overall = read_overall_metrics(overall_csv)
    length_data = read_length_metrics(length_csv)

    models = _pick_models(
        overall=overall,
        length_data=length_data,
        preferred=model_order,
        baseline_only=baseline_only,
    )
    n_models = len(models)

    # Panel A metric order: keep the same narrative as your example.
    metric_order = ["accuracy", "auroc", "auprc", "f1", "mcc", "precision", "recall"]
    metric_labels = [m.upper() if m != "f1" else "F1" for m in metric_order]

    available_idx = [
        i for i, m in enumerate(metric_order)
        if all(m in overall[model] for model in models)
    ]
    if not available_idx:
        raise ValueError("No shared metrics found across selected models")

    panel_metrics = [metric_order[i] for i in available_idx]
    panel_labels = [metric_labels[i] for i in available_idx]
    metric_vals = {model: [overall[model][m] for m in panel_metrics] for model in models}

    bins = sorted(
        {
            b
            for model in models
            for b in length_data[model].keys()
        }
    )
    if not bins:
        raise ValueError("No length bins found for selected models")

    def series(model: str, metric: str):
        return [length_data[model].get(b, {}).get(metric, np.nan) for b in bins]

    # Style tuned for paper-like figure.
    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 10,
            "axes.linewidth": 0.8,
        }
    )

    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8.2))
    fig.subplots_adjust(wspace=0.28, hspace=0.30)

    cmap = plt.cm.get_cmap("tab10", max(n_models, 3))
    colors = [cmap(i) for i in range(n_models)]

    # A: grouped bars
    ax = axes[0, 0]
    x = np.arange(len(panel_metrics))
    total_width = 0.82
    bar_w = min(0.16, total_width / max(n_models, 1))
    start = -((n_models - 1) * bar_w) / 2
    for idx, model in enumerate(models):
        ax.bar(
            x + start + idx * bar_w,
            metric_vals[model],
            width=bar_w,
            color=colors[idx],
            label=model,
        )
    ax.set_xticks(x)
    ax.set_xticklabels(panel_labels, rotation=40, ha="right")
    ymax = max(max(v) for v in metric_vals.values())
    ax.set_ylim(0.0, ymax * 1.12)
    ax.legend(frameon=False, fontsize=8, loc="upper right", ncol=2)
    ax.text(-0.18, 1.06, "A", transform=ax.transAxes, fontsize=22, fontweight="bold", va="top")

    # B: accuracy-length
    ax = axes[0, 1]
    for idx, model in enumerate(models):
        ax.plot(bins, series(model, "accuracy"), color=colors[idx], linewidth=1.6, label=model)
    ax.set_xlabel("Length")
    ax.set_ylabel("Accuracy")
    ax.legend(frameon=False, fontsize=8, loc="best", ncol=2)
    ax.text(-0.18, 1.06, "B", transform=ax.transAxes, fontsize=22, fontweight="bold", va="top")

    # C: auprc-length
    ax = axes[1, 0]
    for idx, model in enumerate(models):
        ax.plot(bins, series(model, "auprc"), color=colors[idx], linewidth=1.6, label=model)
    ax.set_xlabel("Length")
    ax.set_ylabel("AUPRC")
    ax.legend(frameon=False, fontsize=8, loc="best", ncol=2)
    ax.text(-0.18, 1.06, "C", transform=ax.transAxes, fontsize=22, fontweight="bold", va="top")

    # D: precision-length
    ax = axes[1, 1]
    for idx, model in enumerate(models):
        ax.plot(bins, series(model, "precision"), color=colors[idx], linewidth=1.6, label=model)
    ax.set_xlabel("Length")
    ax.set_ylabel("Precision")
    ax.legend(frameon=False, fontsize=8, loc="best", ncol=2)
    ax.text(-0.18, 1.06, "D", transform=ax.transAxes, fontsize=22, fontweight="bold", va="top")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=400, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved figure to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Plot deepsol 4-panel comparison figure.")
    parser.add_argument(
        "--overall-csv",
        type=str,
        default=None,
        help="Overall metrics CSV with one row per model.",
    )
    parser.add_argument(
        "--length-csv",
        type=str,
        default=None,
        help="Length-binned metrics CSV with one row per model-length bin.",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(Path(__file__).resolve().parent / "deepsol_4panel.png"),
        help="Output figure path.",
    )
    parser.add_argument(
        "--models",
        type=str,
        nargs="*",
        default=None,
        help="Model names to plot. If omitted, auto-select baseline models.",
    )
    parser.add_argument(
        "--include-nonbaseline",
        action="store_true",
        help="If set, include non-Baseline_* models when --models is omitted.",
    )
    parser.add_argument(
        "--write-demo-csv",
        action="store_true",
        help="Write demo CSV files and exit.",
    )
    args = parser.parse_args()

    if args.write_demo_csv:
        save_demo_csvs(Path(__file__).resolve().parent)
        return

    if not args.overall_csv or not args.length_csv:
        raise ValueError("Please provide --overall-csv and --length-csv, or use --write-demo-csv")

    plot_4panel(
        overall_csv=Path(args.overall_csv).resolve(),
        length_csv=Path(args.length_csv).resolve(),
        output_path=Path(args.output).resolve(),
        model_order=args.models,
        baseline_only=not args.include_nonbaseline,
    )


if __name__ == "__main__":
    main()
