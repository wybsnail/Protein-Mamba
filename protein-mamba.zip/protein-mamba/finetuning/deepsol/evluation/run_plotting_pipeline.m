% MASTER SCRIPT: One-click plotting pipeline
% This script runs both the 4-panel metrics and 4-panel ROC/PRC curves.

% --- CONFIGURATION ---
overall_csv = 'deepsol_5methods_overall_test_updated_protbert3ep.csv';
length_csv = 'deepsol_5methods_length_test_updated_protbert3ep.csv';
mat_data_dir = 'mat_data'; % Directory containing exported .mat files

% --- STEP 1: Plot 4-Panel Metrics ---
if exist(overall_csv, 'file') && exist(length_csv, 'file')
    disp('Plotting 4-panel metrics comparison...');
    plot_deepsol_4panel(overall_csv, length_csv, 'deepsol_4panel_updated_protbert3ep.png');
else
    fprintf('Error: CSV files not found: %s or %s\n', overall_csv, length_csv);
end

% --- STEP 2: Plot 4-Panel ROC/PRC ---
% Only run if .mat files exist in mat_data
mat_files = dir(fullfile(mat_data_dir, 'Baseline_*_preds.mat'));
if ~isempty(mat_files)
    disp('Plotting 4-panel ROC/PRC curves...');
    plot_deepsol_roc_prc_4panel(mat_data_dir, 'deepsol_roc_prc_4panel_updated_protbert3ep.png');
else
    disp('Skipping ROC/PRC plots: No .mat prediction files found in mat_data.');
    disp('Note: To generate ROC/PRC plots, you must first run export_to_mat.py.');
end

disp('Pipeline execution finished.');
