function plot_deepsol_4panel(overall_csv, length_csv, output_path)
    % Replicate the 4-panel DeepSol metrics figure in MATLAB
    %
    % Usage:
    % plot_deepsol_4panel('overall_metrics.csv', 'length_metrics.csv', 'deepsol_4panel.png')

    if nargin < 3
        output_path = 'deepsol_4panel_matlab.png';
    end

    % Load Data
    overall = readtable(overall_csv, 'TextType', 'string');
    length_data = readtable(length_csv, 'TextType', 'string');

    % Define Models and Metrics
    models = sort(unique(overall.model));
    metric_cols = {'accuracy', 'auroc', 'auprc', 'f1', 'mcc', 'precision', 'recall'};
    metric_labels = {'ACCURACY', 'AUROC', 'AUPRC', 'F1', 'MCC', 'PRECISION', 'RECALL'};

    n_models = length(models);
    % High-Contrast Color Palette (D3 Category10)
    colors_hex = {'#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', ...
                  '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'};
    colors = zeros(10, 3);
    for k = 1:10
        hex = colors_hex{k};
        colors(k, :) = [hex2dec(hex(2:3)), hex2dec(hex(4:5)), hex2dec(hex(6:7))] / 255;
    end
    % If more than 10 models, cycle the colors
    model_colors = colors(mod(0:n_models-1, 10) + 1, :);

    % Setup Figure
    fig = figure('Position', [100, 100, 1100, 800], 'Visible', 'off');
    set(fig, 'DefaultAxesFontName', 'Times New Roman');
    set(fig, 'DefaultAxesFontSize', 10);

    % --- Panel A: Grouped Bar Chart ---
    subplot(2, 2, 1);
    hold on;
    
    data_matrix = zeros(n_models, length(metric_cols));
    for i = 1:n_models
        m_idx = strcmp(overall.model, models(i));
        for j = 1:length(metric_cols)
            if ismember(metric_cols{j}, overall.Properties.VariableNames)
                data_matrix(i, j) = overall.(metric_cols{j})(m_idx);
            end
        end
    end
    
    b = bar(data_matrix', 'grouped');
    for i = 1:n_models
        b(i).FaceColor = model_colors(i, :);
    end
    
    xticks(1:length(metric_labels));
    xticklabels(metric_labels);
    xtickangle(45);
    ylabel('Metric Value');
    ylim([0, max(data_matrix(:)) * 1.15]);
    legend(models, 'Interpreter', 'none', 'FontSize', 8, 'Location', 'northeast', 'NumColumns', 2);
    text(-0.1, 1.05, 'A', 'Units', 'normalized', 'FontSize', 22, 'FontWeight', 'bold');
    grid on;

    % --- Panels B, C, D: Length-binned plots ---
    metrics_to_plot = {'accuracy', 'auprc', 'precision'};
    panel_titles = {'Accuracy', 'AUPRC', 'Precision'};
    panel_labels = {'B', 'C', 'D'};
    
    % Define varied line styles and markers for better differentiation
    line_styles = {'-', '--', ':', '-.'};
    markers = {'o', 's', '^', 'd', 'v', '>', '<', 'p', 'h'};
    
    for p = 1:3
        subplot(2, 2, p+1);
        hold on;
        curr_metric = metrics_to_plot{p};
        
        for i = 1:n_models
            m_idx = strcmp(length_data.model, models(i));
            m_data = length_data(m_idx, :);
            
            % Sort by length bin for plotting
            [sorted_bins, sorted_indices] = sort(m_data.length_bin);
            plot_vals = m_data.(curr_metric)(sorted_indices);
            
            % Select style and marker cyclically
            ls = line_styles{mod(i-1, length(line_styles)) + 1};
            mk = markers{mod(i-1, length(markers)) + 1};
            
            plot(sorted_bins, plot_vals, ...
                 'LineStyle', ls, ...
                 'Marker', mk, ...
                 'MarkerSize', 4, ...
                 'MarkerFaceColor', model_colors(i, :), ...
                 'Color', model_colors(i, :), ...
                 'LineWidth', 2.0, ...
                 'DisplayName', char(models(i)));
        end
        
        xlabel('Length');
        ylabel(panel_titles{p});
        legend('show', 'Interpreter', 'none', 'FontSize', 8, 'Location', 'best', 'NumColumns', 2);
        text(-0.1, 1.05, panel_labels{p}, 'Units', 'normalized', 'FontSize', 22, 'FontWeight', 'bold');
        grid on;
    end

    % Save output
    saveas(fig, output_path);
    fprintf('Saved figure to: %s\n', output_path);
    close(fig);
end
