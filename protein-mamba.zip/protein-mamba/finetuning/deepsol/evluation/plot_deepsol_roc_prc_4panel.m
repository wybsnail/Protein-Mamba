function plot_deepsol_roc_prc_4panel(mat_data_dir, output_path)
    % Replicate the 4-panel ROC/PRC figure in MATLAB
    %
    % Usage:
    % plot_deepsol_roc_prc_4panel('mat_data', 'deepsol_roc_prc_4panel.png')

    if nargin < 2
        output_path = 'deepsol_roc_prc_4panel_matlab.png';
    end

    % Load Data from .mat files
    mat_files = dir(fullfile(mat_data_dir, '*_preds.mat'));
    if isempty(mat_files)
        error('No prediction .mat files found in %s', mat_data_dir);
    end

    % Extract model names and sort for consistency with 4panel plot
    model_names = cell(1, length(mat_files));
    for i = 1:length(mat_files)
        model_names{i} = strrep(mat_files(i).name, '_preds.mat', '');
    end
    model_names = sort(model_names);
    n_models = length(model_names);

    % High-Contrast Color Palette (D3 Category10)
    colors_hex = {'#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', ...
                  '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'};
    colors_mat = zeros(10, 3);
    for k = 1:10
        hex = colors_hex{k};
        colors_mat(k, :) = [hex2dec(hex(2:3)), hex2dec(hex(4:5)), hex2dec(hex(6:7))] / 255;
    end
    % Model colors (cycled)
    model_colors = colors_mat(mod(0:n_models-1, 10) + 1, :);

    % Setup Figure
    fig = figure('Position', [100, 100, 1300, 1000], 'Visible', 'off');
    set(fig, 'DefaultAxesFontName', 'Times New Roman');
    set(fig, 'DefaultAxesFontSize', 10);

    % Define subplots: (A: Val ROC, B: Val PRC, C: Test ROC, D: Test PRC)
    panel_labels = {'A', 'B', 'C', 'D'};
    splits = {'val', 'val', 'test', 'test'};
    curve_types = {'roc', 'prc', 'roc', 'prc'};
    
    line_styles = {'-', '--', ':', '-.'};
    markers = {'o', 's', '^', 'd', 'v', '>', '<', 'p', 'h'};

    for p = 1:4
        subplot(2, 2, p);
        hold on;
        split = splits{p};
        curve = curve_types{p};
        
        for i = 1:n_models
            model_name = model_names{i};
            data = load(fullfile(mat_data_dir, [model_name '_preds.mat']));
            
            y_true = double(data.([split '_y_true']));
            y_score = double(data.([split '_y_score']));
            
            % Select line style and marker cyclically
            ls = line_styles{mod(i-1, length(line_styles)) + 1};
            mk = markers{mod(i-1, length(markers)) + 1};
            
            if strcmp(curve, 'roc')
                [X, Y, T, AUC] = perfcurve(y_true, y_score, 1);
                idx_step = max(1, floor(length(X) / 15));
                m_indices = 1:idx_step:length(X);
                plot(X, Y, 'LineWidth', 2.0, 'LineStyle', ls, ...
                     'Marker', mk, 'MarkerSize', 4, 'MarkerFaceColor', model_colors(i, :), ...
                     'MarkerIndices', m_indices, 'Color', model_colors(i, :), ...
                     'DisplayName', sprintf('%s (AUC=%.3f)', model_name, AUC));
                xlabel('False Positive Rate');
                ylabel('True Positive Rate');
            else
                % Precision-Recall curve
                [X, Y, T, AUPRC] = perfcurve(y_true, y_score, 1, 'XCrit', 'reca', 'YCrit', 'prec');
                idx_step = max(1, floor(length(X) / 15));
                m_indices = 1:idx_step:length(X);
                plot(X, Y, 'LineWidth', 2.0, 'LineStyle', ls, ...
                     'Marker', mk, 'MarkerSize', 4, 'MarkerFaceColor', model_colors(i, :), ...
                     'MarkerIndices', m_indices, 'Color', model_colors(i, :), ...
                     'DisplayName', sprintf('%s (AUPRC=%.3f)', model_name, AUPRC));
                xlabel('Recall');
                ylabel('Precision');
            end
        end

        if strcmp(curve, 'roc')
            plot([0, 1], [0, 1], '--', 'Color', [0.5, 0.5, 0.5], 'LineWidth', 1.0);
        end
        
        xlim([0, 1]);
        ylim([0, 1.02]);
        grid on;
        legend('show', 'Interpreter', 'none', 'FontSize', 8, 'Location', 'best');
        text(-0.1, 1.05, panel_labels{p}, 'Units', 'normalized', 'FontSize', 28, 'FontWeight', 'bold');
    end

    % Save output
    saveas(fig, output_path);
    fprintf('Saved figure to: %s\n', output_path);
    close(fig);
end
