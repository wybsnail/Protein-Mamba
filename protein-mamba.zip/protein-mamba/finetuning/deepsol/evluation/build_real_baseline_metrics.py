from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Dict, List, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.utils import shuffle


def _flatten_labels(values) -> np.ndarray:
    arr = np.asarray(values)
    if arr.ndim > 1:
        arr = np.argmax(arr, axis=1)
    return arr.astype(int).reshape(-1)


def _load_trial0_preds(
    deepsol_dir: Path,
    include_singlechannel: bool = False,
) -> Dict[str, Tuple[np.ndarray, np.ndarray]]:
    model_data: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}

    model_dirs = [p for p in sorted(deepsol_dir.glob("Baseline_*")) if p.is_dir()]
    if include_singlechannel:
        single_dir = deepsol_dir / "SingleChannel"
        if single_dir.is_dir():
            model_dirs.append(single_dir)

    for model_dir in model_dirs:
        trial_dir = model_dir / "Trials" / "Trial_0"
        labels_path = trial_dir / "TestLabels.joblib"
        preds_path = trial_dir / "TestPreds.joblib"
        if not labels_path.exists() or not preds_path.exists():
            continue

        y_true = _flatten_labels(joblib.load(labels_path))
        y_pred = _flatten_labels(joblib.load(preds_path))
        if len(y_true) == 0 or len(y_pred) == 0 or len(y_true) != len(y_pred):
            continue

        model_data[model_dir.name] = (y_true, y_pred)
    return model_data


def _safe_auc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    if len(np.unique(y_true)) < 2:
        return float("nan")
    try:
        return float(roc_auc_score(y_true, y_score))
    except Exception:
        return float("nan")


def _safe_auprc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    if len(np.unique(y_true)) < 2:
        return float("nan")
    try:
        return float(average_precision_score(y_true, y_score))
    except Exception:
        return float("nan")


def _compute_overall_rows(model_data: Dict[str, Tuple[np.ndarray, np.ndarray]]) -> List[dict]:
    rows: List[dict] = []
    for model, (y_true, y_pred) in model_data.items():
        rows.append(
            {
                "model": model,
                "accuracy": float(accuracy_score(y_true, y_pred)),
                "auroc": _safe_auc(y_true, y_pred),
                "auprc": _safe_auprc(y_true, y_pred),
                "f1": float(f1_score(y_true, y_pred, zero_division=0)),
                "mcc": float(matthews_corrcoef(y_true, y_pred)),
                "precision": float(precision_score(y_true, y_pred, zero_division=0)),
                "recall": float(recall_score(y_true, y_pred, zero_division=0)),
            }
        )
    return rows


def _reconstruct_test_lengths(project_root: Path) -> np.ndarray:
    np.random.seed(42)
    deepsol_data_dir = project_root / "data" / "benchmark" / "deepsol"
    train_df = shuffle(pd.read_csv(deepsol_data_dir / "train.csv"))
    val_df = shuffle(pd.read_csv(deepsol_data_dir / "validation.csv"))
    _ = (train_df, val_df)
    test_df = shuffle(pd.read_csv(deepsol_data_dir / "test.csv"))

    if "aa_seq" not in test_df.columns:
        raise ValueError("test.csv must contain 'aa_seq' column")
    lengths = test_df["aa_seq"].astype(str).str.len().to_numpy()
    return lengths


def _build_length_bins(lengths: np.ndarray, n_bins: int) -> Tuple[np.ndarray, Dict[int, float]]:
    # Quantile bins to keep per-bin sample sizes balanced.
    bin_series = pd.qcut(lengths, q=n_bins, labels=False, duplicates="drop")
    bin_idx = np.asarray(bin_series, dtype=int)

    centers: Dict[int, float] = {}
    for b in sorted(np.unique(bin_idx)):
        centers[int(b)] = float(np.median(lengths[bin_idx == b]))
    return bin_idx, centers


def _compute_length_rows(
    model_data: Dict[str, Tuple[np.ndarray, np.ndarray]],
    lengths: np.ndarray,
    n_bins: int,
) -> List[dict]:
    bin_idx, centers = _build_length_bins(lengths, n_bins=n_bins)
    rows: List[dict] = []

    for model, (y_true, y_pred) in model_data.items():
        if len(y_true) != len(lengths):
            raise ValueError(
                f"Length mismatch for {model}: predictions={len(y_true)} vs test_lengths={len(lengths)}"
            )

        for b in sorted(centers.keys()):
            mask = bin_idx == b
            yt = y_true[mask]
            yp = y_pred[mask]
            if len(yt) == 0:
                continue

            rows.append(
                {
                    "model": model,
                    "length_bin": centers[b],
                    "accuracy": float(accuracy_score(yt, yp)),
                    "auprc": _safe_auprc(yt, yp),
                    "precision": float(precision_score(yt, yp, zero_division=0)),
                }
            )
    return rows


def _write_csv(path: Path, rows: List[dict], fieldnames: List[str]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(
        description="Build non-demo deepsol baseline overall/length metrics from Trial_0 Test joblib files."
    )
    parser.add_argument(
        "--deepsol-dir",
        type=str,
        default=str(Path(__file__).resolve().parents[1]),
        help="Path to finetuning/deepsol",
    )
    parser.add_argument(
        "--project-root",
        type=str,
        default=str(Path(__file__).resolve().parents[3]),
        help="Path to project root containing data/benchmark/deepsol/test.csv",
    )
    parser.add_argument(
        "--length-bins",
        type=int,
        default=11,
        help="Number of quantile bins for length metrics",
    )
    parser.add_argument(
        "--include-singlechannel",
        action="store_true",
        help="Include SingleChannel/Trials/Trial_0 TestLabels/TestPreds.joblib if present",
    )
    parser.add_argument(
        "--overall-out",
        type=str,
        default=str(Path(__file__).resolve().parent / "overall_metrics_real_trial0.csv"),
        help="Output overall metrics CSV",
    )
    parser.add_argument(
        "--length-out",
        type=str,
        default=str(Path(__file__).resolve().parent / "length_metrics_real_trial0.csv"),
        help="Output length metrics CSV",
    )
    args = parser.parse_args()

    deepsol_dir = Path(args.deepsol_dir).resolve()
    project_root = Path(args.project_root).resolve()

    model_data = _load_trial0_preds(
        deepsol_dir,
        include_singlechannel=args.include_singlechannel,
    )
    if not model_data:
        raise RuntimeError("No Baseline_*/Trials/Trial_0 TestLabels/TestPreds.joblib files found")

    lengths = _reconstruct_test_lengths(project_root)

    overall_rows = _compute_overall_rows(model_data)
    length_rows = _compute_length_rows(model_data, lengths=lengths, n_bins=args.length_bins)

    _write_csv(
        Path(args.overall_out).resolve(),
        overall_rows,
        ["model", "accuracy", "auroc", "auprc", "f1", "mcc", "precision", "recall"],
    )
    _write_csv(
        Path(args.length_out).resolve(),
        length_rows,
        ["model", "length_bin", "accuracy", "auprc", "precision"],
    )

    print(f"Models: {', '.join(sorted(model_data.keys()))}")
    print(f"Saved overall CSV: {Path(args.overall_out).resolve()}")
    print(f"Saved length CSV:  {Path(args.length_out).resolve()}")


if __name__ == "__main__":
    main()
