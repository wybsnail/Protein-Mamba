from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Iterable, Optional


def _flatten_labels(values) -> "np.ndarray":
    import numpy as np

    arr = np.asarray(values)
    if arr.ndim > 1:
        arr = np.argmax(arr, axis=1)
    return arr.astype(int).reshape(-1)


def _scores_from_preds(pred_values) -> "np.ndarray":
    """
    Convert saved prediction object to a score vector for ROC/PRC.

    Priority:
      - 2D probs/logits: use positive class score at index 1
      - 1D float scores: use directly
      - 1D labels: cast to float (degenerate but still valid)
    """
    import numpy as np

    arr = np.asarray(pred_values)
    if arr.ndim == 2:
        if arr.shape[1] >= 2:
            return arr[:, 1].astype(float)
        return arr[:, 0].astype(float)
    return arr.astype(float).reshape(-1)


def _pick_trial_dir(method_dir: Path) -> Optional[Path]:
    """
    Pick the best trial directory when possible.

    Order:
      1) use best_hyperparameters.joblib -> Trial_<best_trial_num>
      2) first trial dir that contains all required files
    """
    import joblib

    trials_root = method_dir / "Trials"
    if not trials_root.exists():
        return None

    best_params = method_dir / "best_hyperparameters.joblib"
    if best_params.exists():
        try:
            payload = joblib.load(best_params)
            trial_num = payload.get("best_trial_num", None)
            if trial_num is not None:
                candidate = trials_root / f"Trial_{trial_num}"
                if candidate.exists():
                    return candidate
        except Exception:
            pass

    for d in sorted(trials_root.glob("Trial_*")):
        if d.is_dir():
            return d
    return None


def _resolve_split_paths(run_dir: Path, split: str):
    if split == "val":
        label_prefix = "ValLabels"
        pred_prefix = "ValPreds"
    elif split == "test":
        label_prefix = "TestLabels"
        pred_prefix = "TestPreds"
    else:
        raise ValueError(f"Unsupported split: {split}")

    exact_label = run_dir / f"{label_prefix}.joblib"
    exact_pred = run_dir / f"{pred_prefix}.joblib"
    if exact_label.exists() and exact_pred.exists():
        return exact_label, exact_pred

    label_files = sorted(run_dir.glob(f"{label_prefix}*.joblib"))
    pred_files = sorted(run_dir.glob(f"{pred_prefix}*.joblib"))
    if not label_files or not pred_files:
        return None

    def _tail(path: Path, prefix: str) -> str:
        return path.name[len(prefix):]

    pred_map = {_tail(p, pred_prefix): p for p in pred_files}
    for label_path in sorted(label_files, key=lambda p: p.stat().st_mtime, reverse=True):
        matched_pred = pred_map.get(_tail(label_path, label_prefix))
        if matched_pred is not None:
            return label_path, matched_pred

    label_path = max(label_files, key=lambda p: p.stat().st_mtime)
    pred_path = max(pred_files, key=lambda p: p.stat().st_mtime)
    return label_path, pred_path


def _load_split_from_trial(trial_dir: Path, split: str):
    import joblib

    resolved = _resolve_split_paths(trial_dir, split)
    if resolved is None:
        return None

    labels_path, preds_path = resolved

    y_true = _flatten_labels(joblib.load(labels_path))
    y_score = _scores_from_preds(joblib.load(preds_path))
    if len(y_true) == 0 or len(y_score) == 0 or len(y_true) != len(y_score):
        return None
    return y_true, y_score


def _load_split_from_root(method_dir: Path, split: str):
    """Fallback loader for methods that saved labels/preds in method root instead of Trials/Trial_*"""
    return _load_split_from_trial(method_dir, split)


def collect_model_predictions(deepsol_dir: Path) -> Dict[str, Dict[str, tuple]]:
    """
    Return:
      {
        "Baseline_ProtBert": {"val": (y_true, y_score), "test": (...)},
        ...
      }
    """
    model_data: Dict[str, Dict[str, tuple]] = {}

    for method_dir in sorted(deepsol_dir.glob("Baseline_*")):
        if not method_dir.is_dir():
            continue

        trial_dir = _pick_trial_dir(method_dir)
        if trial_dir is not None:
            val_pack = _load_split_from_trial(trial_dir, "val")
            test_pack = _load_split_from_trial(trial_dir, "test")
        else:
            val_pack = _load_split_from_root(method_dir, "val")
            test_pack = _load_split_from_root(method_dir, "test")
        if val_pack is None and test_pack is None:
            continue

        model_data[method_dir.name] = {}
        if val_pack is not None:
            model_data[method_dir.name]["val"] = val_pack
        if test_pack is not None:
            model_data[method_dir.name]["test"] = test_pack

    return model_data


def collect_model_predictions_with_names(deepsol_dir: Path, model_names: Optional[Iterable[str]] = None) -> Dict[str, Dict[str, tuple]]:
    if not model_names:
        return collect_model_predictions(deepsol_dir)

    model_data: Dict[str, Dict[str, tuple]] = {}
    for model_name in model_names:
        method_dir = deepsol_dir / model_name
        if not method_dir.is_dir():
            continue

        trial_dir = _pick_trial_dir(method_dir)
        if trial_dir is not None:
            val_pack = _load_split_from_trial(trial_dir, "val")
            test_pack = _load_split_from_trial(trial_dir, "test")
        else:
            val_pack = _load_split_from_root(method_dir, "val")
            test_pack = _load_split_from_root(method_dir, "test")

        if val_pack is None and test_pack is None:
            continue

        model_data[model_name] = {}
        if val_pack is not None:
            model_data[model_name]["val"] = val_pack
        if test_pack is not None:
            model_data[model_name]["test"] = test_pack

    return model_data


def _plot_roc(ax, split_data: Dict[str, tuple], colors: Dict[str, tuple], panel_label: str):
    from sklearn.metrics import auc, roc_curve

    for model, (y_true, y_score) in split_data.items():
        if len(set(y_true.tolist())) < 2:
            continue
        fpr, tpr, _ = roc_curve(y_true, y_score)
        score = auc(fpr, tpr)
        ax.plot(fpr, tpr, linewidth=1.8, color=colors[model], label=f"{model} (AUC={score:.3f})")

    ax.plot([0, 1], [0, 1], linestyle="--", color="gray", linewidth=1.0, alpha=0.7)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.02)
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    ax.text(-0.16, 1.06, panel_label, transform=ax.transAxes, fontsize=28, fontweight="bold", va="top")


def _plot_prc(ax, split_data: Dict[str, tuple], colors: Dict[str, tuple], panel_label: str):
    from sklearn.metrics import average_precision_score, precision_recall_curve

    for model, (y_true, y_score) in split_data.items():
        if len(set(y_true.tolist())) < 2:
            continue
        precision, recall, _ = precision_recall_curve(y_true, y_score)
        auprc = average_precision_score(y_true, y_score)
        ax.plot(recall, precision, linewidth=1.8, color=colors[model], label=f"{model} (AUPRC={auprc:.3f})")

    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.02)
    ax.legend(frameon=False, fontsize=8, loc="lower left")
    ax.text(-0.16, 1.06, panel_label, transform=ax.transAxes, fontsize=28, fontweight="bold", va="top")


def plot_roc_prc_4panel(
    deepsol_dir: Path,
    output_path: Path,
    include_models: Optional[Iterable[str]] = None,
):
    import matplotlib.pyplot as plt

    model_data = collect_model_predictions_with_names(deepsol_dir, include_models)

    if len(model_data) == 0:
        raise RuntimeError("No baseline prediction files found. Run baseline finetuning first.")

    val_data = {m: d["val"] for m, d in model_data.items() if "val" in d}
    test_data = {m: d["test"] for m, d in model_data.items() if "test" in d}
    if len(val_data) == 0 or len(test_data) == 0:
        raise RuntimeError("Need both val and test prediction files to draw 4 panels.")

    # Keep deterministic model order.
    model_names = sorted(model_data.keys())
    cmap = plt.cm.get_cmap("tab10", max(len(model_names), 3))
    colors = {name: cmap(i) for i, name in enumerate(model_names)}

    plt.rcParams.update(
        {
            "font.family": "Times New Roman",
            "font.size": 10,
            "axes.linewidth": 0.8,
        }
    )

    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    fig.subplots_adjust(wspace=0.24, hspace=0.30, bottom=0.10)

    _plot_roc(axes[0, 0], val_data, colors, "A")
    _plot_prc(axes[0, 1], val_data, colors, "B")
    _plot_roc(axes[1, 0], test_data, colors, "C")
    _plot_prc(axes[1, 1], test_data, colors, "D")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=400, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved figure to: {output_path}")
    print(f"Models plotted: {', '.join(model_names)}")


def main():
    parser = argparse.ArgumentParser(description="Plot deepsol ROC/PRC 4-panel figure for all baselines.")
    parser.add_argument(
        "--deepsol-dir",
        type=str,
        default=str(Path(__file__).resolve().parents[1]),
        help="Path to finetuning/deepsol",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(Path(__file__).resolve().parent / "deepsol_roc_prc_4panel.png"),
        help="Output figure path",
    )
    parser.add_argument(
        "--models",
        type=str,
        nargs="*",
        default=None,
        help="Optional subset of Baseline_* names to include",
    )
    args = parser.parse_args()

    plot_roc_prc_4panel(
        deepsol_dir=Path(args.deepsol_dir).resolve(),
        output_path=Path(args.output).resolve(),
        include_models=args.models,
    )


if __name__ == "__main__":
    main()
