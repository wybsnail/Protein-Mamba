import os, shutil
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from sklearn.metrics import classification_report, f1_score
from transformers import AutoTokenizer
from sklearn.utils import shuffle
import utils, models
import optuna
import joblib
import time
import logging


def _env_int(name, default):
    v = os.getenv(name)
    if v is None:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def _env_float(name, default):
    v = os.getenv(name)
    if v is None:
        return default
    try:
        return float(v)
    except ValueError:
        return default

def save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name):
    shutil_dir = trials_dir + 'Trial_' + str(parameter_dictionary['trial_num']) + '/'
    try: os.mkdir(shutil_dir)
    except: pass 
    shutil.move(outmodel_name, shutil_dir)
    shutil.move(val_label_name, shutil_dir)
    shutil.move(val_pred_name, shutil_dir)
    shutil.move(test_label_name, shutil_dir)
    shutil.move(test_pred_name, shutil_dir)

def eval_model(parameter_dictionary, model, device, trial_num, epoch, set_flag):
    t0 = time.time()
    tmp_params =  {'batch_size': parameter_dictionary['batch_size'], 'shuffle': False, 'num_workers': 4, 'pin_memory': True}
    tmp_loader = DataLoader(validation_set, **tmp_params) if set_flag == 'Validation' else DataLoader(testing_set, **tmp_params)
    len_tmp_dataloader = len(tmp_loader)
    tmp_loss_accumulator = 0
    model.eval()
    epoch_tmp_preds = []
    epoch_tmp_labels = []

    with torch.no_grad():
        for tmp_data_idx, tmp_data in enumerate(tmp_loader):
            tmp_percent_done = (((tmp_data_idx + 1) / len_tmp_dataloader) * 100)
            tmp_ids = tmp_data['input_ids'].to(device, dtype=torch.long)
            tmp_mask = tmp_data['attention_mask'].to(device, dtype=torch.long)
            tmp_labels = tmp_data['labels'].to(device)
            
            tmp_outputs = model(tmp_ids, tmp_mask)

            tmp_loss, tmp_pred, tmp_truth = utils.loss_fn_multi_class(tmp_outputs, tmp_labels, positive_weightings.to(device) if positive_weightings is not None else None)
            tmp_loss_accumulator += tmp_loss.item()
            epoch_tmp_preds.extend(tmp_pred)
            epoch_tmp_labels.extend(tmp_truth)
            t_delta = time.time() - t0
            print(f'Trial: {trial_num}, {set_flag}: Epoch: {epoch}, Loss: {tmp_loss.item():.16f}, % Done: {tmp_percent_done:.5f}, Time Elapsed: {t_delta:.5f}')

    average_tmp_loss = np.round(tmp_loss_accumulator / len_tmp_dataloader, 8)
    return average_tmp_loss, epoch_tmp_labels, epoch_tmp_preds

def train_model(parameter_dictionary):
    trial_num = parameter_dictionary['trial_num']
    study_best = 0 if trial_num <= number_jobs else study.best_trial.values[0]
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    train_params = {'batch_size': parameter_dictionary['batch_size'], 'shuffle': True, 'num_workers': 4, 'pin_memory': True}
    training_loader = DataLoader(training_set, **train_params)
    len_training_dataloader = len(training_loader)

    model = models.BaselineSequenceClassificationLora(parameter_dictionary).bfloat16().to(device)
    optimizer = torch.optim.AdamW(params=model.parameters(), lr=parameter_dictionary['learning_rate'], fused=True)
    
    current_val_metric = -99999
    outmodel_name = f'deepsol_ProtT5_{trial_num}_{RUN_TS}.pt'
    val_label_name = f'ValLabels_{trial_num}_{RUN_TS}.joblib'
    val_pred_name = f'ValPreds_{trial_num}_{RUN_TS}.joblib'
    test_label_name = f'TestLabels_{trial_num}_{RUN_TS}.joblib'
    test_pred_name = f'TestPreds_{trial_num}_{RUN_TS}.joblib'

    grad_accum_steps = parameter_dictionary['grad_accum_steps']
    patience_counter = 0
    patience = 15

    t0 = time.time()
    for epoch in range(parameter_dictionary['epochs']):
        epoch_train_preds = []
        epoch_train_labels = []
        model.train()
        train_loss_accumulator = 0
        optimizer.zero_grad()
        for train_data_idx, train_data in enumerate(training_loader):
            training_percent_done = (((train_data_idx + 1) / len_training_dataloader) * 100)
            train_ids = train_data['input_ids'].to(device, dtype=torch.long)
            train_mask = train_data['attention_mask'].to(device, dtype=torch.long)
            train_labels = train_data['labels'].to(device)

            train_outputs = model(train_ids, train_mask)
                
            train_loss, train_pred, train_truth = utils.loss_fn_multi_class(train_outputs, train_labels, positive_weightings.to(device) if positive_weightings is not None else None)
            train_loss_accumulator += train_loss.item()
            train_loss.backward()

            epoch_train_preds.extend(train_pred)
            epoch_train_labels.extend(train_truth)
            t_delta = time.time() - t0
            print(f'Trial: {trial_num}, Training: Epoch: {epoch}, Loss: {train_loss.item():.16f}, % Done: {training_percent_done:.5f}, Time Elapsed: {t_delta:.5f}')

            if (train_data_idx + 1) % grad_accum_steps == 0 or (train_data_idx + 1) == len(training_loader):
                optimizer.step()
                optimizer.zero_grad()

            if (train_data_idx + 1) == len_training_dataloader:
                average_train_loss = np.round(train_loss_accumulator / (train_data_idx + 1), 8)
                average_val_loss, epoch_val_labels, epoch_val_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, "Validation")
                
                new_val_metric = f1_score(epoch_val_labels, epoch_val_preds, average='macro')
               
                if new_val_metric >= current_val_metric:
                    current_val_metric = new_val_metric
                    patience_counter = 0
                    torch.save(model.state_dict(), outmodel_name)
                    joblib.dump(epoch_val_labels, val_label_name)
                    joblib.dump(epoch_val_preds, val_pred_name)
                else:
                    patience_counter += 1

                print('Validation Metric: ' + str(new_val_metric))
                print('Patience = ' + str(patience_counter))
                
                if patience_counter != patience:
                    model.train()
                else:
                    if current_val_metric >= study_best:
                        average_test_loss, epoch_test_labels, epoch_test_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, 'Testing')
                        joblib.dump(epoch_test_labels, test_label_name)
                        joblib.dump(epoch_test_preds, test_pred_name)
                        save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name)
                    else:
                        os.remove(outmodel_name)
                        os.remove(val_label_name)
                        os.remove(val_pred_name)
                    model.to('cpu')
                    del model
                    torch.cuda.empty_cache()
                    return current_val_metric
        
    average_test_loss, epoch_test_labels, epoch_test_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, 'Testing')
    joblib.dump(epoch_test_labels, test_label_name)
    joblib.dump(epoch_test_preds, test_pred_name)
    save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name)
    model.to('cpu')
    del model
    torch.cuda.empty_cache()
    return current_val_metric

def objective(trial):
    torch.cuda.empty_cache()
    utils.seed_everything(seed)
    trial_num = trial.number

    cfg_epochs = _env_int('PROTT5_EPOCHS', 2)
    cfg_batch = _env_int('PROTT5_BATCH_SIZE', 2)
    cfg_grad_accum = _env_int('PROTT5_GRAD_ACCUM', 16)
    cfg_dropout = _env_float('PROTT5_DROPOUT', 0.21236203565420878)
    cfg_lr = _env_float('PROTT5_LR', 0.000951207163345817)
    cfg_lora_rank = _env_int('PROTT5_LORA_RANK', 7)
    
    if trial_num != 0:
        best_params = study.best_trial.params
        best_params['best_trial_num'] = study.best_trial.number
        joblib.dump(best_params, 'best_hyperparameters.joblib')
        study.trials_dataframe().to_csv('optuna_data.csv', index=False)
        joblib.dump(study, 'optuna_study.joblib')

    parameters = {
            'pretrained_model_path' : os.path.abspath(os.path.join(os.path.dirname(__file__), "../../..", "model", "prot_t5_xl_uniref50")).replace("\\", "/"),
            'in_shape' : MAX_LEN,
            'out_shape' : N_LABELS,
            'epochs' : cfg_epochs,
            'batch_size' : trial.suggest_int('batch_size', cfg_batch, cfg_batch, step=1),
            'grad_accum_steps' : trial.suggest_int('grad_accum_steps', cfg_grad_accum, cfg_grad_accum, step=1),
            'dropout_weight' : trial.suggest_float('dropout_weight', cfg_dropout, cfg_dropout, log=False),
            'learning_rate' : trial.suggest_float('learning_rate', cfg_lr, cfg_lr, log=False),
            'trial_num' : trial_num,
            'lora_rank' : trial.suggest_int('lora_rank', cfg_lora_rank, cfg_lora_rank, step=1),
            'lora_scaling_rank' : 1,
            'lora_init_scale' : 0.01,
            'lora_modules' : '.*encoder.*layer.*|.*encoder.*block.*',
            'lora_layers' : 'query|key|value|dense|q|k|v|o|wi_0|wi_1|wo',
            'lora_trainable_param_names' : '.*norm.*|.*lora_[ab].*'
            }
    trial_metric = train_model(parameters)
    torch.cuda.empty_cache()
    return trial_metric

if __name__ == '__main__':
    global cwd, seed, trials_dir, tokenizer, training_set, validation_set, testing_set, positive_weightings
    global MAX_LEN, N_LABELS, study, number_jobs, RUN_TS
    cwd = os.getcwd() + '/'
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
    model_path = os.path.join(project_root, "model", "prot_t5_xl_uniref50").replace("\\", "/")
    train_csv = os.path.join(project_root, "data", "benchmark", "deepsol", "train.csv")
    val_csv = os.path.join(project_root, "data", "benchmark", "deepsol", "validation.csv")
    test_csv = os.path.join(project_root, "data", "benchmark", "deepsol", "test.csv")
    seed = 42
    RUN_TS = time.strftime("%Y%m%d-%H%M%S")

    utils.seed_everything(seed)
    utils.set_global_logging_level(logging.ERROR, ["transformers", "nlp", "torch", "tensorflow", "tensorboard", "wandb"])
    trials_dir = utils.setup_trials_dir(cwd)

    MAX_LEN = _env_int('PROTT5_MAX_LEN', 768)
    N_LABELS = 2

    tokenizer = AutoTokenizer.from_pretrained(model_path, use_fast=False, local_files_only=True)
    
    train_df = shuffle(pd.read_csv(train_csv))
    val_df = shuffle(pd.read_csv(val_csv))
    test_df = shuffle(pd.read_csv(test_csv))
    

    training_set = models.BaselineDataset(train_df, tokenizer, MAX_LEN, 'aa_seq', 'label', N_LABELS, True)
    validation_set = models.BaselineDataset(val_df, tokenizer, MAX_LEN, 'aa_seq', 'label', N_LABELS, True)
    testing_set = models.BaselineDataset(test_df, tokenizer, MAX_LEN, 'aa_seq', 'label', N_LABELS, True)

    positive_weightings = None

    number_trials = _env_int('PROTT5_NUM_TRIALS', 1)
    number_jobs = _env_int('PROTT5_NUM_JOBS', 1)

    study = optuna.create_study(direction='maximize',sampler=optuna.samplers.TPESampler(seed=seed))
    study.optimize(objective, n_trials=number_trials, n_jobs=number_jobs, show_progress_bar=True)
