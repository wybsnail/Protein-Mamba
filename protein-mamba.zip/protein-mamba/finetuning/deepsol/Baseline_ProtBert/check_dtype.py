import torch
import os
import sys
import pandas as pd
from transformers import AutoTokenizer

# Mock parameters
sys.path.append(os.getcwd())
import models

# Construct path carefully as in train_baseline.py
pretrained_path = os.path.abspath(os.path.join(os.getcwd(), "../../..", "model", "prot_bert")).replace("\\", "/")

params = {
    'pretrained_model_path': pretrained_path,
    'out_shape': 2,
    'dropout_weight': 0.1,
    'lora_rank': 4,
    'lora_scaling_rank': 1,
    'lora_init_scale': 0.01,
    'lora_modules': '.*weight.*', # Broad match for test
    'lora_layers': '.*',
    'lora_trainable_param_names': '.*lora.*'
}

try:
    model = models.BaselineSequenceClassificationLora(params)
    print("Model created successfully.")
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")
    model.to(device)

    # Get vocab size from model
    vocab_size = model.encoder.config.vocab_size
    print(f"Vocab size: {vocab_size}")

    # Check encoder dtype
    enc_param = next(model.encoder.parameters())
    print(f"Encoder parameter dtype: {enc_param.dtype}")
    
    # Check head dtype
    l1_param = model.l1.weight
    print(f"L1 weight dtype: {l1_param.dtype}")
    
    # Check LoRA dtype if any
    for name, module in model.encoder.named_modules():
        if isinstance(module, models.LoRALinear):
            print(f"LoRA module {name} weight dtype: {module.weight.dtype}")
            print(f"LoRA module {name} lora_a dtype: {module.lora_a.dtype}")
            break
            
    # Test forward pass
    ids = torch.randint(0, vocab_size, (1, 10)).to(device)
    mask = torch.ones((1, 10), dtype=torch.long).to(device)
    
    with torch.no_grad():
        output = model.encoder(ids, mask)
        hidden = output.last_hidden_state
        print(f"Encoder output dtype: {hidden.dtype}")
        
        logits = model(ids, mask)
        print(f"Final logits dtype: {logits.dtype}")

except Exception as e:
    import traceback
    print(traceback.format_exc())
