import os
import time
import logging

import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import f1_score, classification_report
from sklearn.utils import shuffle
from torch.utils.data import DataLoader
from transformers import AutoTokenizer

import utils
import models


def evaluate(model, loader, device):
    model.eval()
    loss_acc = 0.0
    preds = []
    labels = []
    with torch.no_grad():
        for batch in loader:
            ids = batch["input_ids"].to(device, dtype=torch.long)
            mask = batch["attention_mask"].to(device, dtype=torch.long)
            y = batch["labels"].to(device)

            outputs = model(ids, mask)
            loss, pred, truth = utils.loss_fn_multi_class(outputs, y, None)
            loss_acc += loss.item()
            preds.extend(pred)
            labels.extend(truth)

    return float(loss_acc / max(len(loader), 1)), labels, preds


def main():
    cwd = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(cwd, "../../.."))

    model_path = os.path.join(project_root, "model", "prot_bert")
    train_csv = os.path.join(project_root, "data", "benchmark", "deepsol", "train.csv")
    val_csv = os.path.join(project_root, "data", "benchmark", "deepsol", "validation.csv")
    test_csv = os.path.join(project_root, "data", "benchmark", "deepsol", "test.csv")

    base_ckpt = os.path.join(cwd, "deepsol_ProtBert_0.pt")
    if not os.path.exists(base_ckpt):
        raise FileNotFoundError(f"Base finetuned checkpoint not found: {base_ckpt}")

    seed = 42
    utils.seed_everything(seed)
    utils.set_global_logging_level(logging.ERROR, ["transformers", "torch", "tensorflow", "wandb"])

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    run_ts = time.strftime("%Y%m%d-%H%M%S")

    hyper = {
        "pretrained_model_path": model_path,
        "in_shape": 768,
        "out_shape": 2,
        "epochs": 3,
        "batch_size": 2,
        "grad_accum_steps": 16,
        "dropout_weight": 0.2,
        "learning_rate": 5e-5,
        "trial_num": 0,
        "lora_rank": 7,
        "lora_scaling_rank": 1,
        "lora_init_scale": 0.01,
        "lora_modules": ".*encoder.*layer.*|.*encoder.*block.*",
        "lora_layers": "query|key|value|dense|q|k|v|o|wi_0|wi_1|wo",
        "lora_trainable_param_names": ".*norm.*|.*lora_[ab].*",
    }

    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)

    train_df = shuffle(pd.read_csv(train_csv), random_state=seed)
    val_df = shuffle(pd.read_csv(val_csv), random_state=seed)
    test_df = shuffle(pd.read_csv(test_csv), random_state=seed)

    train_set = models.BaselineDataset(train_df, tokenizer, 768, "aa_seq", "label", 2, True)
    val_set = models.BaselineDataset(val_df, tokenizer, 768, "aa_seq", "label", 2, True)
    test_set = models.BaselineDataset(test_df, tokenizer, 768, "aa_seq", "label", 2, True)

    train_loader = DataLoader(train_set, batch_size=hyper["batch_size"], shuffle=True, num_workers=4, pin_memory=True)
    val_loader = DataLoader(val_set, batch_size=hyper["batch_size"], shuffle=False, num_workers=4, pin_memory=True)
    test_loader = DataLoader(test_set, batch_size=hyper["batch_size"], shuffle=False, num_workers=4, pin_memory=True)

    model = models.BaselineSequenceClassificationLora(hyper).bfloat16().to(device)
    state = torch.load(base_ckpt, map_location=device, weights_only=True)
    model.load_state_dict(state, strict=True)

    optimizer = torch.optim.AdamW(
        params=model.parameters(),
        lr=hyper["learning_rate"],
        fused=torch.cuda.is_available(),
    )

    out_dir = os.path.join(cwd, "Trials", f"Trial_continue_3ep_{run_ts}")
    os.makedirs(out_dir, exist_ok=True)

    best_val_f1 = -1.0
    best_path = os.path.join(out_dir, f"deepsol_ProtBert_continue3ep_best_{run_ts}.pt")

    print(f"Continue finetuning from: {base_ckpt}")
    print(f"Device: {device}")
    print(f"Output dir: {out_dir}")

    for epoch in range(hyper["epochs"]):
        model.train()
        optimizer.zero_grad()
        running_loss = 0.0

        for step, batch in enumerate(train_loader, start=1):
            ids = batch["input_ids"].to(device, dtype=torch.long)
            mask = batch["attention_mask"].to(device, dtype=torch.long)
            y = batch["labels"].to(device)

            outputs = model(ids, mask)
            loss, _, _ = utils.loss_fn_multi_class(outputs, y, None)
            loss.backward()
            running_loss += loss.item()

            if step % hyper["grad_accum_steps"] == 0 or step == len(train_loader):
                optimizer.step()
                optimizer.zero_grad()

        train_loss = float(running_loss / max(len(train_loader), 1))
        val_loss, val_labels, val_preds = evaluate(model, val_loader, device)
        val_f1 = float(f1_score(val_labels, val_preds, average="macro"))

        print(f"Epoch {epoch+1}/{hyper['epochs']} | train_loss={train_loss:.6f} val_loss={val_loss:.6f} val_macro_f1={val_f1:.6f}")

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            torch.save(model.state_dict(), best_path)
            joblib.dump(val_labels, os.path.join(out_dir, "ValLabels.joblib"))
            joblib.dump(val_preds, os.path.join(out_dir, "ValPreds.joblib"))

    best_state = torch.load(best_path, map_location=device, weights_only=True)
    model.load_state_dict(best_state, strict=True)

    test_loss, test_labels, test_preds = evaluate(model, test_loader, device)
    test_f1 = float(f1_score(test_labels, test_preds, average="macro"))
    joblib.dump(test_labels, os.path.join(out_dir, "TestLabels.joblib"))
    joblib.dump(test_preds, os.path.join(out_dir, "TestPreds.joblib"))

    print(f"Best val macro F1: {best_val_f1:.6f}")
    print(f"Test loss: {test_loss:.6f} | Test macro F1: {test_f1:.6f}")
    print("Test classification report:")
    print(classification_report(test_labels, test_preds))
    print(f"Saved best checkpoint: {best_path}")


if __name__ == "__main__":
    main()
