import logging
import os
import shutil
import time
from pathlib import Path

import joblib
import numpy as np
import optuna
import pandas as pd
import torch
from sklearn.metrics import f1_score
from sklearn.utils import shuffle
from torch.utils.data import DataLoader

import models
import utils


def resolve_deepsol_dir(project_root: Path) -> Path:
    upper = project_root / "Data" / "benchmark" / "deepsol"
    lower = project_root / "data" / "benchmark" / "deepsol"
    if upper.exists():
        return upper
    if lower.exists():
        return lower
    raise FileNotFoundError("Cannot find deepsol dataset under Data/benchmark or data/benchmark")


def safe_remove(path: str):
    if os.path.exists(path):
        os.remove(path)


def save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name):
    shutil_dir = trials_dir + "Trial_" + str(parameter_dictionary["trial_num"]) + "/"
    os.makedirs(shutil_dir, exist_ok=True)
    shutil.move(outmodel_name, shutil_dir)
    shutil.move(val_label_name, shutil_dir)
    shutil.move(val_pred_name, shutil_dir)
    shutil.move(test_label_name, shutil_dir)
    shutil.move(test_pred_name, shutil_dir)


def eval_model(parameter_dictionary, model, device, trial_num, epoch, set_flag):
    t0 = time.time()
    tmp_params = {"batch_size": parameter_dictionary["batch_size"], "shuffle": False, "num_workers": 0}
    tmp_loader = (
        DataLoader(validation_set, **tmp_params)
        if set_flag == "Validation"
        else DataLoader(testing_set, **tmp_params)
    )
    len_tmp_dataloader = len(tmp_loader)
    tmp_loss_accumulator = 0.0
    model.eval()

    epoch_tmp_preds = []
    epoch_tmp_labels = []

    with torch.no_grad():
        for tmp_data_idx, tmp_data in enumerate(tmp_loader):
            tmp_percent_done = ((tmp_data_idx + 1) / len_tmp_dataloader) * 100
            tmp_ids = tmp_data["input_ids"].to(device, dtype=torch.long)
            tmp_mask = tmp_data["attention_mask"].to(device, dtype=torch.long)
            tmp_labels = tmp_data["labels"].to(device, dtype=torch.long)

            tmp_outputs = model(tmp_ids, tmp_mask)
            tmp_loss, tmp_pred, tmp_truth = utils.loss_fn_multi_class(
                tmp_outputs,
                tmp_labels,
                class_weights=class_weights,
            )
            tmp_loss_accumulator += tmp_loss.item()
            epoch_tmp_preds.extend(tmp_pred)
            epoch_tmp_labels.extend(tmp_truth)

            t_delta = time.time() - t0
            print(
                f"Trial: {trial_num}, {set_flag}: Epoch: {epoch}, Loss: {tmp_loss.item():.6f}, "
                f"% Done: {tmp_percent_done:.2f}, Time Elapsed: {t_delta:.2f}"
            )

    average_tmp_loss = np.round(tmp_loss_accumulator / max(len_tmp_dataloader, 1), 8)
    return average_tmp_loss, epoch_tmp_labels, epoch_tmp_preds


def train_model(parameter_dictionary):
    trial_num = parameter_dictionary["trial_num"]
    study_best = 0.0 if trial_num <= number_jobs else study.best_trial.values[0]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_params = {"batch_size": parameter_dictionary["batch_size"], "shuffle": True, "num_workers": 0}
    training_loader = DataLoader(training_set, **train_params)
    len_training_dataloader = len(training_loader)

    model = models.ResNetSequenceClassifier(
        parameter_dictionary,
        vocab_size=tokenizer.vocab_size,
        pad_token_id=tokenizer.pad_token_id,
    ).to(device)
    optimizer = torch.optim.AdamW(
        params=model.parameters(),
        lr=parameter_dictionary["learning_rate"],
        weight_decay=parameter_dictionary["weight_decay"],
    )

    current_val_metric = -1.0
    outmodel_name = "deepsol_resnet_" + str(trial_num) + ".pt"
    val_label_name = "ValLabels.joblib"
    val_pred_name = "ValPreds.joblib"
    test_label_name = "TestLabels.joblib"
    test_pred_name = "TestPreds.joblib"

    grad_accum_steps = parameter_dictionary["grad_accum_steps"]
    patience_counter = 0
    patience = parameter_dictionary["patience"]

    t0 = time.time()
    for epoch in range(parameter_dictionary["epochs"]):
        model.train()
        train_loss_accumulator = 0.0
        optimizer.zero_grad()

        for train_data_idx, train_data in enumerate(training_loader):
            training_percent_done = ((train_data_idx + 1) / len_training_dataloader) * 100
            train_ids = train_data["input_ids"].to(device, dtype=torch.long)
            train_mask = train_data["attention_mask"].to(device, dtype=torch.long)
            train_labels = train_data["labels"].to(device, dtype=torch.long)

            train_outputs = model(train_ids, train_mask)
            train_loss, _, _ = utils.loss_fn_multi_class(train_outputs, train_labels, class_weights=class_weights)
            train_loss_accumulator += train_loss.item()
            train_loss.backward()

            t_delta = time.time() - t0
            print(
                f"Trial: {trial_num}, Training: Epoch: {epoch}, Loss: {train_loss.item():.6f}, "
                f"% Done: {training_percent_done:.2f}, Time Elapsed: {t_delta:.2f}"
            )

            if (train_data_idx + 1) % grad_accum_steps == 0 or (train_data_idx + 1) == len_training_dataloader:
                optimizer.step()
                optimizer.zero_grad()

            if (train_data_idx + 1) in {int(np.floor(len_training_dataloader / 2)), len_training_dataloader}:
                average_train_loss = np.round(train_loss_accumulator / (train_data_idx + 1), 8)
                average_val_loss, epoch_val_labels, epoch_val_preds = eval_model(
                    parameter_dictionary,
                    model,
                    device,
                    trial_num,
                    epoch,
                    "Validation",
                )

                new_val_metric = f1_score(epoch_val_labels, epoch_val_preds, average="macro")

                if new_val_metric >= current_val_metric:
                    current_val_metric = new_val_metric
                    patience_counter = 0
                    torch.save(model.state_dict(), outmodel_name)
                    joblib.dump(epoch_val_labels, val_label_name)
                    joblib.dump(epoch_val_preds, val_pred_name)
                else:
                    patience_counter += 1

                print(
                    f"Average train loss: {average_train_loss} | "
                    f"Average val loss: {average_val_loss} | "
                    f"Val macro F1: {new_val_metric:.5f} | Patience: {patience_counter}/{patience}"
                )

                if patience_counter >= patience:
                    if current_val_metric >= study_best and os.path.exists(outmodel_name):
                        _, epoch_test_labels, epoch_test_preds = eval_model(
                            parameter_dictionary,
                            model,
                            device,
                            trial_num,
                            epoch,
                            "Testing",
                        )
                        joblib.dump(epoch_test_labels, test_label_name)
                        joblib.dump(epoch_test_preds, test_pred_name)
                        save_model(
                            parameter_dictionary,
                            outmodel_name,
                            val_label_name,
                            val_pred_name,
                            test_label_name,
                            test_pred_name,
                        )
                    else:
                        safe_remove(outmodel_name)
                        safe_remove(val_label_name)
                        safe_remove(val_pred_name)

                    model.to("cpu")
                    del model
                    torch.cuda.empty_cache()
                    return current_val_metric
                else:
                    model.train()

    if os.path.exists(outmodel_name):
        _, epoch_test_labels, epoch_test_preds = eval_model(
            parameter_dictionary,
            model,
            device,
            trial_num,
            parameter_dictionary["epochs"] - 1,
            "Testing",
        )
        joblib.dump(epoch_test_labels, test_label_name)
        joblib.dump(epoch_test_preds, test_pred_name)
        save_model(
            parameter_dictionary,
            outmodel_name,
            val_label_name,
            val_pred_name,
            test_label_name,
            test_pred_name,
        )

    model.to("cpu")
    del model
    torch.cuda.empty_cache()
    return current_val_metric


def objective(trial):
    torch.cuda.empty_cache()
    utils.seed_everything(seed)
    trial_num = trial.number

    if trial_num != 0:
        best_params = study.best_trial.params
        best_params["best_trial_num"] = study.best_trial.number
        joblib.dump(best_params, "best_hyperparameters.joblib")
        study.trials_dataframe().to_csv("optuna_data.csv", index=False)
        joblib.dump(study, "optuna_study.joblib")

    parameters = {
        "out_shape": N_LABELS,
        "epochs": EPOCHS,
        "batch_size": trial.suggest_int("batch_size", 16, 64, step=16),
        "grad_accum_steps": trial.suggest_int("grad_accum_steps", 1, 4),
        "learning_rate": trial.suggest_float("learning_rate", 1e-4, 3e-3, log=True),
        "weight_decay": trial.suggest_float("weight_decay", 1e-6, 1e-2, log=True),
        # Architecture fixed to the baseline spec
        "embedding_dim": 100,
        "patience": PATIENCE,
        "trial_num": trial_num,
    }
    return train_model(parameters)


if __name__ == "__main__":
    global cwd, seed, trials_dir, tokenizer, training_set, validation_set, testing_set, class_weights
    global MAX_LEN, N_LABELS, study, number_jobs, EPOCHS, PATIENCE

    cwd = os.getcwd() + "/"
    seed = 42
    MAX_LEN = 1700
    N_LABELS = 2
    EPOCHS = 30
    PATIENCE = 6

    utils.seed_everything(seed)
    utils.set_global_logging_level(logging.ERROR, ("transformers", "torch", "tensorflow", "wandb"))
    trials_dir = utils.setup_trials_dir(cwd)

    project_root = Path(__file__).resolve().parents[3]
    data_dir = resolve_deepsol_dir(project_root)

    tokenizer = models.ProteinTokenizer()

    train_df = shuffle(pd.read_csv(data_dir / "train.csv")).reset_index(drop=True)
    val_df = shuffle(pd.read_csv(data_dir / "validation.csv")).reset_index(drop=True)
    test_df = shuffle(pd.read_csv(data_dir / "test.csv")).reset_index(drop=True)

    training_set = models.BaselineDataset(train_df, tokenizer, MAX_LEN, "aa_seq", "label")
    validation_set = models.BaselineDataset(val_df, tokenizer, MAX_LEN, "aa_seq", "label")
    testing_set = models.BaselineDataset(test_df, tokenizer, MAX_LEN, "aa_seq", "label")
    class_weights = utils.get_class_weights(train_df, N_LABELS, "label")

    number_trials = 1
    number_jobs = 1

    study = optuna.create_study(
        study_name="deepsol_resnet",
        direction="maximize",
        sampler=optuna.samplers.TPESampler(seed=seed),
    )
    study.optimize(objective, n_trials=number_trials, n_jobs=number_jobs, show_progress_bar=True)

    best_params = study.best_trial.params
    best_params["best_trial_num"] = study.best_trial.number
    joblib.dump(best_params, "best_hyperparameters.joblib")
    study.trials_dataframe().to_csv("optuna_data.csv", index=False)
    joblib.dump(study, "optuna_study.joblib")
