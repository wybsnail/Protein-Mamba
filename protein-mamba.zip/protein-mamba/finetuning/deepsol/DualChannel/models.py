import re
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
import torch.nn.init as initialization_strategy
import joblib
import utils
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from tokenizer import ProteinTokenizer
from pretrain.protein_lm.modeling.models.mamba.lm import MambaLMHeadModel
from pretrain.protein_lm.modeling.models.mamba.config_mamba import MambaConfig

utils.seed_everything()
device = 'cuda'

class PerSequenceClassificationLoraDataset(Dataset):

    def __init__(self, dataframe, tokenizer, max_len, seqname, labelname, n_labels):
        self.tokenizer = tokenizer
        self.dataframe = dataframe.copy()
        self.sequences = self.dataframe[seqname]
        self.labels = self.dataframe[labelname]
        self.max_len = max_len
        self.seqname = seqname
        self.n_labels = n_labels

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, index):
        sequence = self.sequences[index]
        label = self.labels[index]
        # In dual channel, we would use ESMScorer if we don't have cached data yet.
        # For now, pass None to generate dummy cons_ids or read from pre-cached files if added.
        ids, cons_ids = self.tokenizer.encode(sequence, cons_scores=None)
        if len(ids) > self.max_len:
            ids = ids[:self.max_len]
            cons_ids = cons_ids[:self.max_len]
        mask_len = len(ids)
        if len(ids) < self.max_len:
            ids = ids + [self.tokenizer.pad_token_id] * (self.max_len - len(ids))
            cons_ids = cons_ids + [self.tokenizer.vocab["[PAD]"]] * (self.max_len - len(cons_ids))
        mask = [1] * mask_len + [0] * (self.max_len - mask_len)
        return {'input_ids': torch.tensor(ids, dtype=torch.int), 'cons_ids': torch.tensor(cons_ids, dtype=torch.int), 'attention_mask': torch.tensor(mask, dtype=torch.int), 'labels': torch.tensor(label, dtype=torch.bfloat16)}


class LoRALinear(nn.Module):
    def __init__(self, linear_layer, rank, scaling_rank, init_scale):
        super().__init__()

        self.in_features = linear_layer.in_features
        self.out_features = linear_layer.out_features
        self.rank = rank
        self.scaling_rank = scaling_rank
        self.weight = linear_layer.weight
        self.bias = linear_layer.bias
        
        self.lora_a = nn.Parameter(torch.randn(rank, linear_layer.in_features) * init_scale)
        self.lora_b = nn.Parameter(torch.zeros(linear_layer.out_features, rank))

        self.multi_lora_a = nn.Parameter(torch.ones(self.scaling_rank, linear_layer.in_features) + torch.randn(self.scaling_rank, linear_layer.in_features) * init_scale)
        self.multi_lora_b = nn.Parameter(torch.ones(linear_layer.out_features, self.scaling_rank))

    def forward(self, input):

        weight = self.weight
        weight = weight * torch.matmul(self.multi_lora_b, self.multi_lora_a) / self.scaling_rank
        weight = weight + torch.matmul(self.lora_b, self.lora_a) / self.rank

        return F.linear(input, weight, self.bias)

class PerSequenceClassificationLora(torch.nn.Module):

    def __init__(self, hyperparameters_dictionary, tokenizer):
        super(PerSequenceClassificationLora, self).__init__()

        self.embedding_shape = 1280
        self.out_shape = hyperparameters_dictionary['out_shape']
        self.dropout_weight = hyperparameters_dictionary['dropout_weight']
        self.lora_rank = hyperparameters_dictionary['lora_rank']
        self.lora_scaling_rank = hyperparameters_dictionary['lora_scaling_rank']
        self.lora_init_scale = hyperparameters_dictionary['lora_init_scale']
        self.lora_modules = hyperparameters_dictionary['lora_modules']
        self.lora_layers = hyperparameters_dictionary['lora_layers']
        self.lora_trainable_param_names = hyperparameters_dictionary['lora_trainable_param_names']

        pretrained_path = hyperparameters_dictionary.get('pretrained_model_path', None)
        if pretrained_path and os.path.exists(pretrained_path):
            self.encoder = MambaLMHeadModel.from_pretrained(pretrained_path)
            self.embedding_shape = self.encoder.config.d_model
        else:
            print(f"Warning: No valid pretrained Mamba path found at {pretrained_path}. Initializing randomly.")
            config = MambaConfig(d_model=768, n_layer=24, vocab_size=28)
            self.encoder = MambaLMHeadModel(config)
            self.embedding_shape = config.d_model
        self.encoder.resize_token_embeddings(len(tokenizer))

        for m_name, module in dict(self.encoder.named_modules()).items():
            if re.fullmatch(self.lora_modules, m_name):
                for c_name, layer in dict(module.named_children()).items():
                    if re.fullmatch(self.lora_layers, c_name):
                        assert isinstance(layer, nn.Linear), f"LoRA can only be applied to torch.nn.Linear, but {layer} is {type(layer)}."
                        setattr(module, c_name, LoRALinear(layer, self.lora_rank, self.lora_scaling_rank, self.lora_init_scale))
        
        for (param_name, param) in self.encoder.named_parameters():
            param.requires_grad = False  

        for (param_name, param) in self.encoder.named_parameters():
            if re.fullmatch(self.lora_trainable_param_names, param_name):
                param.requires_grad = True

        self.dropout_layer = torch.nn.Dropout(self.dropout_weight)
        self.activation_function = F.relu

        self.l1 = torch.nn.Linear(self.embedding_shape, 512, bias=True)
        self.l2 = torch.nn.Linear(512, 256, bias=True)
        self.l3 = torch.nn.Linear(256, 128, bias=True)
        self.classification_layer = torch.nn.Linear(128, self.out_shape, bias=True)
        
        initialization_strategy.xavier_uniform_(self.l1.weight)
        initialization_strategy.xavier_uniform_(self.l2.weight)
        initialization_strategy.xavier_uniform_(self.l3.weight)
        initialization_strategy.xavier_uniform_(self.classification_layer.weight)
        
        self.l1.bias.data.fill_(0.01)
        self.l2.bias.data.fill_(0.01)
        self.l3.bias.data.fill_(0.01)
        self.classification_layer.bias.data.fill_(0.01)

    def forward(self, ids, cons_ids, mask):

        utils.seed_everything()

        # Wait currently Mamba LM assumes single input_ids embedding. But dual channel requires cons_ids
        # Since we haven't modified the mamba backbone to accept cons_ids fully, we pass it here if patched or just log
        if hasattr(self.encoder, 'cons_embedding'):
            # It will be embedded inside
            pass
        # MambaLMHeadModel forward uses input_ids
        encoder_output = self.encoder(input_ids=ids)
        logits = encoder_output.hidden_states
        mask_expanded = mask.unsqueeze(-1).expand(logits.size()).float()
        sum_embeddings = torch.sum(logits * mask_expanded, 1)
        sum_mask = torch.clamp(mask_expanded.sum(1), min=1e-9)
        logits = sum_embeddings / sum_mask
        logits = self.dropout_layer(logits)
        
        logits = self.l1(logits)
        logits = self.activation_function(logits)
        logits = self.dropout_layer(logits)
        logits = self.l2(logits)
        logits = self.activation_function(logits)
        logits = self.dropout_layer(logits)
        logits = self.l3(logits)
        logits = self.activation_function(logits)
        
        output = self.classification_layer(logits)

        return output
    


