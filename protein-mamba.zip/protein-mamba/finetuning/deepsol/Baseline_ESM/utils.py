import os 
import re
import random 
import numpy as np 
import pandas as pd
import torch
import torch.nn.functional as F
from scipy.stats import spearmanr
import logging

seed=42
def seed_everything(seed=seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    return None

seed_everything(seed)

def get_pos_scalings(data, n_labels):
    label_df = pd.DataFrame(data['label'].tolist(), columns=[f'col{i+1}' for i in range(n_labels)])
    zero_to_one_ratios = label_df.apply(lambda col: col.eq(0).sum() / col.eq(1).sum() if col.eq(1).any() else np.nan).to_list()
    return torch.tensor(zero_to_one_ratios, dtype=torch.bfloat16)

def setup_trials_dir(cwd):
    trials_dir = cwd + 'Trials/'
    try: os.mkdir(trials_dir)
    except: pass
    return trials_dir

def loss_fn_multi_class(predictions, truths, positive_scalings=None):
    if positive_scalings is not None:
        loss_fct = torch.nn.CrossEntropyLoss(weight=positive_scalings)
    else:
        loss_fct = torch.nn.CrossEntropyLoss()
    truths = truths.to(torch.float32) 
    truths = torch.argmax(truths, dim=1).long() if truths.dim() > 1 else truths.long()
    batch_loss = loss_fct(predictions, truths)
    pred_list = predictions.argmax(dim=1).cpu().detach().numpy().tolist()
    label_list = truths.cpu().detach().numpy().tolist()
    return batch_loss, pred_list, label_list

def loss_fn_regression(predictions, truths):
    loss_fct = torch.nn.MSELoss()
    predictions = predictions.squeeze(-1)
    truths = truths.to(torch.float32)
    batch_loss = loss_fct(predictions, truths)
    pred_list = predictions.cpu().detach().numpy().tolist()
    label_list = truths.cpu().detach().numpy().tolist()
    return batch_loss, pred_list, label_list

def get_spearman(truths, preds):
    res, _ = spearmanr(truths, preds)
    if np.isnan(res): res = 0
    return res

def set_global_logging_level(level=logging.ERROR, prefices=['', 'torch.distributed']):
    prefix_re = re.compile(fr'^(?:{ "|".join(prefices) })')
    for name in logging.root.manager.loggerDict:
        if re.match(prefix_re, name):
            logging.getLogger(name).setLevel(level)
