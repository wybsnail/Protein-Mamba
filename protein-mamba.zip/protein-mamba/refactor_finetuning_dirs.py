import os
import shutil

FINETUNE_DIR = "finetuning"
DATASETS = ["KCNE1", "PTEN", "RecA", "TPMT"]
OLD_BACKBONES = ["ESM_15B", "ESM_650M", "ProtBERT", "ProtT5"]

for dataset in DATASETS:
    dataset_dir = os.path.join(FINETUNE_DIR, dataset)
    if not os.path.exists(dataset_dir):
        print(f"Skipping {dataset_dir}, doesn't exist.")
        continue
    
    # Target directories
    single_dir = os.path.join(dataset_dir, "SingleChannel")
    dual_dir = os.path.join(dataset_dir, "DualChannel")
    
    # We will copy scripts from ESM_650M as templates
    template_base = os.path.join(dataset_dir, "ESM_650M")
    
    if os.path.exists(template_base):
        
        # 1. Setup SingleChannel from NO_HTL
        no_htl_dir = os.path.join(template_base, "NO_HTL")
        if os.path.exists(no_htl_dir) and not os.path.exists(single_dir):
            shutil.copytree(no_htl_dir, single_dir)
            # rename specific script
            for fname in os.listdir(single_dir):
                if fname.startswith("persequence_"):
                    old_path = os.path.join(single_dir, fname)
                    new_path = os.path.join(single_dir, "train_single_channel.py")
                    os.rename(old_path, new_path)
                    print(f"Created {new_path}")
        
        # 2. Setup DualChannel from HTL
        htl_dir = os.path.join(template_base, "HTL")
        if os.path.exists(htl_dir) and not os.path.exists(dual_dir):
            shutil.copytree(htl_dir, dual_dir)
            # rename specific script
            for fname in os.listdir(dual_dir):
                if fname.startswith("persequence_"):
                    old_path = os.path.join(dual_dir, fname)
                    new_path = os.path.join(dual_dir, "train_dual_channel.py")
                    os.rename(old_path, new_path)
                    print(f"Created {new_path}")

    # 3. Remove old backbones
    for backbone in OLD_BACKBONES:
        backbone_dir = os.path.join(dataset_dir, backbone)
        if os.path.exists(backbone_dir):
            shutil.rmtree(backbone_dir)
            print(f"Removed {backbone_dir}")

print("Refactoring complete.")
