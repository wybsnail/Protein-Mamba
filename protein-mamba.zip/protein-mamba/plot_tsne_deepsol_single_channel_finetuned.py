import argparse
import os
import sys

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import torch
from sklearn.manifold import TSNE
from sklearn.metrics import pairwise_distances, silhouette_score
from sklearn.utils import shuffle
from torch.utils.data import DataLoader

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), ".")))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "finetuning/deepsol/SingleChannel")))

from tokenizer import ProteinTokenizer
import finetuning.deepsol.SingleChannel.models as sc_models


def resolve_deepsol_dir(project_root):
    upper = os.path.join(project_root, "Data", "benchmark", "deepsol")
    lower = os.path.join(project_root, "data", "benchmark", "deepsol")
    if os.path.exists(upper):
        return upper
    if os.path.exists(lower):
        return lower
    raise FileNotFoundError("Cannot find deepsol dataset under Data/benchmark or data/benchmark")


def build_hparams(best_hparams_path, pretrained_ckpt_path):
    best = joblib.load(best_hparams_path)
    hparams = {
        "pretrained_model_path": pretrained_ckpt_path,
        "in_shape": 1700,
        "out_shape": 2,
        "epochs": 30,
        "batch_size": int(best.get("batch_size", 8)),
        "grad_accum_steps": int(best.get("grad_accum_steps", 1)),
        "dropout_weight": float(best.get("dropout_weight", 0.2)),
        "learning_rate": float(best.get("learning_rate", 1e-4)),
        "trial_num": int(best.get("best_trial_num", 0)),
        "lora_rank": int(best.get("lora_rank", 4)),
        "lora_scaling_rank": 1,
        "lora_init_scale": 0.01,
        "lora_modules": ".*mixer.*",
        "lora_layers": "in_proj|out_proj|x_proj|dt_proj",
        "lora_trainable_param_names": ".*norm.*|.*lora_[ab].*",
    }
    return hparams


def load_finetuned_model(model_ckpt_path, best_hparams_path, pretrained_ckpt_path, device):
    hparams = build_hparams(best_hparams_path, pretrained_ckpt_path)
    model = sc_models.PerSequenceClassificationLora(hparams).to(device)
    state_dict = torch.load(model_ckpt_path, map_location=device, weights_only=True)
    model.load_state_dict(state_dict, strict=True)
    model.eval()
    return model


def extract_embeddings(model, dataloader, device):
    embeddings = []
    labels = []

    with torch.no_grad():
        for batch in dataloader:
            ids = batch["input_ids"].to(device, dtype=torch.int)
            mask = batch["attention_mask"].to(device, dtype=torch.int)
            y = batch["labels"].to(device)

            encoder_output = model.encoder(input_ids=ids)
            token_hidden = encoder_output.hidden_states

            mask_expanded = mask.unsqueeze(-1).expand(token_hidden.size()).to(token_hidden.dtype)
            summed = torch.sum(token_hidden * mask_expanded, dim=1)
            denom = torch.clamp(mask_expanded.sum(dim=1), min=1e-9)
            pooled = summed / denom

            x = model.dropout_layer(pooled)
            x = model.l1(x)
            x = torch.relu(x)
            x = model.dropout_layer(x)
            x = model.l2(x)
            x = torch.relu(x)
            x = model.dropout_layer(x)
            x = model.l3(x)
            x = torch.relu(x)

            embeddings.append(x.float().cpu().numpy())
            labels.append(y.to(torch.int64).cpu().numpy())

    embeddings = np.concatenate(embeddings, axis=0)
    labels = np.concatenate(labels, axis=0)
    return embeddings, labels


def compute_metrics(embeddings, labels):
    labels = np.array(labels)
    unique = sorted(set(labels.tolist()))
    if len(unique) != 2:
        return {"available": False, "reason": f"Need exactly 2 classes, got {unique}"}

    mask0 = labels == unique[0]
    mask1 = labels == unique[1]
    if int(mask0.sum()) < 2 or int(mask1.sum()) < 2:
        return {"available": False, "reason": "Each class needs at least 2 samples."}

    silhouette = float(silhouette_score(embeddings, labels, metric="euclidean"))

    emb0 = embeddings[mask0]
    emb1 = embeddings[mask1]
    d0 = pairwise_distances(emb0, metric="euclidean")
    d1 = pairwise_distances(emb1, metric="euclidean")
    d01 = pairwise_distances(emb0, emb1, metric="euclidean")

    mean_intra_0 = float(d0[np.triu_indices_from(d0, k=1)].mean())
    mean_intra_1 = float(d1[np.triu_indices_from(d1, k=1)].mean())
    mean_intra = (mean_intra_0 + mean_intra_1) / 2.0
    mean_inter = float(d01.mean())

    c0 = emb0.mean(axis=0)
    c1 = emb1.mean(axis=0)
    centroid = float(np.linalg.norm(c0 - c1))

    return {
        "available": True,
        "classes": unique,
        "n_class_0": int(mask0.sum()),
        "n_class_1": int(mask1.sum()),
        "silhouette_score": silhouette,
        "mean_intra_class_distance": mean_intra,
        "mean_inter_class_distance": mean_inter,
        "inter_over_intra_ratio": float(mean_inter / (mean_intra + 1e-12)),
        "centroid_distance": centroid,
    }


def main():
    parser = argparse.ArgumentParser(description="t-SNE for DeepSol SingleChannel finetuned model")
    parser.add_argument(
        "--model_ckpt",
        type=str,
        default="finetuning/deepsol/SingleChannel/Trials/Trial_0/deepsol_0.pt",
        help="Path to finetuned SingleChannel model .pt",
    )
    parser.add_argument(
        "--best_hparams",
        type=str,
        default="finetuning/deepsol/SingleChannel/best_hyperparameters.joblib",
        help="Path to best_hyperparameters.joblib",
    )
    parser.add_argument(
        "--pretrained_ckpt",
        type=str,
        default="checkpoints/ptm-mamba-pretrain/best.ckpt",
        help="Path to pretrained mamba ckpt used by finetuned model",
    )
    parser.add_argument(
        "--split",
        type=str,
        default="test",
        choices=["train", "validation", "test"],
        help="DeepSol split to visualize",
    )
    parser.add_argument("--max_samples", type=int, default=None, help="Optional cap on sample count")
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size for embedding extraction")
    parser.add_argument("--perplexity", type=float, default=30.0, help="t-SNE perplexity")
    parser.add_argument("--random_state", type=int, default=42, help="Random seed for t-SNE")
    parser.add_argument(
        "--output_dir",
        type=str,
        default="outputs/tsne_deepsol_single_channel_finetuned",
        help="Output directory",
    )
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    project_root = os.path.abspath(os.path.dirname(__file__))
    data_dir = resolve_deepsol_dir(project_root)
    split_path = os.path.join(data_dir, f"{args.split}.csv")
    df = shuffle(pd.read_csv(split_path), random_state=args.random_state)

    if args.max_samples is not None:
        df = df.iloc[: args.max_samples].copy()

    tokenizer = ProteinTokenizer()
    dataset = sc_models.PerSequenceClassificationLoraDataset(
        dataframe=df,
        tokenizer=tokenizer,
        max_len=1700,
        seqname="aa_seq",
        labelname="label",
        n_labels=2,
    )
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    print(f"Loading finetuned model: {args.model_ckpt}")
    model = load_finetuned_model(args.model_ckpt, args.best_hparams, args.pretrained_ckpt, device)

    print(f"Extracting embeddings from {len(df)} samples...")
    embeddings, labels = extract_embeddings(model, dataloader, device)

    n = len(embeddings)
    if n < 4:
        raise ValueError("Need at least 4 samples to run t-SNE.")
    perplexity = min(args.perplexity, max(2.0, n - 1.0))

    tsne = TSNE(n_components=2, perplexity=perplexity, random_state=args.random_state)
    projected = tsne.fit_transform(embeddings)

    label_names = [str(v) for v in labels.tolist()]
    plt.figure(figsize=(10, 8))
    sns.scatterplot(x=projected[:, 0], y=projected[:, 1], hue=label_names, s=80, alpha=0.8)
    plt.xlabel("t-SNE Dimension 1")
    plt.ylabel("t-SNE Dimension 2")
    plt.grid(True, linestyle="--", alpha=0.6)
    legend = plt.gca().get_legend()
    if legend is not None:
        legend.remove()

    fig_path = os.path.join(args.output_dir, f"tsne_{args.split}.png")
    plt.savefig(fig_path, dpi=300, bbox_inches="tight")
    plt.close()

    metrics = compute_metrics(embeddings, labels)
    metrics_path = os.path.join(args.output_dir, f"metrics_{args.split}.txt")
    with open(metrics_path, "w", encoding="utf-8") as f:
        for key, value in metrics.items():
            f.write(f"{key}: {value}\n")

    print(f"Saved t-SNE plot to {fig_path}")
    print(f"Saved metrics to {metrics_path}")
    if metrics.get("available"):
        print(
            "Metrics | "
            f"silhouette={metrics['silhouette_score']:.4f}, "
            f"inter={metrics['mean_inter_class_distance']:.4f}, "
            f"intra={metrics['mean_intra_class_distance']:.4f}, "
            f"inter/intra={metrics['inter_over_intra_ratio']:.4f}, "
            f"centroid={metrics['centroid_distance']:.4f}"
        )
    else:
        print(f"Metrics unavailable: {metrics.get('reason')}")

if __name__ == "__main__":
    main()
