"""蛋白质基准数据集 Token 化主流程

对 7 个基准数据集执行：
  1. 加载 CSV 数据
  2. ESM2 保守性评分（逐位置熵值）
  3. 双通道 token 化（AA + 保守性等级）
  4. 保存为 .npz + metadata.json

用法:
    python tokenize_datasets.py --dataset deepsol --batch-size 32
    python tokenize_datasets.py --all --device cuda
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path
from typing import Optional

import numpy as np

from tokenizer import ProteinTokenizer
from conservation import ESMConservationScorer


# ═══════════════════════════════════════════════════════════════
# 数据集配置
# ═══════════════════════════════════════════════════════════════

PROJECT_ROOT = Path(__file__).parent
BENCHMARK_DIR = PROJECT_ROOT / "data" / "benchmark"
OUTPUT_DIR = PROJECT_ROOT / "data" / "tokenized"

# 列名映射
COLUMN_MAP = {
    "deepsol":              {"seq": "aa_seq",   "label": "label"},
    "flip_thermostability": {"seq": "aa_seq",   "label": "label"},
    "sarkisyan":            {"seq": "aa_seq",   "label": "label"},
    "envision":             {"seq": "primary",  "label": "scaled_effect1"},
    "rocklin":              {"seq": "aa_seq",   "label": "label"},
    "flip_gb1":             {"seq": "sequence", "label": "target"},
    "flip_aav":             {"seq": "sequence", "label": "target"},
}

ALL_DATASETS = list(COLUMN_MAP.keys())


# ═══════════════════════════════════════════════════════════════
# 数据加载
# ═══════════════════════════════════════════════════════════════

def load_dataset_csv(
    dataset_name: str,
    split: str = "train",
) -> tuple[list[str], list[float]]:
    """加载一个 split 的 CSV 数据。

    Args:
        dataset_name: 数据集名称 (如 "deepsol")。
        split: "train" / "validation" / "test"。

    Returns:
        (sequences, labels) 列表。
    """
    col_cfg = COLUMN_MAP[dataset_name]
    seq_col = col_cfg["seq"]
    label_col = col_cfg["label"]

    csv_path = BENCHMARK_DIR / dataset_name / f"{split}.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"找不到: {csv_path}")

    sequences = []
    labels = []
    with open(csv_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            seq = row[seq_col].strip()
            if not seq:
                continue
            label_val = row[label_col].strip()
            try:
                label = float(label_val)
            except ValueError:
                label = float("nan")
            sequences.append(seq)
            labels.append(label)

    return sequences, labels


def get_splits(dataset_name: str) -> list[str]:
    """获取数据集可用的 split 列表。"""
    ds_dir = BENCHMARK_DIR / dataset_name
    splits = []
    for name in ["train", "validation", "test"]:
        if (ds_dir / f"{name}.csv").exists():
            splits.append(name)
    return splits


# ═══════════════════════════════════════════════════════════════
# FLIP 数据特殊处理
# ═══════════════════════════════════════════════════════════════

def load_flip_split(
    dataset_name: str,
    split_file: str,
) -> tuple[list[str], list[float], list[str]]:
    """加载 FLIP 数据集的特定 split 文件。

    FLIP 的 CSV 格式：sequence, target, set, validation
    其中 set 列指示 train/test。

    Returns:
        (sequences, labels, set_labels)
    """
    col_cfg = COLUMN_MAP[dataset_name]
    csv_path = BENCHMARK_DIR / dataset_name / "splits" / split_file

    sequences, labels, set_labels = [], [], []
    with open(csv_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            seq = row[col_cfg["seq"]].strip()
            if not seq:
                continue
            try:
                label = float(row[col_cfg["label"]])
            except (ValueError, KeyError):
                label = float("nan")
            set_label = row.get("set", "train").strip()
            sequences.append(seq)
            labels.append(label)
            set_labels.append(set_label)

    return sequences, labels, set_labels


# ═══════════════════════════════════════════════════════════════
# Token 化主流程
# ═══════════════════════════════════════════════════════════════

def tokenize_split(
    sequences: list[str],
    labels: list[float],
    tokenizer: ProteinTokenizer,
    scorer: Optional[ESMConservationScorer],
    quantiles: tuple[float, float] = (0.33, 0.66),
) -> dict[str, np.ndarray]:
    """对一个 split 的全部序列进行 token 化。

    Returns:
        字典包含:
          - aa_ids: list of int32 arrays
          - cons_ids: list of int8 arrays
          - entropy: list of float32 arrays  (None if no scorer)
          - labels: float32 array
          - lengths: int32 array
    """
    N = len(sequences)
    all_aa_ids = []
    all_cons_ids = []
    all_entropy = []
    all_labels = np.array(labels, dtype=np.float32)
    all_lengths = np.zeros(N, dtype=np.int32)

    # 批量保守性评分
    if scorer is not None:
        print(f"    计算保守性分数 ({N} 条序列) ...")
        conservation_results = scorer.score_batch(sequences, quantiles)
    else:
        conservation_results = [None] * N

    # Token 化
    print(f"    Token 化 ({N} 条序列) ...")
    for i, seq in enumerate(sequences):
        if conservation_results[i] is not None:
            entropy, cons_bin = conservation_results[i]
            aa_ids, cons_ids = tokenizer.encode(seq, cons_scores=entropy, quantiles=quantiles)
            all_entropy.append(entropy)
        else:
            aa_ids, cons_ids = tokenizer.encode(seq)
            all_entropy.append(np.zeros(len(seq), dtype=np.float32))

        all_aa_ids.append(np.array(aa_ids, dtype=np.int32))
        all_cons_ids.append(np.array(cons_ids, dtype=np.int8))
        all_lengths[i] = len(aa_ids)

    return {
        "aa_ids": np.array(all_aa_ids, dtype=object),
        "cons_ids": np.array(all_cons_ids, dtype=object),
        "entropy": np.array(all_entropy, dtype=object),
        "labels": all_labels,
        "lengths": all_lengths,
    }


def save_tokenized(
    data: dict[str, np.ndarray],
    save_path: Path,
) -> None:
    """保存 token 化结果为 .npz 文件。"""
    save_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        str(save_path),
        aa_ids=data["aa_ids"],
        cons_ids=data["cons_ids"],
        entropy=data["entropy"],
        labels=data["labels"],
        lengths=data["lengths"],
    )
    size_mb = save_path.stat().st_size / 1024 / 1024
    print(f"    ✓ 已保存: {save_path.name} ({size_mb:.1f} MB)")


def save_metadata(
    dataset_name: str,
    save_dir: Path,
    args: argparse.Namespace,
    split_stats: dict,
) -> None:
    """保存元数据。"""
    meta = {
        "dataset": dataset_name,
        "method": args.method,
        "model": args.model if args.method == "esm2" else None,
        "quantiles": list(args.quantiles),
        "vocab_size": 28,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "splits": split_stats,
    }
    meta_path = save_dir / "metadata.json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    print(f"    ✓ metadata.json")


# ═══════════════════════════════════════════════════════════════
# 主函数
# ═══════════════════════════════════════════════════════════════

def process_dataset(
    dataset_name: str,
    tokenizer: ProteinTokenizer,
    scorer: Optional[ESMConservationScorer],
    args: argparse.Namespace,
) -> None:
    """处理单个数据集的全部 splits。"""
    print(f"\n{'='*60}")
    print(f"  数据集: {dataset_name}")
    print(f"{'='*60}")

    save_dir = OUTPUT_DIR / dataset_name
    save_dir.mkdir(parents=True, exist_ok=True)

    split_stats = {}

    # 判断是普通 CSV 还是 FLIP 格式
    splits = get_splits(dataset_name)

    if splits:
        # 标准 train/val/test CSV
        for split in splits:
            print(f"\n  ── {split} ──")
            sequences, labels = load_dataset_csv(dataset_name, split)
            print(f"    加载: {len(sequences):,} 条序列")

            data = tokenize_split(
                sequences, labels, tokenizer, scorer,
                quantiles=tuple(args.quantiles),
            )

            save_tokenized(data, save_dir / f"{split}.npz")
            split_stats[split] = {
                "count": len(sequences),
                "avg_length": float(data["lengths"].mean()),
                "max_length": int(data["lengths"].max()),
            }
    else:
        # FLIP 格式（splits/ 子目录中的 CSV）
        splits_dir = BENCHMARK_DIR / dataset_name / "splits"
        if splits_dir.exists():
            csv_files = sorted(f for f in splits_dir.iterdir() if f.suffix == ".csv")
            for csv_file in csv_files:
                split_name = csv_file.stem
                print(f"\n  ── {split_name} ──")

                sequences, labels, set_labels = load_flip_split(
                    dataset_name, csv_file.name
                )
                print(f"    加载: {len(sequences):,} 条序列")

                data = tokenize_split(
                    sequences, labels, tokenizer, scorer,
                    quantiles=tuple(args.quantiles),
                )

                save_tokenized(data, save_dir / f"{split_name}.npz")
                split_stats[split_name] = {
                    "count": len(sequences),
                    "avg_length": float(data["lengths"].mean()),
                    "max_length": int(data["lengths"].max()),
                }

    save_metadata(dataset_name, save_dir, args, split_stats)


def main():
    parser = argparse.ArgumentParser(
        description="蛋白质基准数据集 Token 化工具"
    )
    parser.add_argument(
        "--dataset", type=str, default=None,
        choices=ALL_DATASETS,
        help="要处理的数据集名称"
    )
    parser.add_argument(
        "--all", action="store_true",
        help="处理全部 7 个数据集"
    )
    parser.add_argument(
        "--method", type=str, default="esm2",
        choices=["esm2", "none"],
        help="保守性评分方法 (default: esm2)"
    )
    parser.add_argument(
        "--model", type=str, default="facebook/esm2_t30_150M_UR50D",
        help="ESM2 模型 checkpoint"
    )
    parser.add_argument(
        "--batch-size", type=int, default=32,
        help="掩码预测的 batch 大小"
    )
    parser.add_argument(
        "--device", type=str, default=None,
        help="计算设备 (cpu/cuda)"
    )
    parser.add_argument(
        "--quantiles", type=float, nargs=2, default=[0.33, 0.66],
        help="分箱分位数阈值"
    )
    parser.add_argument(
        "--no-cache", action="store_true",
        help="禁用磁盘缓存"
    )

    args = parser.parse_args()

    if not args.dataset and not args.all:
        parser.error("请指定 --dataset 或 --all")

    # 确定要处理的数据集
    datasets = ALL_DATASETS if args.all else [args.dataset]

    # 初始化 tokenizer
    tokenizer = ProteinTokenizer(add_special=True)
    print(f"词汇表大小: {tokenizer.vocab_size}")

    # 初始化保守性评分器
    scorer = None
    if args.method == "esm2":
        scorer = ESMConservationScorer(
            model_name=args.model,
            device=args.device,
            batch_size=args.batch_size,
            use_cache=not args.no_cache,
        )

    # 处理数据集
    t0 = time.time()
    for name in datasets:
        process_dataset(name, tokenizer, scorer, args)

    elapsed = time.time() - t0
    print(f"\n{'='*60}")
    print(f"✅ 全部完成！耗时 {elapsed:.1f}s")
    print(f"输出目录: {OUTPUT_DIR.resolve()}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
