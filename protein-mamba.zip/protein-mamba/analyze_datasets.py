import os
import pandas as pd
import json

benchmarks = ['deepsol', 'envision', 'flip_aav', 'flip_gb1', 'flip_thermostability', 'rocklin', 'sarkisyan']
result = {}

for b in benchmarks:
    path = f'Data/benchmark/{b}'
    csv_file = None
    for root, dirs, files in os.walk(path):
        for f in files:
            if f.endswith('.csv') and 'train' in f.lower():
                csv_file = os.path.join(root, f)
                break
        if csv_file: break
    if csv_file:
        try:
            df = pd.read_csv(csv_file)
            cols = df.columns.tolist()
            
            # Find sequence column
            seq_col = None
            for c in cols:
                if 'seq' in c.lower() or 'mutated_sequence' in c.lower() or c.lower() == 'sequence':
                    seq_col = c
                    break
            
            # Find label column
            label_col = None
            for c in cols:
                if c.lower() in ['label', 'score', 'fitness', 'solubility', 'tm', 'mutated_sequence_htl', 'mutated_sequence_no_htl']:
                    label_col = c
                if 'score' in c.lower() or 'fitness' in c.lower():
                    label_col = c
            if b == 'deepsol': label_col = 'label'
            
            # Max length
            if seq_col:
                max_len = int(df[seq_col].str.len().max())
            else:
                max_len = 0
                
            num_classes = df[label_col].nunique() if label_col and df[label_col].dtype in ['int64', 'bool'] else 'regression'
            
            if num_classes != 'regression' and num_classes > 10:
                num_classes = 'regression'
                
            result[b] = {
                'file': csv_file,
                'columns': cols,
                'seq_col': seq_col,
                'label_col': label_col,
                'max_len': max_len,
                'num_classes': num_classes
            }
        except Exception as e:
            result[b] = {'error': str(e)}

with open('dataset_info.json', 'w') as f:
    json.dump(result, f, indent=4)
