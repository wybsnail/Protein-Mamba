import os
import re

DATASETS = ["KCNE1", "PTEN", "RecA", "TPMT"]
MODES = ["SingleChannel", "DualChannel"]

def patch_models_py(path):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    new_init = """        pretrained_path = hyperparameters_dictionary.get('pretrained_model_path', None)
        if pretrained_path and os.path.exists(pretrained_path):
            self.encoder = MambaLMHeadModel.from_pretrained(pretrained_path)
            self.embedding_shape = self.encoder.config.d_model
        else:
            print(f"Warning: No valid pretrained Mamba path found at {pretrained_path}. Initializing randomly.")
            config = MambaConfig(d_model=768, n_layer=24, vocab_size=28)
            self.encoder = MambaLMHeadModel(config)
            self.embedding_shape = config.d_model"""
            
    content = re.sub(
        r"        config = MambaConfig\(d_model=768, n_layer=24, vocab_size=28\)\n\s*self\.encoder = MambaLMHeadModel\(config\)\n\s*self\.embedding_shape = config\.d_model",
        new_init,
        content
    )
    
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def patch_train_py(path, mode):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
        
    model_path_str = "cwd + '../../../../output/single_channel_pretrain'" if mode == "SingleChannel" else "cwd + '../../../../output/dual_channel_pretrain'"
    
    param_addition = f"""            'pretrained_model_path' : {model_path_str},
            'in_shape' :"""
            
    # only replace if not already replaced
    if "'pretrained_model_path'" not in content:
        content = re.sub(r"            'in_shape' :", param_addition, content)

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

def main():
    for dataset in DATASETS:
        for mode in MODES:
            d = os.path.join("finetuning", dataset, mode)
            if not os.path.exists(d): continue
            
            models_path = os.path.join(d, "models.py")
            if os.path.exists(models_path):
                patch_models_py(models_path)
                print(f"Patched {models_path}")
            
            for fname in os.listdir(d):
                if fname.startswith("train_") and fname.endswith(".py"):
                    train_path = os.path.join(d, fname)
                    patch_train_py(train_path, mode)
                    print(f"Patched {train_path}")

if __name__ == "__main__":
    main()
