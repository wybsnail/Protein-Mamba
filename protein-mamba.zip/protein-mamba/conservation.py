"""ESM2 保守性评分模块

利用 ESM2 masked LM 对每个位置做掩码预测，
用预测熵值作为进化保守性代理指标：
  - 低熵 → 模型对该位置有强偏好 → 高度保守
  - 高熵 → 模型不确定 → 低保守
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Optional

import numpy as np

from tokenizer import HIGH_CONS_ID, MED_CONS_ID, LOW_CONS_ID


# ═══════════════════════════════════════════════════════════════
# ESM2 保守性评分器
# ═══════════════════════════════════════════════════════════════

local_model_path = Path(__file__).parent / "model" / "esm2_t30_150M_UR50D"
if local_model_path.exists():
    DEFAULT_MODEL = str(local_model_path)
else:
    DEFAULT_MODEL = "facebook/esm2_t30_150M_UR50D"

CACHE_DIR = Path(__file__).parent / "data" / "cache" / "conservation"


class ESMConservationScorer:
    """基于 ESM2 masked LM 预测熵的保守性评分器。

    对序列的每个位置 i:
      1. 将位置 i 替换为 <mask>
      2. 用 ESM2 预测该位置的氨基酸概率分布 p(a|context)
      3. 计算 Shannon 熵: H_i = -Σ p(a) log p(a)

    低熵 = 高保守 (模型确信该位置只能是某个氨基酸)
    高熵 = 低保守 (该位置可以是很多种氨基酸)
    """

    def __init__(
        self,
        model_name: str = DEFAULT_MODEL,
        device: Optional[str] = None,
        batch_size: int = 32,
        cache_dir: Optional[Path] = None,
        use_cache: bool = True,
    ):
        """
        Args:
            model_name: HuggingFace ESM2 masked LM checkpoint.
            device: 'cpu', 'cuda', 'cuda:0' 等。None 自动选择。
            batch_size: 批量处理掩码位置时的 batch 大小。
            cache_dir: 磁盘缓存目录。
            use_cache: 是否启用磁盘缓存。
        """
        if device is None:
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = device
        self.batch_size = batch_size
        self.use_cache = use_cache
        self.cache_dir = Path(cache_dir) if cache_dir else CACHE_DIR

        if self.use_cache:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

        import torch
        from transformers import AutoTokenizer, EsmForMaskedLM
        self._torch = torch

        print(f"  加载 ESM2 模型: {model_name} (device={device}) ...")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = EsmForMaskedLM.from_pretrained(model_name).to(device)
        self.model.eval()
        print(f"  ✓ ESM2 模型加载完成")

    # ── 单条评分 ──

    def score_sequence(
        self,
        sequence: str,
        quantiles: tuple[float, float] = (0.33, 0.66),
    ) -> tuple[np.ndarray, np.ndarray]:
        """计算单条序列的逐位置保守性分数。

        Args:
            sequence: 氨基酸序列 (长度 L)。
            quantiles: per-sequence quantile 分箱阈值。

        Returns:
            (entropy, cons_bin):
              - entropy: float32 数组, shape (L,)
              - cons_bin: int8 数组, shape (L,), 值 ∈ {25, 26, 27}
        """
        # 检查缓存
        if self.use_cache:
            cached = self._load_cache(sequence)
            if cached is not None:
                return cached

        L = len(sequence)
        entropy = np.zeros(L, dtype=np.float32)

        # 将原始序列 tokenize (不带 mask)
        tokens = self.tokenizer(sequence, return_tensors="pt").to(self.device)
        input_ids = tokens["input_ids"]  # shape: (1, L+2) with BOS/EOS

        # 逐位置或批量掩码预测
        # ESM2 tokenizer 在序列前加 <cls>，后加 <eos>，
        # 所以 AA 位置从 index 1 开始
        mask_token_id = self.tokenizer.mask_token_id

        # 批量处理：一次构造多个掩码序列
        for batch_start in range(0, L, self.batch_size):
            batch_end = min(batch_start + self.batch_size, L)
            batch_positions = list(range(batch_start, batch_end))
            B = len(batch_positions)

            # 复制 input_ids B 次
            batch_ids = input_ids.repeat(B, 1)  # (B, L+2)

            # 对每个副本在对应位置做 mask
            for j, pos in enumerate(batch_positions):
                batch_ids[j, pos + 1] = mask_token_id  # +1 for <cls>

            # 批量推理
            with self._torch.no_grad():
                logits = self.model(input_ids=batch_ids).logits  # (B, L+2, vocab)

            # 提取每个掩码位置的概率分布并计算熵
            for j, pos in enumerate(batch_positions):
                pos_logits = logits[j, pos + 1]  # (vocab_size,)
                probs = self._torch.softmax(pos_logits, dim=-1)
                # Shannon 熵 (全 vocab 上计算更稳健)
                log_probs = self._torch.log(probs + 1e-10)
                h = -(probs * log_probs).sum().item()
                entropy[pos] = h

        # Per-sequence quantile 分箱
        cons_bin = self._quantile_bin(entropy, quantiles)

        # 缓存
        if self.use_cache:
            self._save_cache(sequence, entropy, cons_bin)

        return entropy, cons_bin

    # ── 批量评分 ──

    def score_batch(
        self,
        sequences: list[str],
        quantiles: tuple[float, float] = (0.33, 0.66),
        show_progress: bool = True,
    ) -> list[tuple[np.ndarray, np.ndarray]]:
        """批量计算多条序列的保守性分数。

        Args:
            sequences: 序列列表。
            quantiles: 分箱阈值。
            show_progress: 是否显示进度。

        Returns:
            [(entropy, cons_bin), ...] 列表。
        """
        results = []
        total = len(sequences)
        for i, seq in enumerate(sequences):
            if show_progress and (i % 100 == 0 or i == total - 1):
                print(f"    保守性评分进度: {i + 1}/{total}")
            result = self.score_sequence(seq, quantiles)
            results.append(result)
        return results

    # ── 分箱 ──

    @staticmethod
    def _quantile_bin(
        entropy: np.ndarray,
        quantiles: tuple[float, float] = (0.33, 0.66),
    ) -> np.ndarray:
        """Per-sequence quantile 分箱。

        低熵 → HIGH_CONS; 中 → MED_CONS; 高熵 → LOW_CONS.
        """
        q_low = np.quantile(entropy, quantiles[0])
        q_high = np.quantile(entropy, quantiles[1])

        cons = np.full(len(entropy), MED_CONS_ID, dtype=np.int8)
        cons[entropy <= q_low] = HIGH_CONS_ID
        cons[entropy > q_high] = LOW_CONS_ID
        return cons

    # ── 磁盘缓存 ──

    @staticmethod
    def _seq_hash(sequence: str) -> str:
        return hashlib.md5(sequence.encode("utf-8")).hexdigest()

    def _cache_path(self, sequence: str) -> Path:
        h = self._seq_hash(sequence)
        return self.cache_dir / f"{h}.npz"

    def _load_cache(self, sequence: str) -> Optional[tuple[np.ndarray, np.ndarray]]:
        p = self._cache_path(sequence)
        if p.exists():
            data = np.load(p)
            return data["entropy"], data["cons_bin"]
        return None

    def _save_cache(
        self, sequence: str, entropy: np.ndarray, cons_bin: np.ndarray
    ) -> None:
        p = self._cache_path(sequence)
        np.savez_compressed(p, entropy=entropy, cons_bin=cons_bin)


# ═══════════════════════════════════════════════════════════════
# CLI 测试
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    scorer = ESMConservationScorer(batch_size=16)

    test_seq = "MALWMRLLPLLALLALWGPDPAAA"
    print(f"\n测试序列: {test_seq} (长度 {len(test_seq)})")

    entropy, cons_bin = scorer.score_sequence(test_seq)

    print(f"\n逐位置熵值:")
    for i, (aa, h, c) in enumerate(zip(test_seq, entropy, cons_bin)):
        level = {HIGH_CONS_ID: "HIGH", MED_CONS_ID: "MED ", LOW_CONS_ID: "LOW "}[c]
        print(f"  {i:3d}  {aa}  H={h:.4f}  {level}")

    print(f"\n统计:")
    print(f"  平均熵: {entropy.mean():.4f}")
    print(f"  HIGH_CONS: {(cons_bin == HIGH_CONS_ID).sum()}")
    print(f"  MED_CONS:  {(cons_bin == MED_CONS_ID).sum()}")
    print(f"  LOW_CONS:  {(cons_bin == LOW_CONS_ID).sum()}")
