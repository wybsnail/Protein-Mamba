"""蛋白质序列编码与预处理模块

提供氨基酸序列的索引编码和 one-hot 编码功能。
提取自 ESM.ipynb Cell 7, 10, 12, 14。
"""

import jax
import jax.numpy as jnp


# 20 种标准氨基酸
amino_acids = [
    "R", "H", "K", "D", "E",
    "S", "T", "N", "Q", "G",
    "P", "C", "A", "V", "I",
    "L", "M", "F", "Y", "W",
]

# 氨基酸到索引的映射字典
amino_acid_to_index = {
    amino_acid: index for index, amino_acid in enumerate(amino_acids)
}

# 示例蛋白质序列：人类胰岛素前体
# Technically, this is actually the precursor protein to insulin that will get
# processed into 2 separate protein chains later.
insulin_sequence = (
    "MALWMRLLPLLALLALWGPDPAAAFVNQHLCGSHLVEALYLVCGERGFFYTPKTRREAEDLQVGQVELGG"
    "GPGAGSLQPLALEGSLQKRGIVEQCCTSICSLYQLENYCN"
)


def encode_sequence(sequence: str) -> list[int]:
    """将氨基酸序列转换为索引列表。

    Args:
        sequence: 氨基酸单字母序列字符串，例如 "MALWM"。

    Returns:
        对应的整数索引列表。
    """
    return [amino_acid_to_index[aa] for aa in sequence]


def one_hot_encode(sequence: str, num_classes: int = 20) -> jnp.ndarray:
    """对氨基酸序列进行 one-hot 编码。

    Args:
        sequence: 氨基酸单字母序列字符串。
        num_classes: 氨基酸类别数，默认 20。

    Returns:
        形状为 (len(sequence), num_classes) 的 one-hot 编码矩阵。
    """
    indices = encode_sequence(sequence)
    return jax.nn.one_hot(x=indices, num_classes=num_classes)


def main():
    """演示序列编码流程。"""
    # 示例 1：短序列编码
    tiny_protein = "MALWM"
    indices = encode_sequence(tiny_protein)
    print(f"序列 '{tiny_protein}' 的索引编码: {indices}")

    # 示例 2：one-hot 编码
    one_hot = one_hot_encode(tiny_protein)
    print(f"One-hot 编码形状: {one_hot.shape}")
    print(f"One-hot 编码矩阵:\n{one_hot}")

    # 示例 3：胰岛素序列
    print(f"\n胰岛素前体序列长度: {len(insulin_sequence)}")
    insulin_indices = encode_sequence(insulin_sequence)
    print(f"胰岛素前体索引编码 (前 10 个): {insulin_indices[:10]}")


if __name__ == "__main__":
    main()
