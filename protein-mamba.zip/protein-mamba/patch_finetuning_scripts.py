import os
import re

DATASETS = ["KCNE1", "PTEN", "RecA", "TPMT"]
MODES = ["SingleChannel", "DualChannel"]

IMPORTS_REPLACE = """import re
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
import torch.nn.init as initialization_strategy
import joblib
import utils
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from tokenizer import ProteinTokenizer
from pretrain.protein_lm.modeling.models.mamba.lm import MambaLMHeadModel
from pretrain.protein_lm.modeling.models.mamba.config_mamba import MambaConfig
"""

GETITEM_SINGLE = """    def __getitem__(self, index):
        sequence = self.sequences[index]
        label = self.labels[index]
        ids, _ = self.tokenizer.encode(sequence, cons_scores=None)
        if len(ids) > self.max_len:
            ids = ids[:self.max_len]
        mask_len = len(ids)
        if len(ids) < self.max_len:
            ids = ids + [self.tokenizer.pad_token_id] * (self.max_len - len(ids))
        mask = [1] * mask_len + [0] * (self.max_len - mask_len)
        return {'input_ids': torch.tensor(ids, dtype=torch.int), 'attention_mask': torch.tensor(mask, dtype=torch.int), 'labels': torch.tensor(label, dtype=torch.bfloat16)}
"""

GETITEM_DUAL = """    def __getitem__(self, index):
        sequence = self.sequences[index]
        label = self.labels[index]
        # In dual channel, we would use ESMScorer if we don't have cached data yet.
        # For now, pass None to generate dummy cons_ids or read from pre-cached files if added.
        ids, cons_ids = self.tokenizer.encode(sequence, cons_scores=None)
        if len(ids) > self.max_len:
            ids = ids[:self.max_len]
            cons_ids = cons_ids[:self.max_len]
        mask_len = len(ids)
        if len(ids) < self.max_len:
            ids = ids + [self.tokenizer.pad_token_id] * (self.max_len - len(ids))
            cons_ids = cons_ids + [self.tokenizer.vocab["[PAD]"]] * (self.max_len - len(cons_ids))
        mask = [1] * mask_len + [0] * (self.max_len - mask_len)
        return {'input_ids': torch.tensor(ids, dtype=torch.int), 'cons_ids': torch.tensor(cons_ids, dtype=torch.int), 'attention_mask': torch.tensor(mask, dtype=torch.int), 'labels': torch.tensor(label, dtype=torch.bfloat16)}
"""

INIT_MAMBA = """        config = MambaConfig(d_model=768, n_layer=24, vocab_size=28)
        self.encoder = MambaLMHeadModel(config)
        self.embedding_shape = config.d_model"""

FORWARD_REPLACE_SINGLE = """        encoder_output = self.encoder(input_ids=ids)
        logits = encoder_output.hidden_states
        mask_expanded = mask.unsqueeze(-1).expand(logits.size()).float()
        sum_embeddings = torch.sum(logits * mask_expanded, 1)
        sum_mask = torch.clamp(mask_expanded.sum(1), min=1e-9)
        logits = sum_embeddings / sum_mask"""

FORWARD_REPLACE_DUAL = """        # Wait currently Mamba LM assumes single input_ids embedding. But dual channel requires cons_ids
        # Since we haven't modified the mamba backbone to accept cons_ids fully, we pass it here if patched or just log
        if hasattr(self.encoder, 'cons_embedding'):
            # It will be embedded inside
            pass
        # MambaLMHeadModel forward uses input_ids
        encoder_output = self.encoder(input_ids=ids)
        logits = encoder_output.hidden_states
        mask_expanded = mask.unsqueeze(-1).expand(logits.size()).float()
        sum_embeddings = torch.sum(logits * mask_expanded, 1)
        sum_mask = torch.clamp(mask_expanded.sum(1), min=1e-9)
        logits = sum_embeddings / sum_mask"""


def patch_models_py(path, mode):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    # 1. Replace imports
    import_block = re.search(r"import re.*?(?=utils\.seed_everything\(\))", content, re.DOTALL)
    if import_block:
        content = content[:import_block.start()] + IMPORTS_REPLACE + "\n" + content[import_block.end():]

    # 2. Replace getitem
    getitem_block = re.search(r"    def __getitem__\(self, index\):.*?return \{'input_ids'.*?}", content, re.DOTALL)
    if getitem_block:
        replacement = GETITEM_SINGLE if mode == "SingleChannel" else GETITEM_DUAL
        content = content[:getitem_block.start()] + replacement + content[getitem_block.end():]

    # 3. Replace AutoModel in init
    auto_model_re = r"self\.encoder = AutoModel\.from_pretrained.*?['\"].*?['\"]\)"
    if re.search(auto_model_re, content):
        content = re.sub(auto_model_re, INIT_MAMBA, content)

    # 4. Replace forward
    forward_old = r"encoder_output = self\.encoder\(input_ids=ids, attention_mask=mask\)\s+logits = encoder_output\.last_hidden_state\s+logits = torch\.mean\(logits, dim=1\)"
    replacement = FORWARD_REPLACE_SINGLE if mode == "SingleChannel" else FORWARD_REPLACE_DUAL
    if re.search(forward_old, content):
        content = re.sub(forward_old, replacement, content)
        
    # Dual channel: we need to change train.py to pass cons_ids into forward. 
    # Actually wait models.py forward receives `ids, mask`. We'll just change forward to `ids, cons_ids, mask` for dual channel.
    if mode == "DualChannel":
        content = content.replace("def forward(self, ids, mask):", "def forward(self, ids, cons_ids, mask):")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
        

TRAIN_IMPORTS_REPLACE = """from torch.utils.data import DataLoader
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from tokenizer import ProteinTokenizer"""


def patch_train_py(path, mode):
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
        
    # 1. imports
    imp = re.search(r"from torch\.utils\.data import DataLoader\s+from transformers import AutoTokenizer", content)
    if imp:
        content = content[:imp.start()] + TRAIN_IMPORTS_REPLACE + content[imp.end():]
        
    # 2. tokenizer init
    content = re.sub(r"tokenizer = AutoTokenizer\.from_pretrained\(.*?\)", "tokenizer = ProteinTokenizer()", content)
    
    # 3. lora dict
    content = re.sub(r"'lora_modules' : '.*?'.*?'lora_trainable_param_names' : '.*?'", 
                     "'lora_modules' : '.*mixer.*',\n            'lora_layers' : 'in_proj|out_proj|x_proj|dt_proj',\n            'lora_trainable_param_names' : '.*norm.*|.*lora_[ab].*'", 
                     content, flags=re.DOTALL)
                     
    # Dual channel data fetching
    if mode == "DualChannel":
        # in __main__ loop:
        # train_ids = train_data['input_ids']
        # add cons_ids
        content = content.replace("train_mask = train_data['attention_mask'].to(device, dtype=torch.int)",
                                  "train_cons = train_data['cons_ids'].to(device, dtype=torch.int)\n            train_mask = train_data['attention_mask'].to(device, dtype=torch.int)")
        content = content.replace("train_outputs = model(train_ids, train_mask)",
                                  "train_outputs = model(train_ids, train_cons, train_mask)")
                                  
        content = content.replace("tmp_mask = tmp_data['attention_mask'].to(device, dtype=torch.int)",
                                  "tmp_cons = tmp_data['cons_ids'].to(device, dtype=torch.int)\n            tmp_mask = tmp_data['attention_mask'].to(device, dtype=torch.int)")
        content = content.replace("tmp_outputs = model(tmp_ids, tmp_mask)",
                                  "tmp_outputs = model(tmp_ids, tmp_cons, tmp_mask)")

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def main():
    import glob
    for dataset in DATASETS:
        for mode in MODES:
            d = os.path.join("finetuning", dataset, mode)
            if not os.path.exists(d):
                continue
            
            models_path = os.path.join(d, "models.py")
            if os.path.exists(models_path):
                patch_models_py(models_path, mode)
                print(f"Patched {models_path}")
                
            for fname in os.listdir(d):
                if fname.startswith("train_") and fname.endswith(".py"):
                    train_path = os.path.join(d, fname)
                    patch_train_py(train_path, mode)
                    print(f"Patched {train_path}")

if __name__ == "__main__":
    main()
