import os
import json
import numpy as np
from datasets import Dataset, DatasetDict
from typing import Dict, Optional
from pydantic import BaseModel


class SingleChannelPretrainConfig(BaseModel):
    dataset_loc: str  # e.g. "data/tokenized/pretrain"
    val_size: int = 1000
    test_size: int = 0
    split_seed: int = 42
    max_sequence_length: Optional[int] = 1024


def load_pretokenized_npz(data_dir: str):
    npz_path = os.path.join(data_dir, "train.npz")
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"Missing {npz_path}")

    # Load arrays
    data = np.load(npz_path, allow_pickle=True)
    aa_ids_list = data["aa_ids"]
    labels = data["labels"]

    # Convert to list of lists for HuggingFace Dataset
    # (HuggingFace datasets requires native python lists or arrays)
    aa_ids_list = [arr.tolist() for arr in aa_ids_list]

    dataset_dict = {
        "input_ids": aa_ids_list,
        "labels": labels.tolist()
    }
    return Dataset.from_dict(dataset_dict)


def get_single_channel_dataset(config_dict: Dict, tokenizer=None) -> DatasetDict:
    config = SingleChannelPretrainConfig(**config_dict)
    
    ds = load_pretokenized_npz(config.dataset_loc)
    ds = ds.shuffle(seed=config.split_seed)
    
    valtest_size = config.val_size + config.test_size
    
    if valtest_size > 0:
        train_valtest = ds.train_test_split(
            test_size=valtest_size,
            shuffle=False,
        )
        split_dict = {
            "train": train_valtest["train"],
        }
        if config.test_size > 0 and config.val_size > 0:
            test_val = train_valtest["test"].train_test_split(
                test_size=config.test_size,
                shuffle=False,
            )
            split_dict["val"] = test_val["train"]
            split_dict["test"] = test_val["test"]
        elif config.val_size > 0:
            split_dict["val"] = train_valtest["test"]
        else:
            split_dict["test"] = train_valtest["test"]
    else:
        split_dict = {
            "train": ds,
        }
        
    return DatasetDict(split_dict)
