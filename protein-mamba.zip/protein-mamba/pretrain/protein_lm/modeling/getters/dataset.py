import pandas as pd
from typing import Dict, Literal, Optional
from datasets import Dataset, load_dataset
from datasets.dataset_dict import DatasetDict
from pydantic import BaseModel
from protein_lm.modeling.getters.ptm_dataset import get_ptm_dataset
from protein_lm.modeling.getters.uniref_dataset import get_uniref_dataset


def get_dataset(config_dict: Dict, tokenizer) -> Dataset:
    if config_dict["dataset"] == "ptm":
        from protein_lm.modeling.getters.ptm_dataset import get_ptm_dataset
        return get_ptm_dataset(config_dict, tokenizer)
    elif config_dict["dataset"] == "uniref50":
        from protein_lm.modeling.getters.uniref_dataset import get_uniref_dataset
        return get_uniref_dataset(config_dict, tokenizer)
    elif config_dict["dataset"] == "single_channel_pretrain":
        from protein_lm.modeling.getters.single_channel_dataset import get_single_channel_dataset
        return get_single_channel_dataset(config_dict, tokenizer)
    else:
        raise ValueError(f"Invalid dataset {config_dict['dataset']}!")
