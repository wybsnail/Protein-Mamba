"""PDB 单链蛋白质预训练语料下载脚本

从 RCSB Protein Data Bank 下载单链蛋白质序列，
用于 Protein-Mamba 模型预训练。

目标：~27,000 条单链蛋白质序列。

流程：
  1. 用 RCSB Search API 查询所有单链蛋白质的 PDB entry ID
  2. 批量下载 FASTA 序列
  3. 提取、去重、过滤，保存为预训练语料

用法：
    python prepare_pretrain.py
    python prepare_pretrain.py --max-entries 30000 --min-length 30 --max-length 1024
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import time
from pathlib import Path

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "data" / "pretrain"

# ═══════════════════════════════════════════════════════════════
# 1. RCSB PDB Search API — 查询单链蛋白质
# ═══════════════════════════════════════════════════════════════

SEARCH_API = "https://search.rcsb.org/rcsbsearch/v2/query"


def search_single_chain_proteins(max_results: int = 50000) -> list[str]:
    """用 RCSB Search API 查询单链蛋白质的 PDB entry ID。

    筛选条件：恰好 1 个蛋白质 entity。
    后续在 FASTA 阶段再过滤多 entity (DNA/RNA) 的 entry。

    Returns:
        PDB entry ID 列表。
    """
    query = {
        "query": {
            "type": "terminal",
            "service": "text",
            "parameters": {
                "attribute": "rcsb_entry_info.polymer_entity_count_protein",
                "operator": "equals",
                "value": 1
            }
        },
        "return_type": "entry",
        "request_options": {
            "paginate": {"start": 0, "rows": 0}
        }
    }

    print(f"  正在查询 RCSB PDB (单蛋白质 entity) ...")
    pdb_ids = []
    page_size = 10000

    # 先获取总数
    query["request_options"]["paginate"]["rows"] = 1
    query_json = json.dumps(query, separators=(",", ":"))
    resp = requests.get(
        SEARCH_API, params={"json": query_json}, verify=False, timeout=120
    )
    resp.raise_for_status()
    total_count = resp.json().get("total_count", 0)
    print(f"    总共: {total_count:,} 个 entry (将取前 {max_results:,})")

    # 分页下载
    to_fetch = min(total_count, max_results)
    for start in range(0, to_fetch, page_size):
        rows = min(page_size, to_fetch - start)
        query["request_options"]["paginate"] = {"start": start, "rows": rows}
        query_json = json.dumps(query, separators=(",", ":"))

        for attempt in range(3):
            try:
                resp = requests.get(
                    SEARCH_API, params={"json": query_json},
                    verify=False, timeout=120,
                )
                resp.raise_for_status()
                break
            except Exception as e:
                print(f"    [重试 {attempt+1}/3] 页 {start//page_size+1} 失败: {e}")
                if attempt == 2:
                    raise
                time.sleep(3)

        page_ids = [r["identifier"] for r in resp.json().get("result_set", [])]
        pdb_ids.extend(page_ids)
        print(f"    页 {start//page_size+1}: +{len(page_ids):,} (累计 {len(pdb_ids):,})")

    print(f"  ✓ 获取到 {len(pdb_ids):,} 个 PDB entry ID")
    return pdb_ids


# ═══════════════════════════════════════════════════════════════
# 2. 批量下载 FASTA 序列
# ═══════════════════════════════════════════════════════════════

FASTA_API = "https://www.rcsb.org/fasta/entry"


def download_fasta_batch(
    pdb_ids: list[str],
    batch_size: int = 200,
) -> dict[str, str]:
    """批量下载 PDB entry 的 FASTA 序列。

    Returns:
        {pdb_id: sequence} 字典。
    """
    all_sequences: dict[str, str] = {}
    total = len(pdb_ids)

    for i in range(0, total, batch_size):
        batch = pdb_ids[i:i + batch_size]
        batch_ids = ",".join(batch)
        url = f"{FASTA_API}/{batch_ids}"

        try:
            resp = requests.get(url, verify=False, timeout=120)
            resp.raise_for_status()
            fasta_text = resp.text

            # 解析 FASTA
            current_id = None
            current_seq = []
            for line in fasta_text.strip().split("\n"):
                if line.startswith(">"):
                    if current_id and current_seq:
                        # 取 PDB ID（前 4 位）
                        all_sequences[current_id] = "".join(current_seq)
                    # 解析 header: >PDBID_ENTITY|...
                    header = line[1:].split("|")[0].strip()
                    pdb_part = header.split("_")[0] if "_" in header else header[:4]
                    current_id = header  # 用完整 ID 作为 key
                    current_seq = []
                else:
                    current_seq.append(line.strip())

            # 最后一条
            if current_id and current_seq:
                all_sequences[current_id] = "".join(current_seq)

        except Exception as e:
            print(f"    [警告] 批次 {i//batch_size + 1} 下载失败: {e}")

        done = min(i + batch_size, total)
        if (i // batch_size) % 10 == 0 or done == total:
            print(f"    进度: {done:,}/{total:,} ({done/total*100:.1f}%)")
        time.sleep(0.2)  # 限频

    return all_sequences


# ═══════════════════════════════════════════════════════════════
# 3. 过滤与去重
# ═══════════════════════════════════════════════════════════════

STANDARD_AA = set("ACDEFGHIKLMNPQRSTVWY")


def filter_sequences(
    sequences: dict[str, str],
    min_length: int = 30,
    max_length: int = 1024,
) -> dict[str, str]:
    """过滤并去重蛋白质序列。

    过滤条件：
      - 长度在 [min_length, max_length] 之间
      - 仅含标准 20 种氨基酸（去除含 X/U/O 等非标 AA 的序列）
      - 去除完全相同的序列（基于 MD5 去重）
    """
    seen_hashes: set[str] = set()
    filtered: dict[str, str] = {}

    n_short, n_long, n_nonstandard, n_dup = 0, 0, 0, 0

    for entry_id, seq in sequences.items():
        seq = seq.upper().strip()

        if len(seq) < min_length:
            n_short += 1
            continue
        if len(seq) > max_length:
            n_long += 1
            continue

        # 检查非标 AA
        if not all(c in STANDARD_AA for c in seq):
            n_nonstandard += 1
            continue

        # 去重
        seq_hash = hashlib.md5(seq.encode()).hexdigest()
        if seq_hash in seen_hashes:
            n_dup += 1
            continue
        seen_hashes.add(seq_hash)

        filtered[entry_id] = seq

    print(f"  过滤结果:")
    print(f"    总序列: {len(sequences):,}")
    print(f"    过短 (<{min_length}): {n_short:,}")
    print(f"    过长 (>{max_length}): {n_long:,}")
    print(f"    非标氨基酸: {n_nonstandard:,}")
    print(f"    重复序列: {n_dup:,}")
    print(f"    ✓ 保留: {len(filtered):,}")
    return filtered


# ═══════════════════════════════════════════════════════════════
# 4. 保存
# ═══════════════════════════════════════════════════════════════

def save_pretrain_corpus(
    sequences: dict[str, str],
    output_dir: Path,
) -> None:
    """保存预训练语料为 FASTA + CSV 格式。"""
    output_dir.mkdir(parents=True, exist_ok=True)

    # FASTA 文件
    fasta_path = output_dir / "pretrain_sequences.fasta"
    with open(fasta_path, "w", encoding="utf-8") as f:
        for entry_id, seq in sequences.items():
            f.write(f">{entry_id}\n")
            # 每行 80 字符
            for j in range(0, len(seq), 80):
                f.write(seq[j:j+80] + "\n")

    # CSV 文件 (方便后续 tokenize)
    csv_path = output_dir / "pretrain_sequences.csv"
    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["entry_id", "sequence", "length"])
        for entry_id, seq in sequences.items():
            writer.writerow([entry_id, seq, len(seq)])

    # 元数据
    lengths = [len(s) for s in sequences.values()]
    meta = {
        "total_sequences": len(sequences),
        "avg_length": sum(lengths) / len(lengths) if lengths else 0,
        "min_length": min(lengths) if lengths else 0,
        "max_length": max(lengths) if lengths else 0,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    meta_path = output_dir / "metadata.json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)

    print(f"\n  已保存:")
    print(f"    FASTA: {fasta_path}")
    print(f"    CSV:   {csv_path}")
    print(f"    统计:  {meta['total_sequences']:,} 条序列, "
          f"平均长度 {meta['avg_length']:.1f}, "
          f"范围 [{meta['min_length']}, {meta['max_length']}]")


# ═══════════════════════════════════════════════════════════════
# 主函数
# ═══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="PDB 单链蛋白质预训练语料下载")
    parser.add_argument("--max-entries", type=int, default=50000,
                        help="查询最大 entry 数 (default: 50000)")
    parser.add_argument("--min-length", type=int, default=30,
                        help="最短序列长度 (default: 30)")
    parser.add_argument("--max-length", type=int, default=1024,
                        help="最长序列长度 (default: 1024)")
    parser.add_argument("--batch-size", type=int, default=200,
                        help="FASTA 下载批次大小 (default: 200)")
    args = parser.parse_args()

    print("🚀 PDB 单链蛋白质预训练语料准备")
    print("=" * 60)

    # Step 1: 查询单链蛋白质
    print("\n[1/3] 查询 RCSB PDB ...")
    pdb_ids = search_single_chain_proteins(max_results=args.max_entries)
    print(f"  获取到 {len(pdb_ids):,} 个 PDB entry ID")

    # Step 2: 下载 FASTA 序列
    print(f"\n[2/3] 下载 FASTA 序列 (batch_size={args.batch_size}) ...")
    raw_sequences = download_fasta_batch(pdb_ids, batch_size=args.batch_size)
    print(f"  ✓ 下载到 {len(raw_sequences):,} 条序列")

    # Step 3: 过滤去重
    print(f"\n[3/3] 过滤与去重 ...")
    filtered = filter_sequences(
        raw_sequences,
        min_length=args.min_length,
        max_length=args.max_length,
    )

    # 保存
    save_pretrain_corpus(filtered, OUTPUT_DIR)

    print(f"\n{'='*60}")
    print(f"✅ 预训练语料准备完成！")
    print(f"   目标: ~27,043 条  |  实际: {len(filtered):,} 条")
    print(f"   输出目录: {OUTPUT_DIR.resolve()}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
