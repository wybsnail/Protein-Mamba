import argparse
import csv
import os
from types import SimpleNamespace

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
from omegaconf import OmegaConf
from sklearn.manifold import TSNE
from sklearn.metrics import pairwise_distances, silhouette_score

from pretrain.protein_lm.modeling.models.mamba.lm import MambaLMHeadModel
from pretrain.protein_lm.tokenizer.tokenizer import PTMTokenizer


def load_model(ckpt_path):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Loading checkpoint from {ckpt_path} on {device}...")

    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model_state_dict = ckpt["model"]
    raw_config = OmegaConf.to_container(ckpt["config"], resolve=True)
    model_config = SimpleNamespace(**raw_config)
    model_config.d_model = int(model_config.d_model)
    model_config.n_layer = int(model_config.n_layer)
    if model_config.vocab_size is None:
        model_config.vocab_size = int(model_state_dict["backbone.embedding.weight"].shape[0])
    else:
        model_config.vocab_size = int(model_config.vocab_size)
    if hasattr(model_config, "esm_embed_dim"):
        model_config.esm_embed_dim = int(model_config.esm_embed_dim)
    model_config.fused_add_norm = False
    model_config.rms_norm = False

    model = MambaLMHeadModel(config=model_config).to(device)
    model.load_state_dict(model_state_dict, strict=False)
    model.eval()
    tokenizer = PTMTokenizer()
    return model, tokenizer, device


def read_labeled_sequences(
    csv_path,
    sequence_col,
    label_col=None,
    class_a=None,
    class_b=None,
    max_samples=None,
    color_by_length=False,
):
    sequences = []
    labels = []

    with open(csv_path, "r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if sequence_col not in reader.fieldnames:
            raise ValueError(f"Column '{sequence_col}' not found in {csv_path}")
        if label_col is not None and label_col not in reader.fieldnames:
            raise ValueError(f"Column '{label_col}' not found in {csv_path}")

        for row in reader:
            seq = (row.get(sequence_col) or "").strip()
            if label_col is None:
                lbl = "pretrain"
            else:
                lbl = (row.get(label_col) or "").strip()

            if not seq or not lbl:
                continue
            if label_col is not None and class_a is not None and class_b is not None and lbl not in {class_a, class_b}:
                continue

            if color_by_length:
                seq_len = len(seq.replace(" ", ""))
                if seq_len < 150:
                    lbl = "len<150"
                elif seq_len < 300:
                    lbl = "150<=len<300"
                else:
                    lbl = "len>=300"

            sequences.append(seq)
            labels.append(lbl)
            if max_samples is not None and len(sequences) >= max_samples:
                break

    unique_labels = sorted(set(labels))
    if len(unique_labels) < 1:
        raise ValueError("No valid samples found after filtering.")

    return sequences, labels


def get_sequence_embeddings(model, tokenizer, sequences, device):
    embeddings = []
    with torch.no_grad():
        for idx, sequence in enumerate(sequences):
            input_ids = tokenizer(sequence.replace(" ", ""), return_tensor=True).unsqueeze(0).to(device)
            input_ids = torch.where(
                input_ids < model.config.vocab_size,
                input_ids,
                torch.full_like(input_ids, 3),
            )
            outputs = model(input_ids)
            hidden_states = outputs.hidden_states
            seq_emb = torch.mean(hidden_states, dim=1).squeeze().cpu().numpy()
            embeddings.append(seq_emb)

            if (idx + 1) % 100 == 0:
                print(f"Encoded {idx + 1}/{len(sequences)} sequences")

    return np.array(embeddings)


def compute_metrics(embeddings, labels):
    labels = np.array(labels)
    unique = sorted(set(labels.tolist()))
    if len(unique) != 2:
        return {
            "available": False,
            "reason": f"Metrics currently support 2 classes; got {len(unique)} classes.",
            "classes": unique,
            "n_samples": int(len(labels)),
        }

    class_a, class_b = unique
    mask_a = labels == class_a
    mask_b = labels == class_b
    n_a = int(mask_a.sum())
    n_b = int(mask_b.sum())
    if n_a < 2 or n_b < 2:
        return {
            "available": False,
            "reason": "Each class needs at least 2 samples.",
            "classes": unique,
            "n_class_a": n_a,
            "n_class_b": n_b,
        }

    y = np.where(labels == class_a, 0, 1)
    silhouette = float(silhouette_score(embeddings, y, metric="euclidean"))

    emb_a = embeddings[mask_a]
    emb_b = embeddings[mask_b]
    dist_a = pairwise_distances(emb_a, metric="euclidean")
    dist_b = pairwise_distances(emb_b, metric="euclidean")
    dist_ab = pairwise_distances(emb_a, emb_b, metric="euclidean")

    mean_intra_a = float(dist_a[np.triu_indices_from(dist_a, k=1)].mean())
    mean_intra_b = float(dist_b[np.triu_indices_from(dist_b, k=1)].mean())
    mean_intra = (mean_intra_a + mean_intra_b) / 2.0
    mean_inter = float(dist_ab.mean())

    center_a = emb_a.mean(axis=0)
    center_b = emb_b.mean(axis=0)
    center_dist = float(np.linalg.norm(center_a - center_b))

    return {
        "available": True,
        "classes": unique,
        "n_samples": int(len(labels)),
        "n_class_a": n_a,
        "n_class_b": n_b,
        "silhouette_score": silhouette,
        "mean_intra_class_distance": mean_intra,
        "mean_inter_class_distance": mean_inter,
        "inter_over_intra_ratio": float(mean_inter / (mean_intra + 1e-12)),
        "centroid_distance": center_dist,
    }


def main():
    parser = argparse.ArgumentParser(description="t-SNE for Mamba pretrain sequence embeddings")
    parser.add_argument("--ckpt_path", type=str, required=True, help="Path to pretrain checkpoint")
    parser.add_argument("--csv_path", type=str, required=True, help="CSV with sequence and label columns")
    parser.add_argument("--sequence_col", type=str, default="sequence", help="Sequence column name")
    parser.add_argument("--label_col", type=str, default=None, help="Label column name (optional)")
    parser.add_argument("--class_a", type=str, default=None, help="Optional class A filter")
    parser.add_argument("--class_b", type=str, default=None, help="Optional class B filter")
    parser.add_argument("--color_by_length", action="store_true", help="Color by sequence length bins")
    parser.add_argument("--max_samples", type=int, default=None, help="Optional max rows to load")
    parser.add_argument("--perplexity", type=float, default=30.0, help="t-SNE perplexity")
    parser.add_argument("--random_state", type=int, default=42, help="t-SNE random seed")
    parser.add_argument("--output_dir", type=str, default="./outputs/tsne_mamba_pretrain", help="Output directory")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    sequences, labels = read_labeled_sequences(
        csv_path=args.csv_path,
        sequence_col=args.sequence_col,
        label_col=args.label_col,
        class_a=args.class_a,
        class_b=args.class_b,
        max_samples=args.max_samples,
        color_by_length=args.color_by_length,
    )
    print(f"Loaded {len(sequences)} sequences from {args.csv_path}")
    print(f"Classes: {sorted(set(labels))}")

    model, tokenizer, device = load_model(args.ckpt_path)
    embeddings = get_sequence_embeddings(model, tokenizer, sequences, device)

    n = len(embeddings)
    if n < 4:
        raise ValueError("Need at least 4 samples to run t-SNE robustly.")

    perplexity = min(args.perplexity, max(2.0, n - 1.0))
    tsne = TSNE(n_components=2, perplexity=perplexity, random_state=args.random_state)
    projected = tsne.fit_transform(embeddings)

    plt.figure(figsize=(10, 8))
    unique_labels = sorted(set(labels))
    if len(unique_labels) > 1:
        sns.scatterplot(x=projected[:, 0], y=projected[:, 1], hue=labels, s=85, alpha=0.8)
    else:
        sns.scatterplot(x=projected[:, 0], y=projected[:, 1], s=85, alpha=0.8, color="steelblue")
    plt.title("t-SNE of Mamba Pretrain Sequence Embeddings", fontsize=14)
    plt.xlabel("t-SNE Dimension 1")
    plt.ylabel("t-SNE Dimension 2")
    plt.grid(True, linestyle="--", alpha=0.6)
    if len(unique_labels) > 1:
        plt.legend(title=args.label_col if args.label_col is not None else "label")

    fig_path = os.path.join(args.output_dir, "tsne_mamba_pretrain.png")
    plt.savefig(fig_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Saved t-SNE plot to {fig_path}")

    metrics = compute_metrics(embeddings, labels)
    metrics_path = os.path.join(args.output_dir, "quantitative_metrics.txt")
    with open(metrics_path, "w", encoding="utf-8") as handle:
        for key, value in metrics.items():
            handle.write(f"{key}: {value}\n")

    print(f"Saved metrics to {metrics_path}")
    if metrics.get("available"):
        print(
            "Metrics | "
            f"silhouette={metrics['silhouette_score']:.4f}, "
            f"inter={metrics['mean_inter_class_distance']:.4f}, "
            f"intra={metrics['mean_intra_class_distance']:.4f}, "
            f"inter/intra={metrics['inter_over_intra_ratio']:.4f}, "
            f"centroid={metrics['centroid_distance']:.4f}"
        )
    else:
        print(f"Metrics unavailable: {metrics.get('reason')}")


if __name__ == "__main__":
    main()
