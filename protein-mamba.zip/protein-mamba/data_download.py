"""蛋白质结构数据下载模块

从 RCSB Protein Data Bank 下载蛋白质 PDB 结构文件。
从 UniProt 下载 SwissProt 数据库（用于 PTM 标签提取）。
提取自 ESM.ipynb Cell 5 及 Bio-SCAN-Mamba/ptm_data_preprocessing。
"""

import gzip
import io
import os
import shutil
import zipfile
from pathlib import Path

import requests
import urllib3

# 忽略 SSL 验证警告（某些网络环境下需要）
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── 项目根目录 ──
PROJECT_ROOT = Path(__file__).parent
DATA_DIR = PROJECT_ROOT / "data"


# ═══════════════════════════════════════════════════════════════
# 1. PDB 蛋白质结构文件
# ═══════════════════════════════════════════════════════════════

# 蛋白质名称到 PDB ID 的映射示例
protein_to_pdb = {
    "insulin": "3I40",      # Human. Involved in sugar metabolism.
    "collagen": "1BKV",     # Human. Involved in structural roles.
    "proteasome": "1YAR",   # Archeabacterial. Involved in degradation.
}


def fetch_protein_structure(pdb_id: str) -> str:
    """从 RCSB Protein Data Bank 下载 PDB 蛋白质结构。"""
    url = f"https://files.rcsb.org/download/{pdb_id}.pdb"
    response = requests.get(url, verify=False)
    response.raise_for_status()
    return response.text


def download_pdb_files():
    """下载全部 PDB 蛋白质结构文件到 data/pdb/。"""
    save_dir = DATA_DIR / "pdb"
    save_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("[1/3] 下载 PDB 蛋白质结构文件")
    print("=" * 60)

    for name, pdb_id in protein_to_pdb.items():
        save_path = save_dir / f"{pdb_id}.pdb"
        if save_path.exists():
            print(f"  [跳过] {name} ({pdb_id}) 已存在")
            continue

        print(f"  正在下载 {name} (PDB ID: {pdb_id}) ...")
        structure = fetch_protein_structure(pdb_id)
        save_path.write_text(structure, encoding="utf-8")
        print(f"  ✓ 已保存 ({len(structure):,} 字符)")

    print()


# ═══════════════════════════════════════════════════════════════
# 2. UniProt SwissProt 数据库（PTM 标签提取用）
# ═══════════════════════════════════════════════════════════════

UNIPROT_FILES = {
    "uniprot_sprot.dat.gz": "https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.dat.gz",
    "uniprot_sprot.fasta.gz": "https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz",
}


def _download_large_file(url: str, dest: Path):
    """流式下载大文件，显示进度。"""
    print(f"  正在下载 {url}")
    print(f"  → {dest}")
    with requests.get(url, stream=True, verify=False) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        downloaded = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024 * 1024):  # 1 MB chunks
                f.write(chunk)
                downloaded += len(chunk)
                if total:
                    pct = downloaded / total * 100
                    print(f"\r  进度: {downloaded / 1024 / 1024:.1f} MB / {total / 1024 / 1024:.1f} MB ({pct:.1f}%)", end="", flush=True)
                else:
                    print(f"\r  已下载: {downloaded / 1024 / 1024:.1f} MB", end="", flush=True)
    print(f"\n  ✓ 下载完成")


def _decompress_gz(gz_path: Path, out_path: Path):
    """解压 .gz 文件。"""
    print(f"  正在解压 {gz_path.name} → {out_path.name} ...")
    with gzip.open(gz_path, "rb") as f_in:
        with open(out_path, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
    print(f"  ✓ 解压完成 ({out_path.stat().st_size / 1024 / 1024:.1f} MB)")


def download_uniprot_data():
    """下载 UniProt SwissProt DAT 和 FASTA 文件到 data/uniprot/。"""
    save_dir = DATA_DIR / "uniprot"
    save_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("[2/3] 下载 UniProt SwissProt 数据库")
    print("  （注意：文件较大，约 600MB 压缩 / 数 GB 解压）")
    print("=" * 60)

    for filename, url in UNIPROT_FILES.items():
        gz_path = save_dir / filename
        extracted_name = filename.replace(".gz", "")
        extracted_path = save_dir / extracted_name

        # 如果解压后的文件已存在，跳过
        if extracted_path.exists():
            print(f"  [跳过] {extracted_name} 已存在")
            continue

        # 下载 .gz
        if not gz_path.exists():
            _download_large_file(url, gz_path)
        else:
            print(f"  [跳过下载] {filename} 已存在，直接解压")

        # 解压
        _decompress_gz(gz_path, extracted_path)

    print()


# ═══════════════════════════════════════════════════════════════
# 3. ESM2 预训练模型（HuggingFace 自动下载缓存）
# ═══════════════════════════════════════════════════════════════

DEFAULT_EMBEDDING_CHECKPOINT = "facebook/esm2_t33_650M_UR50D"
DEFAULT_MASKED_LM_CHECKPOINT = "facebook/esm2_t30_150M_UR50D"


def download_esm_models():
    """预下载 ESM2 模型权重到 HuggingFace 缓存。"""
    print("=" * 60)
    print("[3/4] 预下载 ESM2 模型权重")
    print("=" * 60)

    try:
        from transformers import AutoTokenizer, EsmModel, EsmForMaskedLM

        for name, ckpt in [
            ("Embedding 模型", DEFAULT_EMBEDDING_CHECKPOINT),
            ("Masked LM 模型", DEFAULT_MASKED_LM_CHECKPOINT),
        ]:
            print(f"  正在下载 {name}: {ckpt} ...")
            AutoTokenizer.from_pretrained(ckpt)
            if "Masked" in name:
                EsmForMaskedLM.from_pretrained(ckpt)
            else:
                EsmModel.from_pretrained(ckpt)
            print(f"  ✓ {name} 下载完成")

    except ImportError:
        print("  [跳过] transformers 未安装，跳过模型下载")
        print("  请运行: pip install transformers torch")

    print()


# ═══════════════════════════════════════════════════════════════
# 4. 蛋白质基准数据集
# ═══════════════════════════════════════════════════════════════

BENCHMARK_DIR = DATA_DIR / "benchmark"

# FLIP benchmark 数据 hosted at bioembeddings.com
FLIP_BASE_URL = "http://data.bioembeddings.com/public/FLIP/unpacked"

# FLIP GitHub splits
FLIP_SPLITS_BASE = "https://github.com/J-SNACKKB/FLIP/raw/main/splits"


def _hf_dataset_to_csv(dataset_name: str, save_dir: Path, label: str = "all"):
    """从 HuggingFace datasets 下载数据集并保存为 CSV。"""
    from datasets import load_dataset

    print(f"  正在从 HuggingFace 加载 {dataset_name} ...")
    try:
        ds = load_dataset(dataset_name, trust_remote_code=True)
    except TypeError:
        # 旧版 datasets 不支持 trust_remote_code
        ds = load_dataset(dataset_name)

    save_dir.mkdir(parents=True, exist_ok=True)
    for split_name, split_data in ds.items():
        csv_path = save_dir / f"{split_name}.csv"
        split_data.to_csv(str(csv_path), index=False)
        print(f"    ✓ {split_name}: {len(split_data):,} 条 → {csv_path.name}")


def _download_and_extract_zip(url: str, save_dir: Path):
    """下载 zip 文件并解压到指定目录。"""
    print(f"  正在下载 {url} ...")
    resp = requests.get(url, verify=False, stream=True, timeout=120)
    resp.raise_for_status()
    data = io.BytesIO(resp.content)
    with zipfile.ZipFile(data) as zf:
        zf.extractall(save_dir)
        names = zf.namelist()
    print(f"    ✓ 解压 {len(names)} 个文件到 {save_dir.name}/")


def _download_csv(url: str, dest: Path):
    """下载单个 CSV 文件。"""
    print(f"  正在下载 → {dest.name} ...")
    resp = requests.get(url, verify=False, timeout=120)
    resp.raise_for_status()
    dest.write_bytes(resp.content)
    size_mb = dest.stat().st_size / 1024 / 1024
    print(f"    ✓ 已保存 ({size_mb:.1f} MB)")


# ── 4.1 DeepSol（溶解度，二元分类，~71K）──

def download_deepsol():
    """从 HuggingFace AI4Protein/DeepSol 下载溶解度数据集。"""
    save_dir = BENCHMARK_DIR / "deepsol"
    marker = save_dir / "train.csv"
    if marker.exists():
        print("  [跳过] DeepSol 已存在")
        return

    try:
        _hf_dataset_to_csv("AI4Protein/DeepSol", save_dir)
    except Exception as e:
        print(f"  [错误] DeepSol 下载失败: {e}")


# ── 4.2 FLIP-Thermostability（热稳定性，连续值，~7K）──

def download_flip_thermostability():
    """从 HuggingFace AI4Protein/Thermostability 下载热稳定性数据集。"""
    save_dir = BENCHMARK_DIR / "flip_thermostability"
    marker = save_dir / "train.csv"
    if marker.exists():
        print("  [跳过] FLIP-Thermostability 已存在")
        return

    try:
        _hf_dataset_to_csv("AI4Protein/Thermostability", save_dir)
    except Exception as e:
        print(f"  [错误] FLIP-Thermostability 下载失败: {e}")


# ── 4.3 FLIP-GB1（GB1 适应度，连续值，~8.7K）──

def download_flip_gb1():
    """从 FLIP benchmark 下载 GB1 适应度数据集。"""
    save_dir = BENCHMARK_DIR / "flip_gb1"
    save_dir.mkdir(parents=True, exist_ok=True)
    marker = save_dir / "gb1.csv.gz"
    if marker.exists() or (save_dir / "gb1.csv").exists():
        print("  [跳过] FLIP-GB1 已存在")
        return

    try:
        # 下载 splits zip
        zip_url = f"{FLIP_SPLITS_BASE}/gb1/splits.zip"
        _download_and_extract_zip(zip_url, save_dir)

        # 下载原始数据
        csv_url = f"{FLIP_BASE_URL}/gb1/gb1.csv.gz"
        dest = save_dir / "gb1.csv.gz"
        _download_csv(csv_url, dest)
        # 解压 .gz
        out = save_dir / "gb1.csv"
        _decompress_gz(dest, out)
        print(f"    ✓ GB1 数据已保存")
    except Exception as e:
        print(f"  [错误] FLIP-GB1 下载失败: {e}")


# ── 4.4 FLIP-AAV（AAV 适应度，连续值，~82K）──

def download_flip_aav():
    """从 FLIP benchmark 下载 AAV 适应度数据集。"""
    save_dir = BENCHMARK_DIR / "flip_aav"
    save_dir.mkdir(parents=True, exist_ok=True)
    marker = save_dir / "full_data.csv.gz"
    if marker.exists() or (save_dir / "full_data.csv").exists():
        print("  [跳过] FLIP-AAV 已存在")
        return

    try:
        # 下载 splits zip
        zip_url = f"{FLIP_SPLITS_BASE}/aav/splits.zip"
        _download_and_extract_zip(zip_url, save_dir)

        # 下载原始数据
        csv_url = f"{FLIP_BASE_URL}/aav/full_data.csv.gz"
        dest = save_dir / "full_data.csv.gz"
        _download_csv(csv_url, dest)
        # 解压 .gz
        out = save_dir / "full_data.csv"
        _decompress_gz(dest, out)
        print(f"    ✓ AAV 数据已保存")
    except Exception as e:
        print(f"  [错误] FLIP-AAV 下载失败: {e}")


# ── 4.5 Sarkisyan（荧光强度，连续值，~54K）──

def download_sarkisyan():
    """从 HuggingFace 下载 Sarkisyan GFP 荧光强度数据集 (TAPE benchmark)。"""
    save_dir = BENCHMARK_DIR / "sarkisyan"
    marker = save_dir / "train.csv"
    if marker.exists():
        print("  [跳过] Sarkisyan 已存在")
        return

    try:
        _hf_dataset_to_csv("AI4Protein/TAPE_Fluorescence", save_dir)
    except Exception:
        try:
            print("  回退到 SaProtHub/Dataset-Fluorescence-TAPE ...")
            _hf_dataset_to_csv("SaProtHub/Dataset-Fluorescence-TAPE", save_dir)
        except Exception as e:
            print(f"  [错误] Sarkisyan 下载失败: {e}")
            print("  提示: 可手动从 https://github.com/songlab-cal/tape 获取")


# ── 4.6 Envision（酶活性，连续值，~5.2K）──

def download_envision():
    """下载 Envision β-lactamase 酶活性数据集 (TAPE benchmark)。"""
    save_dir = BENCHMARK_DIR / "envision"
    marker = save_dir / "train.csv"
    if marker.exists():
        print("  [跳过] Envision 已存在")
        return

    try:
        _hf_dataset_to_csv("AI4Protein/TAPE_Beta_Lactamase", save_dir)
    except Exception:
        try:
            print("  回退到 hazemessam/beta-lactamase ...")
            _hf_dataset_to_csv("hazemessam/beta-lactamase", save_dir)
        except Exception as e:
            print(f"  [错误] Envision 下载失败: {e}")
            print("  提示: 请手动从 https://envision.gs.washington.edu 下载数据")


# ── 4.7 Rocklin（稳定性，连续值，~69K）──

def download_rocklin():
    """从 HuggingFace 下载 Rocklin 蛋白质稳定性数据集 (TAPE benchmark)。"""
    save_dir = BENCHMARK_DIR / "rocklin"
    marker = save_dir / "train.csv"
    if marker.exists():
        print("  [跳过] Rocklin 已存在")
        return

    try:
        _hf_dataset_to_csv("AI4Protein/TAPE_Stability", save_dir)
    except Exception:
        try:
            print("  回退到 SaProtHub/Dataset-Stability-TAPE ...")
            _hf_dataset_to_csv("SaProtHub/Dataset-Stability-TAPE", save_dir)
        except Exception as e:
            print(f"  [错误] Rocklin 下载失败: {e}")
            print("  提示: 请手动从 https://doi.org/10.5281/zenodo.7401275 下载")


def download_benchmark_datasets():
    """下载全部 7 个蛋白质基准数据集。"""
    BENCHMARK_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("[4/4] 下载蛋白质基准数据集")
    print("=" * 60)

    datasets_funcs = [
        ("1. DeepSol (溶解度)", download_deepsol),
        ("2. FLIP-Thermostability (热稳定性)", download_flip_thermostability),
        ("3. FLIP-GB1 (GB1 适应度)", download_flip_gb1),
        ("4. FLIP-AAV (AAV 适应度)", download_flip_aav),
        ("5. Sarkisyan (荧光强度)", download_sarkisyan),
        ("6. Envision (酶活性)", download_envision),
        ("7. Rocklin (稳定性)", download_rocklin),
    ]

    for label, func in datasets_funcs:
        print(f"\n── {label} ──")
        func()

    print()
    print("  ✓ 基准数据集下载流程完成")
    print()


# ═══════════════════════════════════════════════════════════════
# 主函数
# ═══════════════════════════════════════════════════════════════

def main():
    """下载全部项目数据。"""
    print("🚀 Protein-Mamba 数据下载工具")
    print("=" * 60)
    print()

    download_pdb_files()
    download_uniprot_data()
    download_esm_models()
    download_benchmark_datasets()

    # 汇总
    print("=" * 60)
    print("✅ 全部数据下载完成！")
    print("=" * 60)
    print(f"数据目录: {DATA_DIR.resolve()}")
    for child in sorted(DATA_DIR.rglob("*")):
        if child.is_file() and not child.name.startswith("."):
            size_mb = child.stat().st_size / 1024 / 1024
            rel = child.relative_to(DATA_DIR)
            print(f"  {rel}  ({size_mb:.1f} MB)")


if __name__ == "__main__":
    main()
