import os
import shutil

DATASETS = {
    'deepsol': {'task': 'classification', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 1700, 'n_labels': 2},
    'envision': {'task': 'regression', 'seq_col': 'primary', 'label_col': 'scaled_effect1', 'max_len': 500, 'n_labels': 1},
    'flip_thermostability': {'task': 'regression', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 2700, 'n_labels': 1},
    'rocklin': {'task': 'regression', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 100, 'n_labels': 1},
    'sarkisyan': {'task': 'regression', 'seq_col': 'aa_seq', 'label_col': 'label', 'max_len': 300, 'n_labels': 1},
    'flip_aav': {'task': 'regression', 'seq_col': 'sequence', 'label_col': 'target', 'max_len': 500, 'n_labels': 1, 'split_col': 'set'},
    'flip_gb1': {'task': 'regression', 'seq_col': 'sequence', 'label_col': 'target', 'max_len': 100, 'n_labels': 1, 'split_col': 'set'},
}

def get_train_content(dname, info, channel):
    # Depending on the dataset, the data loading logic changes
    if 'split_col' in info:
        # e.g. flip datasets have a single file with a 'set' column
        data_loading = f"""
    full_df = pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/splits/mut_des.csv') if '{dname}' == 'flip_aav' else pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/splits/two_vs_rest.csv')
    train_df = shuffle(full_df[full_df['set'] == 'train'])
    val_df = shuffle(full_df[full_df['validation'] == True] if 'validation' in full_df.columns and full_df['validation'].any() else full_df[full_df['set'] == 'test']) 
    test_df = shuffle(full_df[full_df['set'] == 'test'])
    """
    else:
        # other datasets have separate files
        data_loading = f"""
    train_df = shuffle(pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/train.csv'))
    val_df = shuffle(pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/validation.csv'))
    test_df = shuffle(pd.read_csv(cwd + '../../../../Data/benchmark/{dname}/test.csv'))
    """

    metrics_train = "f1_score(epoch_train_labels, epoch_train_preds, average='macro')" if info['task'] == 'classification' else "utils.get_spearman(epoch_train_labels, epoch_train_preds)"
    metrics_eval = "f1_score(epoch_val_labels, epoch_val_preds, average='macro')" if info['task'] == 'classification' else "utils.get_spearman(epoch_val_labels, epoch_val_preds)"
    metrics_test = "f1_score(epoch_test_labels, epoch_test_preds, average='macro')" if info['task'] == 'classification' else "utils.get_spearman(epoch_test_labels, epoch_test_preds)"
    
    classification_report_line = "print(classification_report(epoch_val_labels, epoch_val_preds))" if info['task'] == 'classification' else "pass # no class report for regression"
    loss_call = "utils.loss_fn_multi_class(tmp_outputs, tmp_labels, positive_weightings.to(device))" if info['task'] == 'classification' else "utils.loss_fn_regression(tmp_outputs, tmp_labels)"
    loss_call_train = "utils.loss_fn_multi_class(train_outputs, train_labels, positive_weightings.to(device))" if info['task'] == 'classification' else "utils.loss_fn_regression(train_outputs, train_labels)"
    
    pos_weights = "positive_weightings = utils.get_pos_scalings(train_df, N_LABELS)" if info['task'] == 'classification' else "positive_weightings = None"
    
    model_path = "'../../../../output/single_channel_pretrain'" if channel == 'SingleChannel' else "'../../../../output/dual_channel_pretrain'"

    train_py = f"""import os, shutil
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from tokenizer import ProteinTokenizer
from sklearn.metrics import classification_report, f1_score
from sklearn.utils import shuffle
import utils, models
import optuna
import joblib
import time
import logging

def save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name):
    shutil_dir = trials_dir + 'Trial_' + str(parameter_dictionary['trial_num']) + '/'
    try: os.mkdir(shutil_dir)
    except: pass 
    shutil.move(outmodel_name, shutil_dir)
    shutil.move(val_label_name, shutil_dir)
    shutil.move(val_pred_name, shutil_dir)
    shutil.move(test_label_name, shutil_dir)
    shutil.move(test_pred_name, shutil_dir)

def eval_model(parameter_dictionary, model, device, trial_num, epoch, set_flag):
    t0 = time.time()
    tmp_params =  {{'batch_size': parameter_dictionary['batch_size'], 'shuffle': False, 'num_workers': 0}}
    tmp_loader = DataLoader(validation_set, **tmp_params) if set_flag == 'Validation' else DataLoader(testing_set, **tmp_params)
    len_tmp_dataloader = len(tmp_loader)
    tmp_loss_accumulator = 0
    model.eval()
    epoch_tmp_preds = []
    epoch_tmp_labels = []

    with torch.no_grad():
        for tmp_data_idx, tmp_data in enumerate(tmp_loader):
            tmp_percent_done = (((tmp_data_idx + 1) / len_tmp_dataloader) * 100)
            tmp_ids = tmp_data['input_ids'].to(device, dtype=torch.int)
            tmp_mask = tmp_data['attention_mask'].to(device, dtype=torch.int)
            tmp_labels = tmp_data['labels'].to(device, dtype=torch.bfloat16)
            
            # dual channel passes both
            if "{channel}" == "DualChannel":
                tmp_cons = tmp_data['cons_ids'].to(device, dtype=torch.int)
                tmp_outputs = model(tmp_ids, tmp_cons, tmp_mask)
            else:
                tmp_outputs = model(tmp_ids, tmp_mask)

            tmp_loss, tmp_pred, tmp_truth = {loss_call}
            tmp_loss_accumulator += tmp_loss.item()
            epoch_tmp_preds.extend(tmp_pred)
            epoch_tmp_labels.extend(tmp_truth)
            t_delta = time.time() - t0
            print(f'Trial: {{trial_num}}, {{set_flag}}: Epoch: {{epoch}}, Loss: {{tmp_loss.item():.16f}}, % Done: {{tmp_percent_done:.5f}}, Time Elapsed: {{t_delta:.5f}}')

    average_tmp_loss = np.round(tmp_loss_accumulator / len_tmp_dataloader, 8)
    return average_tmp_loss, epoch_tmp_labels, epoch_tmp_preds

def train_model(parameter_dictionary):
    trial_num = parameter_dictionary['trial_num']
    study_best = 0 if trial_num <= number_jobs else study.best_trial.values[0]
    device = torch.device('cuda')

    train_params = {{'batch_size': parameter_dictionary['batch_size'], 'shuffle': True, 'num_workers': 0}}
    training_loader = DataLoader(training_set, **train_params)
    len_training_dataloader = len(training_loader)

    model = models.PerSequenceClassificationLora(parameter_dictionary).bfloat16().to(device)
    optimizer = torch.optim.AdamW(params=model.parameters(), lr=parameter_dictionary['learning_rate'], fused=True)
    
    current_val_metric = -99999
    outmodel_name = '{dname}_' + str(trial_num) + '.pt'
    val_label_name = 'ValLabels.joblib'
    val_pred_name = 'ValPreds.joblib'
    test_label_name = 'TestLabels.joblib'
    test_pred_name = 'TestPreds.joblib'

    grad_accum_steps = parameter_dictionary['grad_accum_steps']
    patience_counter = 0
    patience = 15

    t0 = time.time()
    for epoch in range(parameter_dictionary['epochs']):
        epoch_train_preds = []
        epoch_train_labels = []
        model.train()
        train_loss_accumulator = 0
        optimizer.zero_grad()
        for train_data_idx, train_data in enumerate(training_loader):
            training_percent_done = (((train_data_idx + 1) / len_training_dataloader) * 100)
            train_ids = train_data['input_ids'].to(device, dtype=torch.int)
            train_mask = train_data['attention_mask'].to(device, dtype=torch.int)
            train_labels = train_data['labels'].to(device, dtype=torch.bfloat16)

            if "{channel}" == "DualChannel":
                train_cons = train_data['cons_ids'].to(device, dtype=torch.int)
                train_outputs = model(train_ids, train_cons, train_mask)
            else:
                train_outputs = model(train_ids, train_mask)
                
            train_loss, train_pred, train_truth = {loss_call_train}
            train_loss_accumulator += train_loss.item()
            train_loss.backward()

            epoch_train_preds.extend(train_pred)
            epoch_train_labels.extend(train_truth)
            t_delta = time.time() - t0
            print(f'Trial: {{trial_num}}, Training: Epoch: {{epoch}}, Loss: {{train_loss.item():.16f}}, % Done: {{training_percent_done:.5f}}, Time Elapsed: {{t_delta:.5f}}')

            if (train_data_idx + 1) % grad_accum_steps == 0 or (train_data_idx + 1) == len(training_loader):
                optimizer.step()
                optimizer.zero_grad()

            if (train_data_idx + 1) == int(np.floor(len_training_dataloader / 2)) or (train_data_idx + 1) == len_training_dataloader:
                average_train_loss = np.round(train_loss_accumulator / (train_data_idx + 1), 8)
                average_val_loss, epoch_val_labels, epoch_val_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, "Validation")
                
                new_val_metric = {metrics_eval}
               
                if new_val_metric >= current_val_metric:
                    current_val_metric = new_val_metric
                    patience_counter = 0
                    torch.save(model.state_dict(), outmodel_name)
                    joblib.dump(epoch_val_labels, val_label_name)
                    joblib.dump(epoch_val_preds, val_pred_name)
                else:
                    patience_counter += 1

                print('Validation Metric: ' + str(new_val_metric))
                print('Patience = ' + str(patience_counter))
                
                if patience_counter != patience:
                    model.train()
                else:
                    if current_val_metric >= study_best:
                        average_test_loss, epoch_test_labels, epoch_test_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, 'Testing')
                        joblib.dump(epoch_test_labels, test_label_name)
                        joblib.dump(epoch_test_preds, test_pred_name)
                        save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name)
                    else:
                        os.remove(outmodel_name)
                        os.remove(val_label_name)
                        os.remove(val_pred_name)
                    model.to('cpu')
                    del model
                    torch.cuda.empty_cache()
                    return current_val_metric
        
    average_test_loss, epoch_test_labels, epoch_test_preds = eval_model(parameter_dictionary, model, device, trial_num, epoch, 'Testing')
    joblib.dump(epoch_test_labels, test_label_name)
    joblib.dump(epoch_test_preds, test_pred_name)
    save_model(parameter_dictionary, outmodel_name, val_label_name, val_pred_name, test_label_name, test_pred_name)
    model.to('cpu')
    del model
    torch.cuda.empty_cache()
    return current_val_metric

def objective(trial):
    torch.cuda.empty_cache()
    utils.seed_everything(seed)
    trial_num = trial.number
    
    if trial_num != 0:
        best_params = study.best_trial.params
        best_params['best_trial_num'] = study.best_trial.number
        joblib.dump(best_params, 'best_hyperparameters.joblib')
        study.trials_dataframe().to_csv('optuna_data.csv', index=False)
        joblib.dump(study, 'optuna_study.joblib')

    parameters = {{
            'pretrained_model_path' : cwd + {model_path},
            'in_shape' : MAX_LEN,
            'out_shape' : N_LABELS,
            'epochs' : 50,
            'batch_size' : trial.suggest_int('batch_size', 2, 32, step=2),
            'grad_accum_steps' : trial.suggest_int('grad_accum_steps', 1, 16, step=1),
            'dropout_weight' : trial.suggest_float('dropout_weight', 0.1, 0.4, log=False),
            'learning_rate' : trial.suggest_float('learning_rate', 0.00001, 0.001, log=False),
            'trial_num' : trial_num,
            'lora_rank' : trial.suggest_int('lora_rank', 4, 8, step=1),
            'lora_scaling_rank' : 1,
            'lora_init_scale' : 0.01,
            'lora_modules' : '.*mixer.*',
            'lora_layers' : 'in_proj|out_proj|x_proj|dt_proj',
            'lora_trainable_param_names' : '.*norm.*|.*lora_[ab].*'
            }}
    trial_metric = train_model(parameters)
    torch.cuda.empty_cache()
    return trial_metric

if __name__ == '__main__':
    global cwd, seed, trials_dir, tokenizer, training_set, validation_set, testing_set, positive_weightings
    global MAX_LEN, N_LABELS, study, number_jobs
    cwd = os.getcwd() + '/'
    seed = 42

    utils.seed_everything(seed)
    utils.set_global_logging_level(logging.ERROR, ["transformers", "nlp", "torch", "tensorflow", "tensorboard", "wandb"])
    trials_dir = utils.setup_trials_dir(cwd)

    MAX_LEN = {info['max_len']}
    N_LABELS = {info['n_labels']}

    tokenizer = ProteinTokenizer()
    {data_loading}

    training_set = models.PerSequenceClassificationDataset(train_df, tokenizer, MAX_LEN, '{info['seq_col']}', '{info['label_col']}', N_LABELS)
    validation_set = models.PerSequenceClassificationDataset(val_df, tokenizer, MAX_LEN, '{info['seq_col']}', '{info['label_col']}', N_LABELS)
    testing_set = models.PerSequenceClassificationDataset(test_df, tokenizer, MAX_LEN, '{info['seq_col']}', '{info['label_col']}', N_LABELS)

    {pos_weights}

    number_trials = 10
    number_jobs = 1

    study = optuna.create_study(direction='maximize',sampler=optuna.samplers.TPESampler(seed=seed))
    study.optimize(objective, n_trials=number_trials, n_jobs=number_jobs, show_progress_bar=True)
"""
    return train_py


def get_utils_content():
    return """import os 
import re
import random 
import numpy as np 
import pandas as pd
import torch
import torch.nn.functional as F
from scipy.stats import spearmanr
import logging

seed=42
def seed_everything(seed=seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    return None

seed_everything(seed)

def get_pos_scalings(data, n_labels):
    label_df = pd.DataFrame(data['label'].tolist(), columns=[f'col{i+1}' for i in range(n_labels)])
    zero_to_one_ratios = label_df.apply(lambda col: col.eq(0).sum() / col.eq(1).sum() if col.eq(1).any() else np.nan).to_list()
    return torch.tensor(zero_to_one_ratios, dtype=torch.bfloat16)

def setup_trials_dir(cwd):
    trials_dir = cwd + 'Trials/'
    try: os.mkdir(trials_dir)
    except: pass
    return trials_dir

def loss_fn_multi_class(predictions, truths, positive_scalings=None):
    if positive_scalings is not None:
        loss_fct = torch.nn.CrossEntropyLoss(weight=positive_scalings)
    else:
        loss_fct = torch.nn.CrossEntropyLoss()
    truths = truths.to(torch.float32) 
    truths = torch.argmax(truths, dim=1).long() if truths.dim() > 1 else truths.long()
    batch_loss = loss_fct(predictions, truths)
    pred_list = predictions.argmax(dim=1).cpu().detach().numpy().tolist()
    label_list = truths.cpu().detach().numpy().tolist()
    return batch_loss, pred_list, label_list

def loss_fn_regression(predictions, truths):
    loss_fct = torch.nn.MSELoss()
    predictions = predictions.squeeze(-1)
    truths = truths.to(torch.float32)
    batch_loss = loss_fct(predictions, truths)
    pred_list = predictions.cpu().detach().numpy().tolist()
    label_list = truths.cpu().detach().numpy().tolist()
    return batch_loss, pred_list, label_list

def get_spearman(truths, preds):
    res, _ = spearmanr(truths, preds)
    if np.isnan(res): res = 0
    return res

def set_global_logging_level(level=logging.ERROR, prefices=['', 'torch.distributed']):
    prefix_re = re.compile(fr'^(?:{ "|".join(prefices) })')
    for name in logging.root.manager.loggerDict:
        if re.match(prefix_re, name):
            logging.getLogger(name).setLevel(level)
"""

def get_models_content(info, channel):
    
    get_item = f"""
        sequence = self.sequences[index]
        label = self.labels[index]
        if pd.isna(sequence): sequence = ''
        ids, cons = self.tokenizer.encode(sequence, cons_scores=None)
        if len(ids) > self.max_len:
            ids = ids[:self.max_len]
            cons = cons[:self.max_len]
        mask_len = len(ids)
        if len(ids) < self.max_len:
            ids = ids + [self.tokenizer.pad_token_id] * (self.max_len - len(ids))
            cons = cons + [self.tokenizer.pad_token_id] * (self.max_len - len(cons))
        mask = [1] * mask_len + [0] * (self.max_len - mask_len)
        label_tensor = torch.tensor(label) # shape depends on task
        
        # DualChannel will use cons
        if "{channel}" == "DualChannel":
            return {{'input_ids': torch.tensor(ids, dtype=torch.int), 'cons_ids': torch.tensor(cons, dtype=torch.int), 'attention_mask': torch.tensor(mask, dtype=torch.int), 'labels': label_tensor}}
        else:
            return {{'input_ids': torch.tensor(ids, dtype=torch.int), 'attention_mask': torch.tensor(mask, dtype=torch.int), 'labels': label_tensor}}
"""
    
    classification_call = "logits = self.classification_layer(logits)"
    
    model_py = f"""import re
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
import torch.nn.init as initialization_strategy
import utils
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from tokenizer import ProteinTokenizer
from pretrain.protein_lm.modeling.models.mamba.lm import MambaLMHeadModel
from pretrain.protein_lm.modeling.models.mamba.config_mamba import MambaConfig

utils.seed_everything()

class PerSequenceClassificationDataset(Dataset):
    def __init__(self, dataframe, tokenizer, max_len, seqname, labelname, n_labels):
        self.tokenizer = tokenizer
        self.dataframe = dataframe.copy().reset_index(drop=True)
        self.sequences = self.dataframe[seqname].values
        self.labels = self.dataframe[labelname].values
        self.max_len = max_len

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, index):{get_item}

class LoRALinear(nn.Module):
    def __init__(self, linear_layer, rank, scaling_rank, init_scale):
        super().__init__()
        self.in_features = linear_layer.in_features
        self.out_features = linear_layer.out_features
        self.rank = rank
        self.scaling_rank = scaling_rank
        self.weight = linear_layer.weight
        self.bias = linear_layer.bias
        
        self.lora_a = nn.Parameter(torch.randn(rank, linear_layer.in_features) * init_scale)
        self.lora_b = nn.Parameter(torch.zeros(linear_layer.out_features, rank))
        self.multi_lora_a = nn.Parameter(torch.ones(self.scaling_rank, linear_layer.in_features) + torch.randn(self.scaling_rank, linear_layer.in_features) * init_scale)
        self.multi_lora_b = nn.Parameter(torch.ones(linear_layer.out_features, self.scaling_rank))

    def forward(self, input):
        weight = self.weight
        weight = weight * torch.matmul(self.multi_lora_b, self.multi_lora_a) / self.scaling_rank
        weight = weight + torch.matmul(self.lora_b, self.lora_a) / self.rank
        return F.linear(input, weight, self.bias)

class PerSequenceClassificationLora(torch.nn.Module):
    def __init__(self, hyperparameters_dictionary):
        super(PerSequenceClassificationLora, self).__init__()
        self.out_shape = hyperparameters_dictionary['out_shape']
        self.dropout_weight = hyperparameters_dictionary['dropout_weight']
        self.lora_rank = hyperparameters_dictionary['lora_rank']
        self.lora_scaling_rank = hyperparameters_dictionary['lora_scaling_rank']
        self.lora_init_scale = hyperparameters_dictionary['lora_init_scale']
        self.lora_modules = hyperparameters_dictionary['lora_modules']
        self.lora_layers = hyperparameters_dictionary['lora_layers']
        self.lora_trainable_param_names = hyperparameters_dictionary['lora_trainable_param_names']

        pretrained_path = hyperparameters_dictionary.get('pretrained_model_path', None)
        if pretrained_path and os.path.exists(pretrained_path):
            self.encoder = MambaLMHeadModel.from_pretrained(pretrained_path)
            self.embedding_shape = self.encoder.config.d_model
        else:
            config = MambaConfig(d_model=768, n_layer=24, vocab_size=28)
            self.encoder = MambaLMHeadModel(config)
            self.embedding_shape = config.d_model
            
        for m_name, module in dict(self.encoder.named_modules()).items():
            if re.fullmatch(self.lora_modules, m_name):
                for c_name, layer in dict(module.named_children()).items():
                    if re.fullmatch(self.lora_layers, c_name):
                        if isinstance(layer, nn.Linear):
                            setattr(module, c_name, LoRALinear(layer, self.lora_rank, self.lora_scaling_rank, self.lora_init_scale))
        
        for (param_name, param) in self.encoder.named_parameters():
            if not re.fullmatch(self.lora_trainable_param_names, param_name):
                param.requires_grad = False         
            else:
                param.requires_grad = True

        self.dropout_layer = torch.nn.Dropout(self.dropout_weight)
        self.activation_function = F.relu

        self.l1 = torch.nn.Linear(self.embedding_shape, 512, bias=True)
        self.l2 = torch.nn.Linear(512, 256, bias=True)
        self.l3 = torch.nn.Linear(256, 128, bias=True)
        self.classification_layer = torch.nn.Linear(128, self.out_shape, bias=True)
        
        initialization_strategy.xavier_uniform_(self.l1.weight)
        initialization_strategy.xavier_uniform_(self.l2.weight)
        initialization_strategy.xavier_uniform_(self.l3.weight)
        initialization_strategy.xavier_uniform_(self.classification_layer.weight)

    def forward(self, ids, {'cons_ids, ' if channel == 'DualChannel' else ''}mask):
        utils.seed_everything()
        
        encoder_output = self.encoder(input_ids=ids)
        logits = encoder_output.hidden_states
        
        mask_expanded = mask.unsqueeze(-1).expand(logits.size()).float()
        sum_embeddings = torch.sum(logits * mask_expanded, 1)
        sum_mask = mask_expanded.sum(1)
        sum_mask = torch.clamp(sum_mask, min=1e-9)
        logits = sum_embeddings / sum_mask
        
        logits = self.dropout_layer(logits)
        logits = self.l1(logits)
        logits = self.activation_function(logits)
        logits = self.dropout_layer(logits)
        logits = self.l2(logits)
        logits = self.activation_function(logits)
        logits = self.dropout_layer(logits)
        logits = self.l3(logits)
        logits = self.activation_function(logits)
        
        {classification_call}
        return output
"""
    return model_py

def main():
    root = "finetuning"
    os.makedirs(root, exist_ok=True)
    
    for dname, info in DATASETS.items():
        base_dir = os.path.join(root, dname)
        
        for mode in ['SingleChannel', 'DualChannel']:
            tgt_dir = os.path.join(base_dir, mode)
            os.makedirs(tgt_dir, exist_ok=True)
            
            # Write utils.py
            with open(os.path.join(tgt_dir, "utils.py"), "w", encoding="utf-8") as f:
                f.write(get_utils_content())
                
            # Write models.py
            with open(os.path.join(tgt_dir, "models.py"), "w", encoding="utf-8") as f:
                f.write(get_models_content(info, mode))
                
            # Write train.py
            with open(os.path.join(tgt_dir, f"train_{mode.lower()}.py"), "w", encoding="utf-8") as f:
                f.write(get_train_content(dname, info, mode))
                
            print(f"Generated [{{info['task']}}] {{tgt_dir}}")

if __name__ == '__main__':
    main()
