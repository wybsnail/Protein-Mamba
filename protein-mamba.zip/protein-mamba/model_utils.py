"""ESM2 模型加载与推理工具模块

提供 ESM2 蛋白质语言模型的加载、掩码预测和可视化功能。
提取自 ESM.ipynb Cell 19, 34, 35, 36。
"""

import jax
import matplotlib.pyplot as plt
from transformers import AutoTokenizer, EsmModel, EsmForMaskedLM


# 默认模型检查点
# Model checkpoint name taken from this GitHub README:
# https://github.com/facebookresearch/esm#available-models-and-datasets-
DEFAULT_EMBEDDING_CHECKPOINT = "facebook/esm2_t33_650M_UR50D"
DEFAULT_MASKED_LM_CHECKPOINT = "facebook/esm2_t30_150M_UR50D"


def load_esm_model(checkpoint: str = DEFAULT_EMBEDDING_CHECKPOINT):
    """加载 ESM2 嵌入模型和分词器。

    Args:
        checkpoint: HuggingFace 模型检查点名称。

    Returns:
        (tokenizer, model) 元组。
    """
    tokenizer = AutoTokenizer.from_pretrained(checkpoint)
    model = EsmModel.from_pretrained(checkpoint)
    return tokenizer, model


def load_esm_masked_lm(checkpoint: str = DEFAULT_MASKED_LM_CHECKPOINT):
    """加载 ESM2 掩码语言模型和分词器。

    Args:
        checkpoint: HuggingFace 模型检查点名称。

    Returns:
        (tokenizer, masked_lm_model) 元组。
    """
    tokenizer = AutoTokenizer.from_pretrained(checkpoint)
    masked_lm_model = EsmForMaskedLM.from_pretrained(checkpoint)
    return tokenizer, masked_lm_model


def predict_masked_probabilities(
    masked_lm_model,
    tokenizer,
    amino_acid_seq: str,
    mask_index: int,
) -> tuple:
    """预测掩码位置的氨基酸概率分布。

    Args:
        masked_lm_model: ESM2 掩码语言模型。
        tokenizer: ESM2 分词器。
        amino_acid_seq: 原始氨基酸序列。
        mask_index: 要掩码的氨基酸位置（0-based 索引）。

    Returns:
        (mask_probs, letters, true_amino_acid) 元组：
        - mask_probs: 各 token 的预测概率数组
        - letters: token 名称列表
        - true_amino_acid: 被掩码位置的真实氨基酸
    """
    if mask_index < 0 or mask_index >= len(amino_acid_seq):
        raise ValueError("Mask index outside of sequence range.")

    # 构造掩码序列
    masked_seq = (
        amino_acid_seq[:mask_index] + "<mask>" + amino_acid_seq[(mask_index + 1):]
    )

    # 推理
    masked_inputs = tokenizer(masked_seq, return_tensors="pt")
    model_outputs = masked_lm_model(**masked_inputs)
    model_preds = model_outputs.logits

    # 提取掩码位置的预测（tokenizer 会在序列前添加 <cls>，所以位置 +1）
    mask_preds = model_preds[0, mask_index + 1].detach().numpy()

    # softmax 转换为概率
    mask_probs = jax.nn.softmax(mask_preds)

    vocab_to_index = tokenizer.get_vocab()
    letters = list(vocab_to_index.keys())
    true_amino_acid = amino_acid_seq[mask_index]

    return mask_probs, letters, true_amino_acid


def plot_predicted_probabilities(
    masked_lm_model,
    tokenizer,
    amino_acid_seq: str,
    mask_index: int,
):
    """可视化掩码位置的氨基酸预测概率分布。

    Args:
        masked_lm_model: ESM2 掩码语言模型。
        tokenizer: ESM2 分词器。
        amino_acid_seq: 原始氨基酸序列。
        mask_index: 要掩码的氨基酸位置（0-based 索引）。

    Returns:
        matplotlib Figure 对象。
    """
    mask_probs, letters, true_aa = predict_masked_probabilities(
        masked_lm_model, tokenizer, amino_acid_seq, mask_index
    )

    fig, ax = plt.subplots(figsize=(6, 4))
    plt.bar(letters, mask_probs, color="grey")
    plt.xticks(rotation=90)
    plt.title(
        f"Model probabilities for the masked amino acid at index="
        f"{mask_index} (true amino acid = {true_aa})."
    )
    plt.tight_layout()
    return fig


def main():
    """演示 ESM2 掩码预测流程。"""
    from data_preprocess import insulin_sequence

    print("正在加载 ESM2 掩码语言模型...")
    tokenizer, masked_lm_model = load_esm_masked_lm()
    print("模型加载完成。")

    # 掩码胰岛素序列的第 29 个位置（0-based）
    mask_idx = 29
    print(f"\n对胰岛素序列位置 {mask_idx} 进行掩码预测...")
    mask_probs, letters, true_aa = predict_masked_probabilities(
        masked_lm_model, tokenizer, insulin_sequence, mask_idx
    )
    print(f"真实氨基酸: {true_aa}")
    print(f"预测概率前 5 名:")
    sorted_indices = sorted(range(len(mask_probs)), key=lambda i: -mask_probs[i])
    for i in sorted_indices[:5]:
        print(f"  {letters[i]}: {mask_probs[i]:.4f}")

    # 可视化
    fig = plot_predicted_probabilities(
        masked_lm_model, tokenizer, insulin_sequence, mask_idx
    )
    plt.show()


if __name__ == "__main__":
    main()
