import os
from transformers import AutoTokenizer, EsmForMaskedLM

def download_model():
    model_name = "facebook/esm2_t30_150M_UR50D"
    base_dir = os.path.dirname(os.path.abspath(__file__))
    save_directory = os.path.join(base_dir, "model", "esm2_t30_150M_UR50D")
    
    print(f"Downloading {model_name}...")
    
    # Download tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = EsmForMaskedLM.from_pretrained(model_name)
    
    print(f"Saving to {save_directory}...")
    os.makedirs(save_directory, exist_ok=True)
    # Save them to the local directory
    tokenizer.save_pretrained(save_directory)
    model.save_pretrained(save_directory)
    
    print("Download complete!")

if __name__ == "__main__":
    download_model()
