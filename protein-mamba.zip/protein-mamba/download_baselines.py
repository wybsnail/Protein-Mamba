import os
from transformers import AutoTokenizer, AutoModelForSequenceClassification

def download_model(model_name):
    # Convert model_name to folder format (e.g., Rostlab/prot_bert -> prot_bert)
    folder_name = model_name.split("/")[-1]
    base_dir = os.path.dirname(os.path.abspath(__file__))
    save_directory = os.path.join(base_dir, "model", folder_name)
    
    print(f"\n--- Downloading {model_name} ---")
    
    # Download tokenizer and model
    print(f"Loading tokenizer for {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    print(f"Loading model for {model_name}...")
    model = AutoModelForSequenceClassification.from_pretrained(model_name)
    
    os.makedirs(save_directory, exist_ok=True)
    print(f"Saving to {save_directory}...")
    tokenizer.save_pretrained(save_directory)
    model.save_pretrained(save_directory)
    
    print(f"Download of {model_name} complete!")

if __name__ == "__main__":
    baselines = [
        "facebook/esm2_t33_650M_UR50D",
        "Rostlab/prot_bert",
        "Rostlab/prot_t5_xl_uniref50"
    ]
    
    for baseline in baselines:
        try:
            download_model(baseline)
        except Exception as e:
            print(f"Error downloading {baseline}: {e}")
