"""蛋白质单通道预训练语料 Token 化脚本

仅处理氨基酸序列（不计算保守性分数），用于 Mamba 原生单通道环境的预训练。

读取 data/pretrain/pretrain_sequences.csv
写入 data/tokenized/pretrain/ 目录下的 npz 和 metadata

用法：
    python tokenize_pretrain_single.py
"""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import numpy as np

from tokenizer import ProteinTokenizer

PROJECT_ROOT = Path(__file__).parent
PRETRAIN_CSV = PROJECT_ROOT / "data" / "pretrain" / "pretrain_sequences.csv"
OUTPUT_DIR = PROJECT_ROOT / "data" / "tokenized" / "pretrain"


def process_pretrain_data():
    if not PRETRAIN_CSV.exists():
        raise FileNotFoundError(f"找不到预训练语料: {PRETRAIN_CSV}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    tokenizer = ProteinTokenizer(add_special=True)

    print(f"🚀 单通道预训练 Token 化")
    print(f"=" * 60)
    print(f"  读取: {PRETRAIN_CSV}")

    aa_ids_list = []
    lengths_list = []

    # 1. 读取并编码
    t0 = time.time()
    with open(PRETRAIN_CSV, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader):
            seq = row["sequence"].strip()
            # 仅编码 AA，无保守性分数 (cons_ids 会默认全为 PAD/MED，这里预训练丢弃不用)
            aa_ids, _ = tokenizer.encode(seq, cons_scores=None)
            
            aa_ids_list.append(np.array(aa_ids, dtype=np.int32))
            lengths_list.append(len(aa_ids))

            if (i + 1) % 5000 == 0:
                print(f"    已处理 {i + 1:,} 条 ...")

    total_seqs = len(aa_ids_list)
    lengths = np.array(lengths_list, dtype=np.int32)
    print(f"  ✓ 完成。共 {total_seqs:,} 条，总耗时 {time.time() - t0:.1f}s")
    
    # 2. 保存 .npz
    out_npz = OUTPUT_DIR / "train.npz"
    print(f"  正在保存至: {out_npz}")
    # 对于单通道预训练，模型只关心 input_ids。
    # 为了兼容可能的 dataset loader，保存 aa_ids
    np.savez_compressed(
        str(out_npz),
        aa_ids=np.array(aa_ids_list, dtype=object),
        lengths=lengths,
        # 伪造占位的 labels 使其结构与其他数据一致 (无监督无 label)
        labels=np.zeros(total_seqs, dtype=np.float32)
    )

    size_mb = out_npz.stat().st_size / 1024 / 1024
    print(f"  ✓ npz 保存完毕 ({size_mb:.1f} MB)")

    # 3. 保存 metadata
    meta = {
        "dataset": "pretrain",
        "method": "none",
        "channels": "single",
        "vocab_size": tokenizer.vocab_size,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "splits": {
            "train": {
                "count": total_seqs,
                "avg_length": float(lengths.mean()),
                "max_length": int(lengths.max()),
            }
        }
    }
    meta_path = OUTPUT_DIR / "metadata.json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
        
    print(f"  ✓ metadata 保存完毕")
    print(f"=" * 60)


if __name__ == "__main__":
    process_pretrain_data()
