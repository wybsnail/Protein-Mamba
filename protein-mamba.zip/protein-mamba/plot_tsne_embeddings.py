
import argparse
import torch
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.metrics import silhouette_score
from sklearn.metrics import pairwise_distances
import seaborn as sns
import os
import sys
from types import SimpleNamespace
from omegaconf import OmegaConf

# Append the project root appropriately
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), ".")))

from pretrain.protein_lm.modeling.models.mamba.lm import MambaLMHeadModel
from pretrain.protein_lm.tokenizer.tokenizer import PTMTokenizer

def load_model(ckpt_path):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Loading checkpoint from {ckpt_path} on {device}...")
    
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model_state_dict = ckpt["model"]
    raw_config = OmegaConf.to_container(ckpt["config"], resolve=True)
    model_config = SimpleNamespace(**raw_config)
    model_config.d_model = int(model_config.d_model)
    model_config.n_layer = int(model_config.n_layer)
    if model_config.vocab_size is None:
        model_config.vocab_size = int(model_state_dict["backbone.embedding.weight"].shape[0])
    else:
        model_config.vocab_size = int(model_config.vocab_size)
    if hasattr(model_config, "esm_embed_dim"):
        model_config.esm_embed_dim = int(model_config.esm_embed_dim)
    model_config.fused_add_norm = False
    model_config.rms_norm = False
    
    tokenizer = PTMTokenizer()
    
    model = MambaLMHeadModel(config=model_config)
    model = model.to(device)
    model.load_state_dict(model_state_dict, strict=False)
    model.eval()
    
    return model, tokenizer, device

def get_sequence_embeddings(model, tokenizer, sequences, device):
    embeddings = []
    with torch.no_grad():
        for seq in sequences:
            # Tokenize sequence
            input_ids = tokenizer(seq.replace(" ", ""), return_tensor=True).unsqueeze(0).to(device)
            input_ids = torch.where(
                input_ids < model.config.vocab_size,
                input_ids,
                torch.full_like(input_ids, 3),
            )
            
            # Forward pass to get hidden states
            # Forcing to CPU bypasses the customized fused CUDA kernels in mamba_ssm
            outputs = model(input_ids)
            # outputs is a CausalLMOutput with hidden_states (B, L, D)
            hidden_states = outputs.hidden_states
            
            # Global mean pooling for the sequence
            seq_emb = torch.mean(hidden_states, dim=1).squeeze().cpu().numpy()
            embeddings.append(seq_emb)
            
    return np.array(embeddings)


def compute_quantitative_metrics(embeddings, labels, positive_label):
    labels = np.array(labels)
    positive_mask = labels == positive_label
    negative_mask = ~positive_mask

    n_positive = int(positive_mask.sum())
    n_negative = int(negative_mask.sum())
    if n_positive < 2 or n_negative < 2:
        return {
            "available": False,
            "reason": "Each class needs at least 2 samples for distance and silhouette metrics.",
            "positive_class": positive_label,
            "negative_class": "other",
            "n_positive": n_positive,
            "n_negative": n_negative,
        }

    binary_labels = positive_mask.astype(int)
    silhouette = float(silhouette_score(embeddings, binary_labels, metric="euclidean"))

    positive_embeddings = embeddings[positive_mask]
    negative_embeddings = embeddings[negative_mask]

    pos_dists = pairwise_distances(positive_embeddings, metric="euclidean")
    neg_dists = pairwise_distances(negative_embeddings, metric="euclidean")
    inter_dists = pairwise_distances(positive_embeddings, negative_embeddings, metric="euclidean")

    mean_intra_positive = float(pos_dists[np.triu_indices_from(pos_dists, k=1)].mean())
    mean_intra_negative = float(neg_dists[np.triu_indices_from(neg_dists, k=1)].mean())
    mean_intra = (mean_intra_positive + mean_intra_negative) / 2.0
    mean_inter = float(inter_dists.mean())

    centroid_positive = positive_embeddings.mean(axis=0)
    centroid_negative = negative_embeddings.mean(axis=0)
    centroid_distance = float(np.linalg.norm(centroid_positive - centroid_negative))

    return {
        "available": True,
        "silhouette_score": silhouette,
        "mean_intra_class_distance": mean_intra,
        "mean_inter_class_distance": mean_inter,
        "inter_over_intra_ratio": float(mean_inter / (mean_intra + 1e-12)),
        "centroid_distance": centroid_distance,
        "positive_class": positive_label,
        "negative_class": "other",
        "n_positive": n_positive,
        "n_negative": n_negative,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt_path", type=str, required=True, help="Path to best.ckpt")
    parser.add_argument("--output_dir", type=str, default="./outputs/tsne_plots", help="Output directory for plots")
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    model, tokenizer, device = load_model(args.ckpt_path)

    # ---------------------------------------------------------
    # PART A: Sequence Embeddings (Wild-type vs PTM)
    # ---------------------------------------------------------
    print("Generating Sequence Embeddings...")
    
    # 1. Generate some dummy/synthetic wild-type and corresponding PTM sequences
    # PTM tokens generally defined in the PTMTokenizer
    wild_types = [
        "M G S S H H H H H H S S G L V P R G S H M A S",
        "M K V L F A A L A L C A A W A A L T T N A M T",
        "M Y L N N N N N N N N N N N N N N N N N N N N",
        "D V Q V Q S V E S L A N L T T G G D K V L T S",
        "R K Y K V T P Q F A E A C L L T A K C M A P S"
    ]
    
    # For representation, let's insert some PTM tokens from the tokenizer vocab
    # Typical PTM tokens look like <Phosphoserine>, <N-acetylalanine>, etc.
    # Below are purely artificial examples modified from the wild types.
    ptm_seqs = [
         "M G S S H H H H H H S S G L V P R G <Phosphoserine> H M A S",
         "M K V L F A A L A L C A A W A A L T T <N-acetylalanine> M T",
         "M Y L N N N N N N N N N N N N N <Phosphothreonine> N N N N",
         "D V Q V Q S V E S L A N L T T G G D K V <Phosphotyrosine> T S",
         "R K Y K V T P Q F A E A C L L T A K C <N-acetylmethionine> A P S"
    ]
    
    all_seqs = wild_types + ptm_seqs
    labels = ["Wild-Type"] * len(wild_types) + ["PTM"] * len(ptm_seqs)
    
    seq_embs = get_sequence_embeddings(model, tokenizer, all_seqs, device)
    seq_metrics = compute_quantitative_metrics(seq_embs, labels, positive_label="PTM")
    
    # t-SNE for Sequences
    tsne_seq = TSNE(n_components=2, perplexity=3, random_state=42)
    seq_tsne_results = tsne_seq.fit_transform(seq_embs)
    
    # Plot A: Sequence Space
    plt.figure(figsize=(10, 8))
    sns.scatterplot(
        x=seq_tsne_results[:, 0], 
        y=seq_tsne_results[:, 1], 
        hue=labels, 
        palette={"Wild-Type": "blue", "PTM": "green"},
        s=100,
        alpha=0.8
    )
    
    # Draw orange lines connecting pairs
    for i in range(len(wild_types)):
        plt.plot(
            [seq_tsne_results[i, 0], seq_tsne_results[i + len(wild_types), 0]],
            [seq_tsne_results[i, 1], seq_tsne_results[i + len(wild_types), 1]],
            color='orange', 
            linestyle='--', 
            linewidth=1.5
        )
        
    plt.title("A) t-SNE of Sequence Embeddings (Wild-Type vs PTM)", fontsize=14)
    plt.xlabel("t-SNE Dimension 1")
    plt.ylabel("t-SNE Dimension 2")
    plt.grid(True, linestyle='--', alpha=0.6)
    
    out_path_A = os.path.join(args.output_dir, "tsne_sequence_embeddings.png")
    plt.savefig(out_path_A, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved Part A to {out_path_A}")
    if seq_metrics["available"]:
        print(
            "Sequence metrics | "
            f"silhouette={seq_metrics['silhouette_score']:.4f}, "
            f"inter={seq_metrics['mean_inter_class_distance']:.4f}, "
            f"intra={seq_metrics['mean_intra_class_distance']:.4f}, "
            f"inter/intra={seq_metrics['inter_over_intra_ratio']:.4f}, "
            f"centroid={seq_metrics['centroid_distance']:.4f}"
        )
    else:
        print(
            "Sequence metrics unavailable | "
            f"reason={seq_metrics['reason']}, "
            f"n_positive={seq_metrics['n_positive']}, n_negative={seq_metrics['n_negative']}"
        )
    
    # ---------------------------------------------------------
    # PART B: Token Embeddings
    # ---------------------------------------------------------
    print("Generating Token Embeddings...")
    
    # Get token embedding weights
    # MambaLMHeadModel has `backbone.embedding`
    token_embeddings = model.backbone.embedding.weight.detach().cpu().numpy()
    
    # Get vocabulary mapping
    vocab = {
        token: idx
        for idx, token in enumerate(tokenizer.ids_to_tokens[: model.config.vocab_size])
    }
    
    # Let's filter out special tokens that aren't AAs or PTMs, or group them
    token_labels = []
    valid_indices = []
    
    standard_aas = set("ACDEFGHIKLMNPQRSTVWY")
    
    for token, idx in vocab.items():
        if token in standard_aas:
            token_labels.append("Standard AA")
            valid_indices.append(idx)
        elif token.startswith("<") and token.endswith(">") and len(token) > 5 and token not in ["<pad>", "<cls>", "<eos>", "<mask>", "<unk>"]:
            # Assume it's a PTM token based on length & brackets (e.g. <Phosphoserine>)
            token_labels.append("PTM Token")
            valid_indices.append(idx)
        elif token in ["<pad>", "<cls>", "<eos>", "<mask>", "<unk>"]:
            # Optionally include special tokens
            # token_labels.append("Special")
            # valid_indices.append(idx)
            pass
            
    filtered_embeddings = token_embeddings[valid_indices]
    token_metrics = compute_quantitative_metrics(filtered_embeddings, token_labels, positive_label="PTM Token")
    
    # t-SNE for Tokens
    tsne_token = TSNE(n_components=2, perplexity=10, random_state=42)
    token_tsne_results = tsne_token.fit_transform(filtered_embeddings)
    
    # Plot B: Token Space
    plt.figure(figsize=(10, 8))
    sns.scatterplot(
        x=token_tsne_results[:, 0], 
        y=token_tsne_results[:, 1], 
        hue=token_labels,
        palette={"Standard AA": "purple", "PTM Token": "red"},
        s=80,
        alpha=0.7
    )
    
    plt.title("B) t-SNE of Labeled Token Embeddings", fontsize=14)
    plt.xlabel("t-SNE Dimension 1")
    plt.ylabel("t-SNE Dimension 2")
    plt.grid(True, linestyle='--', alpha=0.6)
    
    out_path_B = os.path.join(args.output_dir, "tsne_token_embeddings.png")
    plt.savefig(out_path_B, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved Part B to {out_path_B}")

    metrics_report_path = os.path.join(args.output_dir, "quantitative_metrics.txt")
    with open(metrics_report_path, "w", encoding="utf-8") as f:
        f.write("[Sequence Embeddings]\n")
        for key, value in seq_metrics.items():
            f.write(f"{key}: {value}\n")
        f.write("\n[Token Embeddings]\n")
        for key, value in token_metrics.items():
            f.write(f"{key}: {value}\n")

    if token_metrics["available"]:
        print(
            "Token metrics | "
            f"silhouette={token_metrics['silhouette_score']:.4f}, "
            f"inter={token_metrics['mean_inter_class_distance']:.4f}, "
            f"intra={token_metrics['mean_intra_class_distance']:.4f}, "
            f"inter/intra={token_metrics['inter_over_intra_ratio']:.4f}, "
            f"centroid={token_metrics['centroid_distance']:.4f}"
        )
    else:
        print(
            "Token metrics unavailable | "
            f"reason={token_metrics['reason']}, "
            f"n_positive={token_metrics['n_positive']}, n_negative={token_metrics['n_negative']}"
        )
    print(f"Saved quantitative metrics to {metrics_report_path}")
    print("Visualization complete.")

if __name__ == "__main__":
    main()
